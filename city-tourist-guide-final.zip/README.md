# City Tourist Guide 🗺️

A modern, full-stack, comprehensive City Tourist Companion & Decision Engine built with React 19, TypeScript, Vite, Tailwind CSS, Google Maps Platform, Three.js 3D Cinema Simulation, and Express.js.

Created by **Jeevan M K**.

---

## 🚀 Quick Start Guide (Run in VS Code)

### Prerequisites
- **Node.js** (v18.0.0 or higher recommended)
- **npm** (comes with Node.js) or **bun** / **pnpm**
- **VS Code** (Visual Studio Code)

---

### Step 1: Open the Project in VS Code
1. Extract `city-tourist-guide.zip` on your computer.
2. Open VS Code:
   - Click **File** -> **Open Folder...**
   - Select the extracted `city-tourist-guide` folder.
3. Open the integrated terminal in VS Code:
   - Press `` Ctrl + ` `` (Backtick) or go to **Terminal** -> **New Terminal**.

---

### Step 2: Install Dependencies
In the VS Code terminal, run:

```bash
npm install
```

*(This will install React, TypeScript, Tailwind CSS, Three.js, Lucide icons, Express, Vite, and all required packages.)*

---

### Step 3: Configure Environment Variables (Optional)
Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

You can optionally add your Google Gemini API key or Google Maps key in `.env`:
```env
GEMINI_API_KEY=your_gemini_api_key_here
PORT=3000
```
*(The app is designed with smart built-in fallback data for all districts, so it runs completely out of the box even without any external API keys!)*

---

### Step 4: Start the Development Server
In the VS Code terminal, run:

```bash
npm run dev
```

The application will start on:
👉 **http://localhost:3000**

Open this URL in Google Chrome, Microsoft Edge, or any modern web browser!

---

### Step 5: Build for Production
To create a production build:

```bash
npm run build
npm start
```

---

## 🌟 Key Features & Architecture

### 1. Account & Security Gate
- **Authentication**: User registration, login, and profile tracking.
- **Auto-Login**: Saves credentials locally with "Remember Me" for instant access.
- **Admin Portal**: Restricted administrator panel (`admin123`) to view user databases, booking transactions, city directory status, and real-time quick updates.

### 2. District & City Explorer
- **Davanagere Default**: Clean, uncluttered view spotlighting Davanagere district.
- **Curated Suggestions**: Famous Benne Dosa, Durgambika Devi Temple & Harihareshwara Temple, Gitanjali 3D cinema, Kunduvada Kere Promenade, and Bathi Hill & Glass House.
- **31 Districts of Karnataka & All India**: Seamless search and 1-click district switching across all Indian states and Union Territories.

### 3. Google Maps Platform with Real Satellite View
- **Satellite Imagery**: Toggle between real high-resolution satellite view and roadmap.
- **Turn-by-Turn Navigation**: Step-by-step route directions with distance calculations and direct Google Maps GPS navigation links.

### 4. Live Theatres & 3D Cinema Hall Booking (Three.js)
- **Currently Playing Movies**: Blockbuster movies running in district theatres (*Kantara: Chapter 1*, *Kalki 2898 AD*, *Pushpa 2*, *Stree 2*).
- **Interactive 3D Theatre**:
  - Curved glowing 3D silver screen with projector beam.
  - Tiered stadium seating: Recliner VIP, Gold Club, Silver Executive.
  - Interactive 3D seat raycasting (hover & pick seats).
  - "Preview View from Seat" camera flight mode.
  - E-Ticket QR generator & instant PDF pass download.

### 5. Smart Tourist Decision Hub (6 Hackathon Questions)
1. **Where should I go?** — Vibe Matcher (Spiritual, Foodie, Movies, Nature, Heritage, Family).
2. **What can I do nearby?** — Proximity radius filter (Walking <2 km, Auto <6 km, Drive).
3. **How much will the trip cost?** — Dynamic budget calculator with food, transit, and passes.
4. **How can I travel between places?** — Transit guide for auto-rickshaws, KSRTC buses, and walking.
5. **Which places are suitable for my time and budget?** — 2-3 hr express, 5 hr half-day, and full-day plans.
6. **What should I do if I need help while travelling?** — SOS dialers (112, 1091, 1363), local emergency contacts, and a Kannada phrasebook.

### 6. Time Spender Selector & City Slots
- Dedicated category views: **Sacred Temples & Live Crowd Radar**, **Cinemas & Theatres**, **Restaurants & Rated Dishes**, **Heritage Tourist Sights & Entry Tickets**, and **Live Events Near Me**.
- Multi-Day Personalized Itinerary Planner.
- AI Tourist Concierge & E-Ticket QR Wallet.
