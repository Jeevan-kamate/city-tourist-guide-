import React, { useState } from 'react';
import { Place, MovieShow } from '../types';
import { Film, Clock, Ticket, Star, Sparkles, Video, CheckCircle, Info, Calendar } from 'lucide-react';

interface TheatresViewProps {
  theatres: Place[];
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
  onBookMovie?: (movie: MovieShow, theatre: Place, showtime?: any) => void;
  onOpen3DTheatreBooking?: (theatre: Place, movie?: MovieShow, showtime?: any) => void;
}

export const TheatresView: React.FC<TheatresViewProps> = ({
  theatres,
  onSelectPlace,
  onShowOnMap,
  onBookMovie,
  onOpen3DTheatreBooking,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<string>('all');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [selectedTimeWindow, setSelectedTimeWindow] = useState<string>('all');

  // Extract all unique movies across theatres in this city
  const allMovies: { movie: MovieShow; theatre: Place }[] = [];
  theatres.forEach((th) => {
    th.movies?.forEach((mov) => {
      allMovies.push({ movie: mov, theatre: th });
    });
  });

  const formats = ['all', 'IMAX', '3D', '4K Laser', 'Dolby Atmos'];

  const filteredMovies = allMovies.filter(({ movie }) => {
    const matchesFormat =
      selectedFormat === 'all' ||
      movie.format.toLowerCase().includes(selectedFormat.toLowerCase());
    return matchesFormat;
  });

  const handleShowtimeClick = (movie: MovieShow, theatre: Place, showtime: any) => {
    if (onBookMovie) {
      onBookMovie(movie, theatre, showtime);
    }
  };

  return (
    <div id="theatres-section" className="space-y-6">
      {/* Banner & Filter Bar */}
      <div className="bg-[#2D2D2A] text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-[#45453E]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-2.5 bg-amber-400 text-[#2D2D2A] rounded-2xl shadow-sm">
                <Film className="w-6 h-6" />
              </span>
              <div>
                <span className="text-[11px] uppercase tracking-wider text-amber-300 font-bold block">
                  Direct Cinema Box Office
                </span>
                <h2 className="text-xl md:text-2xl font-serif font-bold text-white">
                  Cinema Theatres & Showtimes
                </h2>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-stone-300 max-w-2xl leading-relaxed">
              Book movie tickets with real-time seat selection, IMAX / 4K screen formats, popcorn pre-orders, and instant digital QR entry passes.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/15 text-xs">
            <div>
              <span className="text-stone-300 block text-[10px] uppercase font-bold">Theatres</span>
              <span className="font-bold text-lg text-white font-serif">{theatres.length}</span>
            </div>
            <div className="h-7 w-px bg-white/20" />
            <div>
              <span className="text-stone-300 block text-[10px] uppercase font-bold">Current Shows</span>
              <span className="font-bold text-lg text-amber-300 font-serif">{allMovies.length}</span>
            </div>
          </div>
        </div>

        {/* Filter Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-5 border-t border-white/10 mt-5 text-xs">
          <span className="text-stone-300 font-bold">Screen Formats:</span>
          {formats.map((fmt) => (
            <button
              key={fmt}
              onClick={() => setSelectedFormat(fmt)}
              className={`px-3.5 py-1.5 rounded-xl font-bold transition-all ${
                selectedFormat === fmt
                  ? 'bg-amber-400 text-[#2D2D2A] shadow-xs'
                  : 'bg-white/10 hover:bg-white/20 text-stone-200 border border-white/10'
              }`}
            >
              {fmt === 'all' ? 'All Screen Formats' : fmt}
            </button>
          ))}
        </div>
      </div>

      {/* Movies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMovies.map(({ movie, theatre }, idx) => (
          <div
            key={`${theatre.id}-${movie.id}-${idx}`}
            className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Movie Header / Poster */}
              <div className="relative h-44 w-full bg-stone-900 overflow-hidden">
                <img
                  src={movie.poster}
                  alt={movie.title}
                  className="w-full h-full object-cover opacity-85 hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-600/90 text-white backdrop-blur-md">
                    {movie.format}
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-400 text-stone-900">
                    ⭐ {movie.rating}/10
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <h3 className="font-bold text-base leading-tight drop-shadow-xs line-clamp-1">
                    {movie.title}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-stone-300 mt-0.5">
                    <span>{movie.duration}</span>
                    <span>•</span>
                    <span className="px-1.5 py-0.2 bg-white/20 rounded text-[10px]">{movie.certification}</span>
                    <span>•</span>
                    <span className="truncate">{movie.genre.join(', ')}</span>
                  </div>
                </div>
              </div>

              {/* Theatre Name & Address */}
              <div className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-2 pb-2 border-b border-stone-100">
                  <div>
                    <h4 className="font-bold text-xs text-stone-900 flex items-center gap-1.5">
                      <Film className="w-3.5 h-3.5 text-indigo-600" />
                      <span>{theatre.name}</span>
                    </h4>
                    <p className="text-[11px] text-stone-500 truncate mt-0.5">{theatre.address}</p>
                  </div>
                  <button
                    onClick={() => onShowOnMap(theatre)}
                    className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 shrink-0"
                  >
                    Map Pin
                  </button>
                </div>

                {/* Synopsis */}
                <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                  {movie.synopsis}
                </p>

                {/* Showtimes & Ticket Rates */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold text-stone-700">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-stone-400" />
                      Today's Available Showtimes:
                    </span>
                    <span className="text-[11px] text-stone-500 font-normal">Click time to reserve</span>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    {movie.showtimes.map((st, sIdx) => (
                      <button
                        key={sIdx}
                        onClick={() => handleShowtimeClick(movie, theatre, st)}
                        className="bg-[#F4F1EA] hover:bg-amber-100/80 border border-[#DEDACF] hover:border-amber-400 rounded-xl p-2.5 text-left transition-all group/st shadow-2xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-[#2D2D2A] group-hover/st:text-amber-950">
                            {st.time}
                          </span>
                          <span className="font-bold text-xs text-[#5A5A40]">
                            {st.currency}{st.price}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-[#8B8B6B] mt-1">
                          <span className="truncate">{st.screenType}</span>
                          <span className={
                            st.seatAvailability === 'Available' ? 'text-emerald-700 font-bold' : 'text-amber-700 font-bold'
                          }>
                            {st.seatAvailability}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Theatre Footer */}
            <div className="p-4 pt-0 space-y-2">
                <button
                  type="button"
                  onClick={() => handleShowtimeClick(movie, theatre, movie.showtimes[0])}
                  className="flex-1 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 text-xs font-extrabold rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-stone-950" />
                  <span>Book Tickets (Real 3D Theatre)</span>
                </button>

              <button
                onClick={() => onSelectPlace(theatre)}
                className="w-full py-2 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#5A5A40] text-xs font-semibold rounded-xl transition-colors border border-[#DEDACF]"
              >
                View Complex Details & All Movies ({theatre.movies?.length || 0})
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
