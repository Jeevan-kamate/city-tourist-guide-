import React, { useEffect, useRef, useState } from 'react';
import { Place, PlaceCategory, City, CityEvent, ItineraryScheduleItem } from '../types';
import L from 'leaflet';
import { 
  Film, 
  Sparkles, 
  UtensilsCrossed, 
  Landmark, 
  Navigation, 
  Layers, 
  Maximize2, 
  Compass, 
  MapPin, 
  Star, 
  Ticket, 
  Clock, 
  Eye, 
  Route, 
  PartyPopper,
  Calendar,
  PlusCircle,
  ExternalLink,
  Car,
  Footprints,
  Radio,
  X,
  ChevronRight
} from 'lucide-react';

interface InteractiveMapProps {
  city: City;
  places: Place[];
  events?: CityEvent[];
  selectedCategory: PlaceCategory | 'all';
  onCategoryChange: (cat: PlaceCategory | 'all') => void;
  onSelectPlace: (place: Place) => void;
  onSelectEvent?: (event: CityEvent) => void;
  onAddToItinerary?: (target: { type: 'place' | 'event'; item: Place | CityEvent }) => void;
  activePlace?: Place | null;
  activeEvent?: CityEvent | null;
  itineraryRouteItems?: ItineraryScheduleItem[];
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  city,
  places,
  events = [],
  selectedCategory,
  onCategoryChange,
  onSelectPlace,
  onSelectEvent,
  onAddToItinerary,
  activePlace,
  activeEvent,
  itineraryRouteItems,
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [id: string]: L.Marker }>({});
  const routeLayerRef = useRef<L.Polyline | null>(null);
  const labelLayerRef = useRef<L.TileLayer | null>(null);

  const [mapType, setMapType] = useState<'street' | 'terrain' | 'satellite'>('street');
  const [isSimulatingRoute, setIsSimulatingRoute] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Navigation & Directions Drawer States
  const [isNavDrawerOpen, setIsNavDrawerOpen] = useState(false);
  const [navOriginId, setNavOriginId] = useState<string>('origin-station');
  const [navDestinationId, setNavDestinationId] = useState<string>(places[0]?.id || '');
  const [navMode, setNavMode] = useState<'driving' | 'walking' | 'auto'>('driving');

  // Filter places based on active category & search query
  const filteredPlaces = places.filter((p) => {
    if (selectedCategory === 'event') return false;
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Filter events based on active category & search query
  const filteredEvents = events.filter((e) => {
    if (selectedCategory !== 'all' && selectedCategory !== 'event') return false;
    const matchesSearch = searchQuery === '' ||
      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.locationName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  // Category Icon SVG generator for custom Leaflet markers in Natural Tones
  const createCustomIcon = (
    category: PlaceCategory | 'event',
    isHighlighted: boolean = false,
    sequenceNumber?: number
  ) => {
    let bgColor = '#5A5A40'; // Olive default
    let iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><line x1="7" y1="2" x2="7" y2="22"></line><line x1="17" y1="2" x2="17" y2="22"></line><line x1="2" y1="12" x2="22" y2="12"></line></svg>`;

    if (category === 'temple') {
      bgColor = '#8B8B6B'; // Sage / Earth
      iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"></path></svg>`;
    } else if (category === 'restaurant') {
      bgColor = '#4A6741'; // Forest green
      iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8Z"></path><path d="M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7"></path></svg>`;
    } else if (category === 'attraction') {
      bgColor = '#C2410C'; // Warm terracotta
      iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="22" x2="21" y2="22"></line><line x1="6" y1="18" x2="6" y2="11"></line><line x1="10" y1="18" x2="10" y2="11"></line><line x1="14" y1="18" x2="14" y2="11"></line><line x1="18" y1="18" x2="18" y2="11"></line><polygon points="12 2 20 7 4 7"></polygon></svg>`;
    } else if (category === 'event') {
      bgColor = '#D28E5D'; // Warm amber event
      iconSvg = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5.8 11.3 2 22l10.7-3.8L22 2l-10.7 3.8Z"></path><path d="m9 15 3-3"></path></svg>`;
    }

    const size = isHighlighted ? 44 : 36;
    const ringClass = isHighlighted ? 'ring-4 ring-[#2D2D2A] shadow-2xl scale-110' : 'shadow-md';

    const innerContent = sequenceNumber !== undefined
      ? `<span style="color: white; font-weight: 800; font-size: 13px; font-family: sans-serif;">${sequenceNumber}</span>`
      : iconSvg;

    const html = `
      <div style="
        background-color: ${bgColor};
        width: ${size}px;
        height: ${size}px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid #ffffff;
        box-shadow: 0 4px 12px rgba(0,0,0,0.25);
      " class="${ringClass}">
        <div style="transform: rotate(45deg); display: flex; align-items: center; justify-content: center;">
          ${innerContent}
        </div>
      </div>
    `;

    return L.divIcon({
      html,
      className: 'custom-leaflet-marker',
      iconSize: [size, size],
      iconAnchor: [size / 2, size],
      popupAnchor: [0, -size],
    });
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [city.coordinates.lat, city.coordinates.lng],
        zoom: 13,
        zoomControl: false,
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // Natural Voyager CartoDB tiles by default
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://carto.com/">CARTO</a>, OpenStreetMap | Google Maps Platform Ready (gmp_mcp_codeassist_v1_aistudio)',
        maxZoom: 19,
      }).addTo(map);

      mapInstanceRef.current = map;
    } else {
      mapInstanceRef.current.setView([city.coordinates.lat, city.coordinates.lng], 13);
    }

    const timer = setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 250);

    return () => clearTimeout(timer);
  }, [city]);

  // Update Markers for Places and Events
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear previous markers
    Object.values(markersRef.current).forEach((marker: L.Marker) => marker.remove());
    markersRef.current = {};

    const bounds = L.latLngBounds([]);

    // If Itinerary Route is passed, render itinerary sequence markers and polyline
    if (itineraryRouteItems && itineraryRouteItems.length > 0) {
      const routeLatLngs: [number, number][] = [];

      itineraryRouteItems.forEach((it, idx) => {
        const coords = it.place?.coordinates || it.event?.coordinates;
        if (!coords) return;

        routeLatLngs.push([coords.lat, coords.lng]);
        const cat = it.place?.category || (it.event ? 'event' : 'attraction');
        const icon = createCustomIcon(cat as any, false, idx + 1);

        const marker = L.marker([coords.lat, coords.lng], { icon });
        const title = it.place?.name || it.event?.title || it.customTitle || 'Stop';

        const popupContent = document.createElement('div');
        popupContent.className = 'p-2 max-w-[240px] text-[#3D3D3D] font-sans';
        popupContent.innerHTML = `
          <div style="font-size: 10px; font-weight: 800; color: #5A5A40; text-transform: uppercase;">
            Stop #${idx + 1} (${it.startTime} - ${it.endTime})
          </div>
          <h4 style="font-weight: 700; font-size: 13px; margin: 2px 0 4px;">${title}</h4>
          <p style="font-size: 11px; color: #666; margin: 0;">${it.place?.address || it.event?.locationName || ''}</p>
        `;

        marker.bindPopup(popupContent);
        marker.addTo(map);
        markersRef.current[`it-route-${it.id}`] = marker;
        bounds.extend([coords.lat, coords.lng]);
      });

      if (routeLatLngs.length >= 2) {
        if (routeLayerRef.current) routeLayerRef.current.remove();
        routeLayerRef.current = L.polyline(routeLatLngs, {
          color: '#5A5A40',
          weight: 4,
          dashArray: '6, 8',
          opacity: 0.9,
        }).addTo(map);
        map.fitBounds(routeLayerRef.current.getBounds(), { padding: [50, 50] });
      } else if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
      }

      return;
    }

    // Add markers for filtered places
    filteredPlaces.forEach((place) => {
      const isHighlighted = activePlace?.id === place.id;
      const icon = createCustomIcon(place.category, isHighlighted);

      const marker = L.marker([place.coordinates.lat, place.coordinates.lng], { icon });

      // Custom Popup HTML with Google Maps GPS Navigation link
      const popupContent = document.createElement('div');
      popupContent.className = 'p-1 max-w-[270px] space-y-2 text-[#3D3D3D] font-sans';
      popupContent.innerHTML = `
        <div class="relative h-28 w-full rounded-xl overflow-hidden mb-2 bg-[#F4F1EA]">
          <img src="${place.image}" alt="${place.name}" style="width: 100%; height: 100%; object-fit: cover;" />
          <span style="position: absolute; top: 6px; left: 6px; font-size: 10px; font-weight: 700; background: #5A5A40; color: white; padding: 2px 6px; border-radius: 9999px; text-transform: uppercase;">
            ${place.category}
          </span>
          <span style="position: absolute; bottom: 6px; right: 6px; font-size: 10px; font-weight: 700; background: #ffffff; color: #2D2D2A; padding: 2px 6px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.2);">
            ⭐ ${place.rating} (${place.reviewCount})
          </span>
        </div>
        <h4 style="font-weight: 700; font-size: 13px; line-height: 1.3; margin: 0; color: #2D2D2A;">${place.name}</h4>
        <p style="font-size: 11px; color: #666; margin: 0; line-height: 1.2;">${place.tagline}</p>
        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 11px; border-top: 1px solid #E5E2D9; padding-top: 6px; margin-top: 6px;">
          <span style="font-weight: 700; color: #2D2D2A;">
            ${place.ticket.isFree ? 'FREE ENTRY' : `${place.ticket.currency}${place.ticket.generalPrice}`}
          </span>
          <span style="color: #8B8B6B; font-size: 10px;">${place.timings.open} - ${place.timings.close}</span>
        </div>
        <div style="display: flex; gap: 4px; margin-top: 6px;">
          <button id="popup-btn-view-${place.id}" style="
            flex: 1;
            background: #5A5A40;
            color: white;
            border: none;
            padding: 6px 8px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
          ">
            Details →
          </button>
          <a href="https://www.google.com/maps/dir/?api=1&destination=${place.coordinates.lat},${place.coordinates.lng}" target="_blank" rel="noopener noreferrer" style="
            background: #F4F1EA;
            color: #2D2D2A;
            border: 1px solid #DEDACF;
            padding: 6px 8px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 2px;
            text-decoration: none;
          ">
            🧭 GPS Nav
          </a>
        </div>
      `;

      marker.bindPopup(popupContent, { maxWidth: 290, closeButton: true });

      marker.on('popupopen', () => {
        const viewBtn = document.getElementById(`popup-btn-view-${place.id}`);
        if (viewBtn) {
          viewBtn.onclick = () => onSelectPlace(place);
        }
      });

      marker.addTo(map);
      markersRef.current[place.id] = marker;
      bounds.extend([place.coordinates.lat, place.coordinates.lng]);
    });

    // Add markers for filtered events
    filteredEvents.forEach((event) => {
      const isHighlighted = activeEvent?.id === event.id;
      const icon = createCustomIcon('event', isHighlighted);

      const marker = L.marker([event.coordinates.lat, event.coordinates.lng], { icon });

      const popupContent = document.createElement('div');
      popupContent.className = 'p-1 max-w-[270px] space-y-2 text-[#3D3D3D] font-sans';
      popupContent.innerHTML = `
        <div class="relative h-28 w-full rounded-xl overflow-hidden mb-2 bg-[#F4F1EA]">
          <img src="${event.image}" alt="${event.title}" style="width: 100%; height: 100%; object-fit: cover;" />
          <span style="position: absolute; top: 6px; left: 6px; font-size: 10px; font-weight: 700; background: #C2410C; color: white; padding: 2px 6px; border-radius: 9999px; text-transform: uppercase;">
            ${event.status}
          </span>
          <span style="position: absolute; bottom: 6px; right: 6px; font-size: 10px; font-weight: 700; background: #ffffff; color: #2D2D2A; padding: 2px 6px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.2);">
            ${event.isFree ? 'FREE' : `${event.currency}${event.ticketPrice}`}
          </span>
        </div>
        <h4 style="font-weight: 700; font-size: 13px; line-height: 1.3; margin: 0; color: #2D2D2A;">${event.title}</h4>
        <p style="font-size: 11px; color: #666; margin: 0; line-height: 1.2;">${event.locationName}</p>
        <div style="font-size: 10px; color: #8B8B6B; margin-top: 4px;">
          📅 ${event.date} • ${event.timing}
        </div>
        <div style="display: flex; gap: 4px; margin-top: 6px;">
          <button id="popup-btn-event-view-${event.id}" style="
            flex: 1;
            background: #5A5A40;
            color: white;
            border: none;
            padding: 6px 8px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
          ">
            Event Info →
          </button>
        </div>
      `;

      marker.bindPopup(popupContent, { maxWidth: 290, closeButton: true });

      marker.on('popupopen', () => {
        const viewBtn = document.getElementById(`popup-btn-event-view-${event.id}`);
        if (viewBtn && onSelectEvent) {
          viewBtn.onclick = () => onSelectEvent(event);
        }
      });

      marker.addTo(map);
      markersRef.current[`evt-${event.id}`] = marker;
      bounds.extend([event.coordinates.lat, event.coordinates.lng]);
    });

    if ((filteredPlaces.length > 0 || filteredEvents.length > 0) && !activePlace && !activeEvent && bounds.isValid()) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }
  }, [filteredPlaces, filteredEvents, activePlace, activeEvent, itineraryRouteItems]);

  // Pan to active place / event
  useEffect(() => {
    if (activePlace && mapInstanceRef.current) {
      mapInstanceRef.current.setView(
        [activePlace.coordinates.lat, activePlace.coordinates.lng],
        16,
        { animate: true }
      );
      const marker = markersRef.current[activePlace.id];
      if (marker) marker.openPopup();
    } else if (activeEvent && mapInstanceRef.current) {
      mapInstanceRef.current.setView(
        [activeEvent.coordinates.lat, activeEvent.coordinates.lng],
        16,
        { animate: true }
      );
      const marker = markersRef.current[`evt-${activeEvent.id}`];
      if (marker) marker.openPopup();
    }
  }, [activePlace, activeEvent]);

  // Route Path Simulator between places
  const toggleRouteSimulation = () => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (isSimulatingRoute) {
      if (routeLayerRef.current) {
        routeLayerRef.current.remove();
        routeLayerRef.current = null;
      }
      setIsSimulatingRoute(false);
    } else {
      const latlngs = filteredPlaces.map((p) => [p.coordinates.lat, p.coordinates.lng] as [number, number]);
      if (latlngs.length >= 2) {
        if (routeLayerRef.current) routeLayerRef.current.remove();
        routeLayerRef.current = L.polyline(latlngs, {
          color: '#5A5A40',
          weight: 5,
          dashArray: '8, 8',
          opacity: 0.9,
        }).addTo(map);
        map.fitBounds(routeLayerRef.current.getBounds(), { padding: [50, 50] });
        setIsSimulatingRoute(true);
      }
    }
  };

  // Real Satellite Switcher
  const handleTileChange = (type: 'street' | 'terrain' | 'satellite') => {
    setMapType(type);
    const map = mapInstanceRef.current;
    if (!map) return;

    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    if (type === 'satellite') {
      // True High-Resolution World Imagery
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19,
        attribution: 'Satellite Imagery &copy; Esri, Maxar, Earthstar Geographics | Google Maps Platform API Enabled',
      }).addTo(map);

      // Add clear street labels on top of satellite
      const labelLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        pane: 'shadowPane',
      }).addTo(map);
      labelLayerRef.current = labelLayer;
    } else if (type === 'terrain') {
      L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        maxZoom: 17,
        attribution: 'Map data: &copy; OpenStreetMap contributors, SRTM | Map style: &copy; OpenTopoMap',
      }).addTo(map);
    } else {
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        attribution: '&copy; CARTO, OpenStreetMap | Google Maps Platform Ready (gmp_mcp_codeassist_v1_aistudio)',
      }).addTo(map);
    }
  };

  // Resolve selected destination place for navigation
  const selectedDestPlace = places.find((p) => p.id === navDestinationId) || places[0];

  return (
    <div id="interactive-map-section" className="relative w-full h-[580px] lg:h-[700px] rounded-3xl overflow-hidden border border-[#E5E2D9] shadow-md bg-[#F4F1EA]">
      {/* Map Container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Floating Top Header Controls Overlay */}
      <div className="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        
        {/* Category Filters in Natural Tones */}
        <div className="flex items-center gap-1 bg-white/95 backdrop-blur-md p-1.5 rounded-2xl border border-[#DEDACF] shadow-md pointer-events-auto overflow-x-auto max-w-full text-xs">
          <button
            onClick={() => onCategoryChange('all')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'all' ? 'bg-[#2D2D2A] text-white' : 'text-[#3D3D3D] hover:bg-[#F4F1EA]'
            }`}
          >
            All Pins ({places.length + events.length})
          </button>

          <button
            onClick={() => onCategoryChange('temple')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'temple' ? 'bg-[#8B8B6B] text-white' : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Temples</span>
          </button>

          <button
            onClick={() => onCategoryChange('theatre')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'theatre' ? 'bg-[#5A5A40] text-white' : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Theatres</span>
          </button>

          <button
            onClick={() => onCategoryChange('restaurant')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'restaurant' ? 'bg-[#4A6741] text-white' : 'text-[#4A6741] hover:bg-[#E9F2E9]'
            }`}
          >
            <UtensilsCrossed className="w-3.5 h-3.5" />
            <span>Food & Dosa</span>
          </button>

          <button
            onClick={() => onCategoryChange('attraction')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'attraction' ? 'bg-[#C2410C] text-white' : 'text-[#C2410C] hover:bg-[#FFF9F0]'
            }`}
          >
            <Landmark className="w-3.5 h-3.5" />
            <span>Attractions</span>
          </button>
        </div>

        {/* Right Tools: Navigation Drawer, Route Simulator & Tile Switch */}
        <div className="flex items-center gap-2 pointer-events-auto">
          
          {/* Navigation & Turn-by-Turn GPS Button */}
          <button
            type="button"
            onClick={() => setIsNavDrawerOpen(!isNavDrawerOpen)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold shadow-md backdrop-blur-md transition-all ${
              isNavDrawerOpen
                ? 'bg-amber-400 text-stone-950 ring-2 ring-amber-300'
                : 'bg-white/95 text-[#2D2D2A] border border-[#DEDACF] hover:bg-[#F4F1EA]'
            }`}
          >
            <Navigation className="w-4 h-4 text-amber-600" />
            <span>Live Navigation & GPS</span>
          </button>

          <button
            onClick={toggleRouteSimulation}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold shadow-md backdrop-blur-md transition-all ${
              isSimulatingRoute
                ? 'bg-[#5A5A40] text-white ring-2 ring-[#8B8B6B]'
                : 'bg-white/95 text-[#2D2D2A] border border-[#DEDACF] hover:bg-[#F4F1EA]'
            }`}
            title="Connect all places to visualize travel route"
          >
            <Route className="w-4 h-4" />
            <span>{isSimulatingRoute ? 'Clear Path' : 'Connect Route'}</span>
          </button>

          {/* Real Satellite / Street View Toggle */}
          <div className="flex items-center bg-white/95 backdrop-blur-md p-1 rounded-2xl border border-[#DEDACF] shadow-md">
            <button
              onClick={() => handleTileChange('street')}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-colors ${
                mapType === 'street' ? 'bg-[#2D2D2A] text-white' : 'text-[#8B8B6B] hover:bg-[#F4F1EA]'
              }`}
            >
              Street
            </button>
            <button
              onClick={() => handleTileChange('satellite')}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 ${
                mapType === 'satellite' ? 'bg-[#2D2D2A] text-white' : 'text-[#8B8B6B] hover:bg-[#F4F1EA]'
              }`}
            >
              <span>Satellite</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Slide-out Turn-by-Turn GPS Navigation Panel */}
      {isNavDrawerOpen && (
        <div className="absolute top-16 right-3 z-30 w-full max-w-sm bg-white/95 backdrop-blur-md border border-[#DEDACF] rounded-3xl p-4 shadow-2xl space-y-3.5 animate-in slide-in-from-right-4 duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-[#F4F1EA]">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-amber-100 text-amber-800 rounded-xl">
                <Navigation className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-[#2D2D2A]">Turn-by-Turn Navigation</h4>
                <span className="text-[10px] text-emerald-700 font-semibold">Google Maps API Enabled</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsNavDrawerOpen(false)}
              className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Destination Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-[#5A5A40]">Navigate to Destination:</label>
            <select
              value={navDestinationId}
              onChange={(e) => setNavDestinationId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-[#FDFCF8] border border-[#DEDACF] text-xs font-bold text-[#2D2D2A] focus:outline-hidden"
            >
              {places.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.category})
                </option>
              ))}
            </select>
          </div>

          {/* Mode Selector */}
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'driving', label: 'Car 🚗', time: '8 mins' },
              { id: 'auto', label: 'Auto 🛺', time: '11 mins' },
              { id: 'walking', label: 'Walk 🚶', time: '22 mins' },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setNavMode(m.id as any)}
                className={`p-2 rounded-xl border text-center text-xs transition-all ${
                  navMode === m.id
                    ? 'bg-[#5A5A40] text-white border-[#5A5A40] font-bold'
                    : 'bg-[#FDFCF8] text-[#5A5A40] border-[#E5E2D9] hover:bg-[#F4F1EA]'
                }`}
              >
                <div>{m.label}</div>
                <div className="text-[10px] opacity-80 mt-0.5">{m.time}</div>
              </button>
            ))}
          </div>

          {/* Route Metric Summary */}
          {selectedDestPlace && (
            <div className="p-3 rounded-2xl bg-[#F4F1EA] border border-[#E5E2D9] space-y-1 text-xs">
              <div className="flex justify-between font-bold text-[#2D2D2A]">
                <span>Distance from Center:</span>
                <span>~2.4 km</span>
              </div>
              <div className="flex justify-between text-[#5A5A40] text-[11px]">
                <span>Destination Address:</span>
                <span className="truncate max-w-[170px]">{selectedDestPlace.address}</span>
              </div>
            </div>
          )}

          {/* Launch Real Google Maps GPS Navigation */}
          {selectedDestPlace && (
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${selectedDestPlace.coordinates.lat},${selectedDestPlace.coordinates.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all text-decoration-none cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open in Google Maps (Live Turn-by-Turn GPS)</span>
            </a>
          )}
        </div>
      )}

      {/* Floating Bottom Quick Place Drawer */}
      <div className="absolute bottom-4 left-4 right-4 z-10 pointer-events-none">
        <div className="bg-white/95 backdrop-blur-md border border-[#E5E2D9] rounded-3xl p-3 shadow-xl max-w-4xl mx-auto pointer-events-auto">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#F4F1EA] text-xs">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#5A5A40]" />
              <span className="font-serif font-bold text-[#2D2D2A]">
                {city.name} Waypoints ({filteredPlaces.length + filteredEvents.length} Pins)
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-[#8B8B6B]">
              <span className="hidden sm:inline">Google Maps Platform Active</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
          </div>

          {/* Horizontal scrollable quick cards */}
          <div className="flex gap-2.5 overflow-x-auto pb-1.5 scrollbar-thin">
            {filteredPlaces.map((p) => {
              const isActive = activePlace?.id === p.id;
              return (
                <div
                  key={`drawer-pl-${p.id}`}
                  onClick={() => onSelectPlace(p)}
                  className={`flex items-center gap-2.5 p-2 rounded-2xl border shrink-0 w-64 cursor-pointer transition-all ${
                    isActive
                      ? 'bg-[#F4F1EA] border-[#5A5A40] ring-2 ring-[#5A5A40]/30 shadow-xs'
                      : 'bg-[#FDFCF8] hover:bg-[#F4F1EA] border-[#E5E2D9]'
                  }`}
                >
                  <img
                    src={p.image}
                    alt={p.name}
                    className="w-12 h-12 rounded-xl object-cover shrink-0"
                  />
                  <div className="truncate flex-1 min-w-0">
                    <span className="text-[9px] font-bold text-[#5A5A40] uppercase block">
                      {p.category}
                    </span>
                    <h5 className="font-bold text-xs text-[#2D2D2A] truncate leading-tight">
                      {p.name}
                    </h5>
                    <div className="flex items-center justify-between text-[10px] mt-1">
                      <span className="font-semibold text-[#2D2D2A]">
                        {p.ticket.isFree ? 'Free' : `${p.ticket.currency}${p.ticket.generalPrice}`}
                      </span>
                      <span className="text-[#8B8B6B] font-bold">⭐ {p.rating}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
