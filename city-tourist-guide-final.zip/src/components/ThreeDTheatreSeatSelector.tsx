import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Eye, RotateCcw, Sparkles, SlidersHorizontal, Info } from 'lucide-react';

interface ThreeDTheatreSeatSelectorProps {
  movieTitle: string;
  showtime: string;
  screenType: string;
  theatreName: string;
  selectedSeats: string[];
  onToggleSeat: (seatId: string) => void;
  basePrice: number;
}

interface SeatNode {
  id: string;
  row: string;
  col: number;
  tier: 'Recliner' | 'Gold' | 'Silver';
  price: number;
  status: 'available' | 'selected' | 'booked';
  x: number;
  y: number;
  z: number;
  mesh?: THREE.Group;
}

export const ThreeDTheatreSeatSelector: React.FC<ThreeDTheatreSeatSelectorProps> = ({
  movieTitle,
  showtime,
  screenType,
  theatreName,
  selectedSeats,
  onToggleSeat,
  basePrice,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());
  const seatsRef = useRef<SeatNode[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const targetCamPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 9, 21));
  const targetCamLookRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 3, 0));

  const [hoveredSeat, setHoveredSeat] = useState<SeatNode | null>(null);
  const [isViewFromSeat, setIsViewFromSeat] = useState(false);
  const [seatViewId, setSeatViewId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'3d' | '2d'>('3d');

  // Rows and seat configuration
  const rows = ['A', 'B', 'C', 'D', 'E'];
  const cols = [1, 2, 3, 4, 5, 6, 7, 8];

  // Initialize Seat Grid
  const initializeSeats = (): SeatNode[] => {
    const list: SeatNode[] = [];
    rows.forEach((row, rIdx) => {
      let tier: 'Recliner' | 'Gold' | 'Silver' = 'Silver';
      let price = basePrice;

      if (row === 'A' || row === 'B') {
        tier = 'Recliner';
        price = basePrice + 120;
      } else if (row === 'C' || row === 'D') {
        tier = 'Gold';
        price = basePrice + 50;
      } else {
        tier = 'Silver';
        price = basePrice;
      }

      cols.forEach((c) => {
        const seatId = `${row}${c}`;
        const isOccupied = (row === 'B' && c === 3) || (row === 'D' && c === 6);
        const isSelected = selectedSeats.includes(seatId);

        // Position coordinates in 3D space
        const xOffset = (c - (cols.length + 1) / 2) * 1.55;
        const zOffset = 13 - rIdx * 2.5;
        const yOffset = (rows.length - rIdx) * 0.72 + 0.3;

        list.push({
          id: seatId,
          row,
          col: c,
          tier,
          price,
          status: isOccupied ? 'booked' : isSelected ? 'selected' : 'available',
          x: xOffset,
          y: yOffset,
          z: zOffset,
        });
      });
    });
    return list;
  };

  // Build 3D Cinema Hall with Three.js
  useEffect(() => {
    if (viewMode !== '3d' || !mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth || 640;
    const height = container.clientHeight || 420;

    // Detect software rendering guard
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch (e) {
        return true;
      }
    })();

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c0c10);
    scene.fog = new THREE.FogExp2(0x0c0c10, 0.024);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.set(0, 9, 21);
    camera.lookAt(0, 3, 0);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: !isSoftwareGl, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.replaceChildren(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x231d28, 1.2);
    scene.add(ambientLight);

    const ceilingLight = new THREE.DirectionalLight(0xfff0e0, 1.1);
    ceilingLight.position.set(0, 16, 8);
    scene.add(ceilingLight);

    // Overhead Projector Light Beam
    const projectorLight = new THREE.SpotLight(0xa5d8ff, 14, 45, Math.PI / 7, 0.45);
    projectorLight.position.set(0, 12, 26);
    projectorLight.target.position.set(0, 4, -4);
    scene.add(projectorLight);
    scene.add(projectorLight.target);

    // Screen Glow Light
    const screenGlowLight = new THREE.PointLight(0x38bdf8, 3.8, 22);
    screenGlowLight.position.set(0, 4, -2);
    scene.add(screenGlowLight);

    // 5. Curved 3D Silver Screen
    const screenGeo = new THREE.CylinderGeometry(22, 22, 8.5, 32, 1, true, -Math.PI / 7.5, (2 * Math.PI) / 7.5);
    const screenCanvas = document.createElement('canvas');
    screenCanvas.width = 1024;
    screenCanvas.height = 512;
    const ctx = screenCanvas.getContext('2d');
    if (ctx) {
      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, 1024, 512);
      grad.addColorStop(0, '#0a0914');
      grad.addColorStop(0.5, '#241432');
      grad.addColorStop(1, '#0c1b33');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1024, 512);

      // Gold screen border
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 12;
      ctx.strokeRect(18, 18, 988, 476);

      // Movie title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 44px sans-serif';
      ctx.textAlign = 'center';
      const cleanTitle = (movieTitle || 'NOW SHOWING').toUpperCase();
      ctx.fillText(cleanTitle.length > 24 ? cleanTitle.substring(0, 22) + '...' : cleanTitle, 512, 200);

      // Screen format
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 26px sans-serif';
      ctx.fillText(`⚡ ${screenType || '4K LASER DOLBY ATMOS'}`, 512, 260);

      // Showtime
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '22px sans-serif';
      ctx.fillText(`SHOWTIME: ${showtime || '06:30 PM'} · ${theatreName || 'CINEMA'}`, 512, 320);
    }

    const screenTexture = new THREE.CanvasTexture(screenCanvas);
    screenTexture.colorSpace = THREE.SRGBColorSpace;
    const screenMat = new THREE.MeshStandardMaterial({
      map: screenTexture,
      roughness: 0.25,
      metalness: 0.1,
      emissive: new THREE.Color(0x1a2638),
      emissiveIntensity: 0.8,
      side: THREE.DoubleSide,
    });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.set(0, 4.2, -4);
    screenMesh.rotation.y = Math.PI;
    scene.add(screenMesh);

    // Screen Frames
    const frameGeo = new THREE.BoxGeometry(20, 0.4, 0.7);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x1f1f23, roughness: 0.7 });
    const topFrame = new THREE.Mesh(frameGeo, frameMat);
    topFrame.position.set(0, 8.6, -4);
    scene.add(topFrame);
    const bottomFrame = new THREE.Mesh(frameGeo, frameMat);
    bottomFrame.position.set(0, -0.2, -4);
    scene.add(bottomFrame);

    // 6. Auditorium Tiered Steps
    for (let i = 0; i < rows.length + 2; i++) {
      const stepWidth = 18;
      const stepDepth = 2.6;
      const stepHeight = 0.72;
      const stepGeo = new THREE.BoxGeometry(stepWidth, stepHeight, stepDepth);
      const stepMat = new THREE.MeshStandardMaterial({
        color: i % 2 === 0 ? 0x16131c : 0x121016,
        roughness: 0.9,
      });
      const stepMesh = new THREE.Mesh(stepGeo, stepMat);
      stepMesh.position.set(0, (rows.length - i) * 0.72, 13 - i * 2.5);
      scene.add(stepMesh);
    }

    // Aisle neon runner lights
    const aislePoints = [
      new THREE.Vector3(-8.2, 0.2, -2),
      new THREE.Vector3(-8.2, 5.0, 14),
      new THREE.Vector3(8.2, 0.2, -2),
      new THREE.Vector3(8.2, 5.0, 14),
    ];
    aislePoints.forEach((pt) => {
      const led = new THREE.PointLight(0xf59e0b, 1.0, 3.5);
      led.position.copy(pt);
      scene.add(led);
    });

    // 7. Generate 3D Interactive Seats
    const seatList = initializeSeats();
    seatsRef.current = seatList;

    const matAvailableSilver = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.5 });
    const matAvailableGold = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.4 });
    const matAvailableRecliner = new THREE.MeshStandardMaterial({ color: 0x881337, roughness: 0.35 });
    const matSelected = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      roughness: 0.2,
      emissive: 0x064e3b,
      emissiveIntensity: 0.6,
    });
    const matBooked = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });

    seatList.forEach((seat) => {
      const seatGroup = new THREE.Group();
      (seatGroup as any).seatData = seat;

      let seatMat = matAvailableSilver;
      if (seat.status === 'selected') seatMat = matSelected;
      else if (seat.status === 'booked') seatMat = matBooked;
      else if (seat.tier === 'Recliner') seatMat = matAvailableRecliner;
      else if (seat.tier === 'Gold') seatMat = matAvailableGold;

      // Cushion
      const cushionGeo = new THREE.BoxGeometry(0.85, 0.24, 0.8);
      const cushion = new THREE.Mesh(cushionGeo, seatMat);
      cushion.position.y = 0.24;
      seatGroup.add(cushion);

      // Backrest
      const backGeo = new THREE.BoxGeometry(0.85, 0.9, 0.2);
      const back = new THREE.Mesh(backGeo, seatMat);
      back.position.set(0, 0.72, -0.3);
      back.rotation.x = -0.12;
      seatGroup.add(back);

      // Headrest
      const headGeo = new THREE.BoxGeometry(0.62, 0.32, 0.22);
      const head = new THREE.Mesh(headGeo, seatMat);
      head.position.set(0, 1.25, -0.38);
      seatGroup.add(head);

      // Armrests
      const armGeo = new THREE.BoxGeometry(0.12, 0.32, 0.65);
      const armMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6 });
      const leftArm = new THREE.Mesh(armGeo, armMat);
      leftArm.position.set(-0.48, 0.45, -0.04);
      const rightArm = new THREE.Mesh(armGeo, armMat);
      rightArm.position.set(0.48, 0.45, -0.04);
      seatGroup.add(leftArm);
      seatGroup.add(rightArm);

      seatGroup.position.set(seat.x, seat.y, seat.z);
      seatGroup.lookAt(0, 3, -4);
      seat.mesh = seatGroup;
      scene.add(seatGroup);
    });

    // 8. Robust 360° Hand Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.rotateSpeed = 0.95;
    controls.zoomSpeed = 1.1;
    controls.panSpeed = 0.8;
    controls.minDistance = 5;
    controls.maxDistance = 38;
    controls.maxPolarAngle = Math.PI / 2 + 0.05; // Keep camera above floor
    controls.minPolarAngle = 0.05;
    controls.target.set(0, 3.5, 0);
    controlsRef.current = controls;

    // Distinguish genuine click (tap seat) from 360° rotation drag
    let pointerDownPos = { x: 0, y: 0 };
    let pointerDownTime = 0;

    const handlePointerDown = (e: PointerEvent) => {
      pointerDownPos = { x: e.clientX, y: e.clientY };
      pointerDownTime = performance.now();
    };

    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      // Hover detection
      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      const intersects = raycasterRef.current.intersectObjects(scene.children, true);

      let foundSeat: SeatNode | null = null;
      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && curr !== scene) {
          if ((curr as any).seatData) {
            foundSeat = (curr as any).seatData;
            break;
          }
          curr = curr.parent;
        }
        if (foundSeat) break;
      }
      setHoveredSeat(foundSeat);
    };

    const handlePointerUp = (e: PointerEvent) => {
      const dist = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
      const duration = performance.now() - pointerDownTime;

      // If user dragged more than 7px or held longer than 450ms, it was a 360° hand rotation drag, NOT a seat tap!
      if (dist > 7 || duration > 450) return;

      const rect = container.getBoundingClientRect();
      mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      const intersects = raycasterRef.current.intersectObjects(scene.children, true);

      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && curr !== scene) {
          if ((curr as any).seatData) {
            const seat = (curr as any).seatData as SeatNode;
            if (seat.status !== 'booked') {
              onToggleSeat(seat.id);
            }
            return;
          }
          curr = curr.parent;
        }
      }
    };

    container.addEventListener('pointerdown', handlePointerDown);
    container.addEventListener('pointermove', handlePointerMove);
    container.addEventListener('pointerup', handlePointerUp);

    // 9. Continuous Smooth Render Loop with OrbitControls Update
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // 10. Robust ResizeObserver (guarantees pixel-perfect sizing on open & resize)
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      controls.dispose();
      container.removeEventListener('pointerdown', handlePointerDown);
      container.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('pointerup', handlePointerUp);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
    };
  }, [viewMode, movieTitle, showtime, screenType, theatreName]);

  // Sync Seat Colors on Selection Change
  useEffect(() => {
    if (!sceneRef.current || viewMode !== '3d') return;

    seatsRef.current.forEach((seat) => {
      const isSelected = selectedSeats.includes(seat.id);
      if (!seat.mesh) return;

      const newStatus = seat.status === 'booked' ? 'booked' : isSelected ? 'selected' : 'available';
      seat.status = newStatus;

      let targetColor = 0x475569;
      let emissiveColor = 0x000000;
      let emissiveIntensity = 0;

      if (newStatus === 'selected') {
        targetColor = 0x10b981;
        emissiveColor = 0x064e3b;
        emissiveIntensity = 0.6;
      } else if (newStatus === 'booked') {
        targetColor = 0x1e293b;
      } else if (seat.tier === 'Recliner') {
        targetColor = 0x881337;
      } else if (seat.tier === 'Gold') {
        targetColor = 0xb45309;
      }

      seat.mesh.traverse((child) => {
        if ((child as THREE.Mesh).isMesh && (child as THREE.Mesh).material) {
          const mat = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
          if (mat.name !== 'armrest') {
            mat.color.setHex(targetColor);
            if (mat.emissive) {
              mat.emissive.setHex(emissiveColor);
              mat.emissiveIntensity = emissiveIntensity;
            }
          }
        }
      });
    });
  }, [selectedSeats, viewMode]);

  // Preview View From Seat
  const handlePreviewViewFromSeat = (seatId: string) => {
    const seat = seatsRef.current.find((s) => s.id === seatId);
    if (!seat || !cameraRef.current || !controlsRef.current) return;

    setIsViewFromSeat(true);
    setSeatViewId(seatId);

    // Camera placed directly at seat eye-level, target focused on screen center
    cameraRef.current.position.set(seat.x, seat.y + 1.15, seat.z - 0.1);
    controlsRef.current.target.set(0, 4.2, -4);
    controlsRef.current.update();
  };

  const handleResetCamera = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    setIsViewFromSeat(false);
    setSeatViewId(null);
    cameraRef.current.position.set(0, 9, 21);
    controlsRef.current.target.set(0, 3.5, 0);
    controlsRef.current.update();
  };

  return (
    <div className="bg-[#1e1e24] border border-stone-800 rounded-3xl overflow-hidden shadow-2xl text-white space-y-3 p-3 sm:p-4">
      {/* Top Header & Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-stone-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-serif font-bold text-sm text-white">
                Real 3D Theatre Seat Selection
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Interactive 3D
              </span>
            </div>
            <p className="text-[11px] text-stone-400">
              Drag to look around in 360°, tap any seat to reserve, or preview your exact view of the screen
            </p>
          </div>
        </div>

        {/* 3D / 2D Mode Switcher */}
        <div className="flex items-center bg-stone-900 border border-stone-700 rounded-xl p-1 text-xs self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setViewMode('3d')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              viewMode === '3d'
                ? 'bg-amber-400 text-stone-950 shadow-sm'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            Real 3D Hall
          </button>
          <button
            type="button"
            onClick={() => setViewMode('2d')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              viewMode === '2d'
                ? 'bg-amber-400 text-stone-950 shadow-sm'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            2D Grid
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas Viewport */}
      {viewMode === '3d' ? (
        <div className="relative w-full h-80 sm:h-96 rounded-2xl overflow-hidden bg-black border border-stone-800">
          <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing touch-none select-none" />

          {/* Floating Camera Control Pill */}
          <div className="absolute top-2.5 left-3 z-10 flex items-center gap-2">
            {isViewFromSeat ? (
              <button
                type="button"
                onClick={handleResetCamera}
                className="px-3 py-1 rounded-xl bg-stone-900/90 hover:bg-stone-800 border border-stone-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg backdrop-blur-md transition-all cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                <span>Return to Auditorium View</span>
              </button>
            ) : (
              <div className="px-2.5 py-1 rounded-xl bg-stone-900/80 border border-stone-800 text-stone-300 text-[11px] flex items-center gap-1.5 backdrop-blur-md">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Swipe / Drag to rotate in 360° · Tap to select seat</span>
              </div>
            )}
          </div>

          {/* Hovered Seat Tooltip */}
          {hoveredSeat && (
            <div className="absolute top-2.5 right-3 z-10 px-3 py-1.5 rounded-xl bg-stone-900/95 border border-stone-700 text-xs shadow-xl backdrop-blur-md pointer-events-none">
              <span className="font-bold text-white">Seat {hoveredSeat.id}</span>
              <span className="text-amber-400 ml-1.5 font-bold">₹{hoveredSeat.price}</span>
              <span className="text-stone-400 text-[10px] ml-1.5 uppercase font-semibold">({hoveredSeat.tier})</span>
            </div>
          )}

          {/* Bottom Screen Banner Marker */}
          <div className="absolute bottom-2 inset-x-0 text-center pointer-events-none">
            <span className="px-3 py-1 rounded-full bg-stone-900/80 border border-stone-700 text-[10px] uppercase font-mono tracking-wider text-stone-300">
              ⚡ Curved Glowing Silver 3D Screen Ahead
            </span>
          </div>
        </div>
      ) : (
        /* 2D Plan View Fallback */
        <div className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
          <div className="space-y-1 text-center">
            <div className="h-1.5 w-3/4 mx-auto bg-gradient-to-r from-transparent via-amber-400 to-transparent rounded-full shadow-md" />
            <span className="text-[10px] uppercase tracking-widest text-stone-400">All Eyes This Way · Cinema Screen</span>
          </div>

          <div className="space-y-2 pt-2">
            {rows.map((row) => {
              const isVipRow = row === 'A' || row === 'B';
              const isGoldRow = row === 'C' || row === 'D';
              const tierName = isVipRow ? 'Recliner (+₹120)' : isGoldRow ? 'Gold (+₹50)' : 'Silver';

              return (
                <div key={row} className="flex items-center justify-between gap-1 text-xs">
                  <span className="w-6 font-bold text-stone-400 text-center">{row}</span>
                  <div className="flex items-center justify-center gap-1.5 flex-1">
                    {cols.map((col) => {
                      const seatId = `${row}${col}`;
                      const isSelected = selectedSeats.includes(seatId);
                      const isOccupied = (row === 'B' && col === 3) || (row === 'D' && col === 6);

                      return (
                        <button
                          key={col}
                          type="button"
                          disabled={isOccupied}
                          onClick={() => onToggleSeat(seatId)}
                          className={`w-7 h-7 rounded-lg text-[10px] font-bold flex items-center justify-center transition-all ${
                            isOccupied
                              ? 'bg-stone-800 text-stone-600 cursor-not-allowed'
                              : isSelected
                              ? 'bg-emerald-500 text-white scale-110 shadow-md ring-2 ring-emerald-300 font-extrabold'
                              : isVipRow
                              ? 'bg-rose-950/70 text-rose-200 border border-rose-800/60 hover:bg-rose-800'
                              : isGoldRow
                              ? 'bg-amber-950/70 text-amber-200 border border-amber-800/60 hover:bg-amber-800'
                              : 'bg-stone-800 text-stone-300 hover:bg-stone-700 border border-stone-700'
                          }`}
                        >
                          {col}
                        </button>
                      );
                    })}
                  </div>
                  <span className="text-[10px] text-stone-400 w-24 text-right hidden sm:inline">{tierName}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Seat Selection Dock & "Preview View from Seat" trigger */}
      <div className="p-3 bg-stone-900 rounded-2xl border border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-stone-400 text-xs">Selected Seats:</span>
          {selectedSeats.length > 0 ? (
            selectedSeats.map((s) => (
              <span key={s} className="px-2 py-0.5 rounded-md bg-emerald-500 text-white font-extrabold text-[11px]">
                {s}
              </span>
            ))
          ) : (
            <span className="text-amber-400 font-semibold text-xs">Tap any seat in 3D to select</span>
          )}
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {selectedSeats.length > 0 && viewMode === '3d' && (
            <button
              type="button"
              onClick={() => handlePreviewViewFromSeat(selectedSeats[0])}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-amber-400" />
              <span>Preview View from Seat {selectedSeats[0]}</span>
            </button>
          )}

          {/* Tiers Legend */}
          <div className="flex items-center gap-2.5 text-[10px] text-stone-400">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-rose-900" /> Recliner</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-amber-800" /> Gold</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-slate-700" /> Silver</span>
          </div>
        </div>
      </div>
    </div>
  );
};
