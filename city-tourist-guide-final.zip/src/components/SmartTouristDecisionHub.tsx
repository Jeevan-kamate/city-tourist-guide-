import React, { useState, useMemo } from 'react';
import { 
  Compass, 
  HelpCircle, 
  DollarSign, 
  Navigation, 
  Clock, 
  ShieldAlert, 
  Sparkles, 
  MapPin, 
  Car, 
  Footprints, 
  Bus, 
  PhoneCall, 
  AlertCircle, 
  CheckCircle2, 
  Heart, 
  UtensilsCrossed, 
  Film, 
  Landmark, 
  ArrowRight, 
  ChevronRight,
  TrendingDown,
  Volume2,
  Copy,
  Check,
  Languages
} from 'lucide-react';
import { City, Place } from '../types';

interface SmartTouristDecisionHubProps {
  city: City;
  places: Place[];
  onSelectPlace: (place: Place) => void;
  onNavigateToPlace: (place: Place) => void;
  onOpenBookings: () => void;
}

type DecisionTab = 'where' | 'nearby' | 'cost' | 'travel' | 'suitability' | 'emergency';

export const SmartTouristDecisionHub: React.FC<SmartTouristDecisionHubProps> = ({
  city,
  places,
  onSelectPlace,
  onNavigateToPlace,
  onOpenBookings,
}) => {
  const [activeTab, setActiveTab] = useState<DecisionTab>('where');

  // 1. Where should I go states
  const [selectedVibe, setSelectedVibe] = useState<'spiritual' | 'foodie' | 'movies' | 'nature' | 'heritage' | 'family'>('spiritual');

  // 2. What can I do nearby states
  const [selectedRadius, setSelectedRadius] = useState<'walk' | 'auto' | 'drive'>('walk');

  // 3. How much will trip cost states
  const [travelersCount, setTravelersCount] = useState(2);
  const [travelMode, setTravelMode] = useState<'auto' | 'cab' | 'bus' | 'walk'>('auto');
  const [diningStyle, setDiningStyle] = useState<'street' | 'standard' | 'fine'>('standard');
  const [includeCinema, setIncludeCinema] = useState(true);
  const [includeVipDarshan, setIncludeVipDarshan] = useState(false);

  // 5. Suitability filter states
  const [budgetCap, setBudgetCap] = useState<'budget' | 'medium' | 'premium'>('medium');
  const [timeAvailable, setTimeAvailable] = useState<'2hr' | '5hr' | 'fullday'>('5hr');

  // 6. Emergency copied state
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Vibe filtered places
  const vibeRecommendations = useMemo(() => {
    if (selectedVibe === 'spiritual') {
      return places.filter((p) => p.category === 'temple');
    } else if (selectedVibe === 'foodie') {
      return places.filter((p) => p.category === 'restaurant');
    } else if (selectedVibe === 'movies') {
      return places.filter((p) => p.category === 'theatre');
    } else if (selectedVibe === 'nature' || selectedVibe === 'heritage') {
      return places.filter((p) => p.category === 'attraction');
    } else {
      return places.slice(0, 4);
    }
  }, [places, selectedVibe]);

  // Nearby distance simulation
  const nearbyPlaces = useMemo(() => {
    return places.map((p, idx) => {
      // Mock realistic proximity
      const distanceKm = Number((0.6 + idx * 1.2).toFixed(1));
      let walkingMins = Math.round(distanceKm * 13);
      let autoMins = Math.round(distanceKm * 3.5) + 2;
      return {
        ...p,
        distanceKm,
        walkingMins,
        autoMins,
      };
    }).filter((p) => {
      if (selectedRadius === 'walk') return p.distanceKm <= 2.2;
      if (selectedRadius === 'auto') return p.distanceKm <= 6.0;
      return true;
    });
  }, [places, selectedRadius]);

  // Trip Cost Calculation
  const costBreakdown = useMemo(() => {
    let transportCost = travelMode === 'walk' ? 0 : travelMode === 'bus' ? 30 * travelersCount : travelMode === 'auto' ? 180 : 450;
    let foodPerHead = diningStyle === 'street' ? 120 : diningStyle === 'standard' ? 280 : 650;
    let foodCost = foodPerHead * travelersCount;

    let ticketsCost = 0;
    if (includeCinema) ticketsCost += 250 * travelersCount;
    if (includeVipDarshan) ticketsCost += 200 * travelersCount;
    // Add default attraction entry
    ticketsCost += 50 * travelersCount;

    const total = transportCost + foodCost + ticketsCost;
    const perPerson = Math.round(total / travelersCount);

    return {
      transportCost,
      foodCost,
      ticketsCost,
      total,
      perPerson,
    };
  }, [travelersCount, travelMode, diningStyle, includeCinema, includeVipDarshan]);

  // Dynamic top places for the active city
  const topRestaurant = useMemo(() => places.find((p) => p.category === 'restaurant'), [places]);
  const topFoodName = useMemo(() => {
    return topRestaurant?.topDishes?.[0]?.name || topRestaurant?.name?.split(' ')[0] || (city.highlights?.[0] ? city.highlights[0] : 'Famous Local Delicacy');
  }, [topRestaurant, city]);

  const topTemple = useMemo(() => places.find((p) => p.category === 'temple'), [places]);
  const topTempleName = useMemo(() => {
    return topTemple?.name || `${city.name} Historical Shrines`;
  }, [topTemple, city]);

  const topTheatre = useMemo(() => places.find((p) => p.category === 'theatre'), [places]);
  const topTheatreName = useMemo(() => {
    return topTheatre?.name || `${city.name} Central Cinemas`;
  }, [topTheatre, city]);

  const topAttraction = useMemo(() => places.find((p) => p.category === 'attraction'), [places]);
  const topAttractionName = useMemo(() => {
    return topAttraction?.name || (city.highlights?.[1] || `${city.name} Sightseeing Landmark`);
  }, [topAttraction, city]);

  const secondAttraction = useMemo(() => {
    const list = places.filter((p) => p.category === 'attraction');
    return list[1]?.name || list[0]?.name || (city.highlights?.[2] || `${city.name} Viewpoint`);
  }, [places, city]);

  // Local Phrase Guide for Travelers
  const phrases = [
    { kannada: 'ನಮಸ್ಕಾರ (Namaskara)', english: 'Hello / Greetings', usage: 'Polite greeting to anyone' },
    { kannada: 'ಇದರ ಬೆಲೆ ಎಷ್ಟು? (Idara bele eshtu?)', english: 'How much does this cost?', usage: 'At shops, autos, ticket counters' },
    { kannada: 'ಪ್ರಸಿದ್ಧ ಊಟ ಎಲ್ಲಿ ಸಿಗುತ್ತೆ? (Prasiddha oota elli siguthe?)', english: `Where do I get famous ${topFoodName}?`, usage: 'Asking locals for food spots' },
    { kannada: 'ದಯವಿಟ್ಟು ಸಹಾಯ ಮಾಡಿ (Dayavittu sahayamaadi)', english: 'Please help me', usage: 'In any emergency or navigation doubt' },
    { kannada: 'ಮೀಟರ್ ಹಾಕಿ ಹೋಗಿ (Meter haaki hogi)', english: 'Please run the auto-rickshaw meter', usage: 'Hailing auto-rickshaws' },
    { kannada: 'ಧನ್ಯವಾದಗಳು (Dhanyavaadagalu)', english: 'Thank you very much', usage: 'Showing polite gratitude' },
  ];

  return (
    <div id="smart-tourist-decision-hub" className="bg-white rounded-3xl border border-[#E5E2D9] shadow-md overflow-hidden">
      
      {/* Header Bar */}
      <div className="p-5 sm:p-6 bg-gradient-to-r from-[#2D2D2A] via-[#3F3F3A] to-[#5A5A40] text-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-400/30 flex items-center justify-center text-amber-300">
              <Compass className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif font-bold text-lg sm:text-xl text-white">
                  Smart Tourist Decision Engine
                </h3>
              </div>
              <p className="text-xs text-[#DEDACF] mt-0.5">
                Answers all 6 essential travel decisions for {city.name}: Where to go, nearby spots, exact trip cost, transit, tailored fit & safety help.
              </p>
            </div>
          </div>
        </div>

        {/* 6 Decision Navigation Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5 mt-5 pt-4 border-t border-white/10 text-xs">
          {[
            { id: 'where', label: '1. Where to Go?', icon: Compass },
            { id: 'nearby', label: '2. What\'s Nearby?', icon: MapPin },
            { id: 'cost', label: '3. Trip Cost ₹', icon: DollarSign },
            { id: 'travel', label: '4. How to Travel?', icon: Car },
            { id: 'suitability', label: '5. Match Time & Budget', icon: Clock },
            { id: 'emergency', label: '6. Need Help? (SOS)', icon: ShieldAlert },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as DecisionTab)}
                className={`p-2.5 rounded-2xl font-bold flex flex-col sm:flex-row items-center sm:items-start gap-1.5 transition-all cursor-pointer text-center sm:text-left ${
                  isActive
                    ? 'bg-amber-400 text-stone-950 shadow-md scale-[1.02]'
                    : 'bg-white/10 hover:bg-white/15 text-stone-200'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-stone-950' : 'text-amber-300'}`} />
                <span className="text-[11px] leading-tight">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-5 sm:p-6 bg-[#FDFCF8]">
        
        {/* ========================================================= */}
        {/* QUESTION 1: WHERE SHOULD I GO? */}
        {/* ========================================================= */}
        {activeTab === 'where' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E2D9]">
              <div>
                <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                  Where should I go in {city.name}?
                </h4>
                <p className="text-xs text-[#8B8B6B]">
                  Tell us what kind of experience you are in the mood for, and we will match the best destinations.
                </p>
              </div>

              {/* Vibe Chips */}
              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: 'spiritual', label: 'Spiritual & Peaceful 🛕' },
                  { id: 'foodie', label: 'Iconic Foodie Trail 🍛' },
                  { id: 'movies', label: 'Cinema & 3D Theatres 🎬' },
                  { id: 'nature', label: 'Scenic Lakes & Sunsets 🌅' },
                  { id: 'heritage', label: 'Heritage & Forts 🏛️' },
                  { id: 'family', label: 'Family & Relaxation 👨‍👩‍👦' },
                ].map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => setSelectedVibe(v.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedVibe === v.id
                        ? 'bg-[#5A5A40] text-white shadow-xs'
                        : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                    }`}
                  >
                    {v.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Recommendations Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {vibeRecommendations.map((p) => (
                <div
                  key={p.id}
                  className="p-4 rounded-2xl bg-white border border-[#E5E2D9] shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    <div className="relative h-32 rounded-xl overflow-hidden bg-stone-100">
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-[#2D2D2A]/90 text-white">
                        {p.category}
                      </span>
                      <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md text-[10px] font-bold bg-white text-stone-900 shadow-sm">
                        ⭐ {p.rating}
                      </span>
                    </div>

                    <div>
                      <h5 className="font-bold text-sm text-[#2D2D2A] line-clamp-1">{p.name}</h5>
                      <p className="text-xs text-[#8B8B6B] mt-0.5 line-clamp-2">{p.tagline || p.description}</p>
                    </div>

                    {p.crowd && (
                      <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-800">
                        <strong>Best Low-Crowd Hour:</strong> {p.crowd.leastCrowdHours}
                      </div>
                    )}
                  </div>

                  <div className="pt-3 mt-3 border-t border-[#F4F1EA] flex items-center justify-between gap-2">
                    <span className="font-bold text-xs text-[#2D2D2A]">
                      {p.ticket.isFree ? 'FREE ENTRY' : `${p.ticket.currency}${p.ticket.generalPrice}`}
                    </span>
                    <button
                      type="button"
                      onClick={() => onSelectPlace(p)}
                      className="px-3 py-1.5 rounded-xl bg-[#5A5A40] hover:bg-[#484832] text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>Explore Spot</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* QUESTION 2: WHAT CAN I DO NEARBY? */}
        {/* ========================================================= */}
        {activeTab === 'nearby' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E2D9]">
              <div>
                <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                  What can I do nearby right now?
                </h4>
                <p className="text-xs text-[#8B8B6B]">
                  Discover spots within comfortable walking or quick auto distance from city center.
                </p>
              </div>

              <div className="flex items-center gap-1.5 bg-[#F4F1EA] p-1 rounded-2xl border border-[#DEDACF]">
                <button
                  type="button"
                  onClick={() => setSelectedRadius('walk')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedRadius === 'walk' ? 'bg-[#5A5A40] text-white shadow-2xs' : 'text-[#5A5A40]'
                  }`}
                >
                  🚶 &lt; 2 km (Walking)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRadius('auto')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedRadius === 'auto' ? 'bg-[#5A5A40] text-white shadow-2xs' : 'text-[#5A5A40]'
                  }`}
                >
                  🛺 &lt; 6 km (Short Auto)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedRadius('drive')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedRadius === 'drive' ? 'bg-[#5A5A40] text-white shadow-2xs' : 'text-[#5A5A40]'
                  }`}
                >
                  🚗 All District
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {nearbyPlaces.map((p) => (
                <div
                  key={p.id}
                  className="p-3.5 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between gap-3 shadow-2xs hover:shadow-sm transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img src={p.image} alt={p.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                    <div className="truncate min-w-0">
                      <span className="text-[10px] font-bold text-[#5A5A40] uppercase">
                        {p.category} · {p.timings.currentStatus}
                      </span>
                      <h5 className="font-bold text-sm text-[#2D2D2A] truncate">{p.name}</h5>
                      <div className="flex items-center gap-3 text-xs text-[#8B8B6B] mt-1">
                        <span className="flex items-center gap-1 text-[#2D2D2A] font-bold">
                          <MapPin className="w-3.5 h-3.5 text-amber-600" /> {p.distanceKm} km
                        </span>
                        <span>🚶 {p.walkingMins} mins</span>
                        <span>🛺 {p.autoMins} mins</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onNavigateToPlace(p)}
                      className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Directions</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectPlace(p)}
                      className="px-3 py-1 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#5A5A40] text-[11px] font-bold transition-colors cursor-pointer"
                    >
                      Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* QUESTION 3: HOW MUCH WILL THE TRIP COST? */}
        {/* ========================================================= */}
        {activeTab === 'cost' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="pb-3 border-b border-[#E5E2D9]">
              <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                How much will a day trip in {city.name} cost?
              </h4>
              <p className="text-xs text-[#8B8B6B]">
                Interactive cost calculator customized to your party size, dining style, transport, and passes.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Controls Column */}
              <div className="lg:col-span-2 space-y-4">
                
                {/* Party Size Slider */}
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-2">
                  <div className="flex justify-between items-center text-xs font-bold text-[#2D2D2A]">
                    <span>Number of Travelers:</span>
                    <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 font-extrabold text-sm">
                      {travelersCount} Person{travelersCount > 1 ? 's' : ''}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="8"
                    value={travelersCount}
                    onChange={(e) => setTravelersCount(Number(e.target.value))}
                    className="w-full accent-[#5A5A40] cursor-pointer"
                  />
                </div>

                {/* Transport Mode */}
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-2">
                  <span className="text-xs font-bold text-[#2D2D2A] block">Travel Mode:</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'auto', label: '🛺 Auto-rickshaw', desc: '₹180 avg' },
                      { id: 'cab', label: '🚕 Local Cab', desc: '₹450 avg' },
                      { id: 'bus', label: '🚌 Local Bus', desc: '₹30/head' },
                      { id: 'walk', label: '🚶 Walking Tour', desc: '₹0 Free' },
                    ].map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setTravelMode(m.id as any)}
                        className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                          travelMode === m.id
                            ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                            : 'bg-[#FDFCF8] text-[#3D3D3D] border-[#E5E2D9] hover:bg-[#F4F1EA]'
                        }`}
                      >
                        <div className="font-bold">{m.label}</div>
                        <div className="text-[10px] opacity-80">{m.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Dining Style */}
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-2">
                  <span className="text-xs font-bold text-[#2D2D2A] block">Dining Preference:</span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'street', label: `${topFoodName} & Local Street Chaat`, price: '₹120 / person' },
                      { id: 'standard', label: 'Traditional Regional Meals & Cafes', price: '₹280 / person' },
                      { id: 'fine', label: 'Royal Thali & Specialty Dining', price: '₹650 / person' },
                    ].map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => setDiningStyle(d.id as any)}
                        className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                          diningStyle === d.id
                            ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                            : 'bg-[#FDFCF8] text-[#3D3D3D] border-[#E5E2D9] hover:bg-[#F4F1EA]'
                        }`}
                      >
                        <div className="font-bold leading-tight">{d.label}</div>
                        <div className="text-[10px] opacity-80 mt-1">{d.price}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Optional Experiences */}
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] flex flex-wrap gap-4 text-xs font-bold">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeCinema}
                      onChange={(e) => setIncludeCinema(e.target.checked)}
                      className="accent-[#5A5A40] w-4 h-4 rounded"
                    />
                    <span>Include 4K Laser Cinema Movie Ticket (₹250/head)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeVipDarshan}
                      onChange={(e) => setIncludeVipDarshan(e.target.checked)}
                      className="accent-[#5A5A40] w-4 h-4 rounded"
                    />
                    <span>Include Temple VIP Line Bypass Token (₹200/head)</span>
                  </label>
                </div>
              </div>

              {/* Total Calculation Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-[#2D2D2A] to-[#1C1C1A] text-white space-y-4 flex flex-col justify-between shadow-xl border border-stone-800">
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                    <span className="text-xs text-stone-400 font-bold uppercase tracking-wider">Estimated Total</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300">
                      Accurate Local Rates
                    </span>
                  </div>

                  <div className="text-center py-2">
                    <div className="text-3xl sm:text-4xl font-serif font-extrabold text-amber-300">
                      ₹{costBreakdown.total.toLocaleString()}
                    </div>
                    <div className="text-xs text-stone-400 mt-1">
                      (Approx. <strong className="text-white">₹{costBreakdown.perPerson}</strong> per person for {travelersCount} traveler{travelersCount > 1 ? 's' : ''})
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-stone-800 text-xs">
                    <div className="flex justify-between text-stone-400">
                      <span>🛺 Local Transport:</span>
                      <span className="font-bold text-white">₹{costBreakdown.transportCost}</span>
                    </div>
                    <div className="flex justify-between text-stone-400">
                      <span>🍛 Food & {topFoodName}:</span>
                      <span className="font-bold text-white">₹{costBreakdown.foodCost}</span>
                    </div>
                    <div className="flex justify-between text-stone-400">
                      <span>🎟️ Passes & Cinema Tickets:</span>
                      <span className="font-bold text-white">₹{costBreakdown.ticketsCost}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-800 space-y-2">
                  <p className="text-[11px] text-stone-400">
                    💡 <em>Tip: General entry at {topTempleName} is free. Budget accommodates authentic {topFoodName}.</em>
                  </p>
                  <button
                    type="button"
                    onClick={onOpenBookings}
                    className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>View Wallet & Pre-book Tickets</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* QUESTION 4: HOW CAN I TRAVEL BETWEEN PLACES? */}
        {/* ========================================================= */}
        {activeTab === 'travel' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="pb-3 border-b border-[#E5E2D9]">
              <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                How can I travel between places in {city.name}?
              </h4>
              <p className="text-xs text-[#8B8B6B]">
                Transit options, expected fares, routes, and tips for navigating the city without getting overcharged.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Option 1: Auto */}
              <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3 shadow-2xs">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center text-lg">
                  🛺
                </div>
                <div>
                  <h5 className="font-bold text-sm text-[#2D2D2A]">Local Auto-Rickshaws</h5>
                  <p className="text-xs text-[#8B8B6B] mt-0.5">Most convenient mode for short district hops</p>
                </div>
                <div className="space-y-1.5 text-xs text-[#5A5A40]">
                  <div className="flex justify-between">
                    <span>Base Fare:</span>
                    <strong className="text-[#2D2D2A]">₹30 (first 2 km)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Per Km Rate:</span>
                    <strong className="text-[#2D2D2A]">₹15 - ₹18 / km</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Station to Lake:</span>
                    <strong className="text-emerald-700">~₹60 - ₹80</strong>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F4F1EA] text-[11px] text-[#5A5A40]">
                  📌 <strong>Local Tip:</strong> Auto stands are stationed at Railway Station, Old Bus Stand, and PB Road. Confirm fare before boarding.
                </div>
              </div>

              {/* Option 2: KSRTC & City Bus */}
              <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3 shadow-2xs">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-900 flex items-center justify-center text-lg">
                  🚌
                </div>
                <div>
                  <h5 className="font-bold text-sm text-[#2D2D2A]">KSRTC & City Buses</h5>
                  <p className="text-xs text-[#8B8B6B] mt-0.5">Super affordable for temple corridors & Harihar</p>
                </div>
                <div className="space-y-1.5 text-xs text-[#5A5A40]">
                  <div className="flex justify-between">
                    <span>City Ticket:</span>
                    <strong className="text-[#2D2D2A]">₹10 - ₹20</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Davanagere to Harihar:</span>
                    <strong className="text-[#2D2D2A]">₹25 (every 10 mins)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Main Hub:</span>
                    <strong className="text-[#2D2D2A]">Central Bus Stand (KSRTC)</strong>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F4F1EA] text-[11px] text-[#5A5A40]">
                  📌 <strong>Local Tip:</strong> Local buses and shuttles connect {city.name} transit hubs to {topTempleName} frequently.
                </div>
              </div>

              {/* Option 3: Walking & Cabs */}
              <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3 shadow-2xs">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-900 flex items-center justify-center text-lg">
                  🚶
                </div>
                <div>
                  <h5 className="font-bold text-sm text-[#2D2D2A]">Walking Trails & App Cabs</h5>
                  <p className="text-xs text-[#8B8B6B] mt-0.5">Pleasant promenades around {topAttractionName}</p>
                </div>
                <div className="space-y-1.5 text-xs text-[#5A5A40]">
                  <div className="flex justify-between">
                    <span>Walking Area:</span>
                    <strong className="text-[#2D2D2A]">{topAttractionName} Loop</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Best Time to Walk:</span>
                    <strong className="text-emerald-700">06:00 AM & 05:30 PM</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Cab Availability:</span>
                    <strong className="text-[#2D2D2A]">Local travel autos & cabs</strong>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F4F1EA] text-[11px] text-[#5A5A40]">
                  📌 <strong>Local Tip:</strong> The promenade around {topAttractionName} has scenic viewpoints and pedestrian paths.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* QUESTION 5: WHICH PLACES ARE SUITABLE FOR TIME & BUDGET? */}
        {/* ========================================================= */}
        {activeTab === 'suitability' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="pb-3 border-b border-[#E5E2D9]">
              <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                Which places are suitable for my time and budget?
              </h4>
              <p className="text-xs text-[#8B8B6B]">
                Curated itineraries tailored to exactly how many hours you have in {city.name}.
              </p>
            </div>

            {/* Time Presets */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {[
                { id: '2hr', label: '⚡ 2-3 Hours Express (Must-Do Essentials)' },
                { id: '5hr', label: '☀️ Half Day (5 Hours Balanced Explorer)' },
                { id: 'fullday', label: '🌟 Full Day (8-10 Hours Complete Tour)' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTimeAvailable(t.id as any)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    timeAvailable === t.id
                      ? 'bg-[#5A5A40] text-white shadow-2xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Smart Schedule Sequence */}
            <div className="space-y-3">
              {timeAvailable === '2hr' && (
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#2D2D2A]">2-Hour Express: Fast Taste & Blessings</span>
                    <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg">
                      Cost: ~₹150 / person
                    </span>
                  </div>
                  <ol className="relative border-l border-amber-300 ml-3 space-y-4 text-xs">
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">Step 1 (45 mins):</strong> Taste the legendary {topFoodName} at {topRestaurant?.name || `${city.name} Heritage Kitchen`}.
                    </li>
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">Step 2 (40 mins):</strong> Visit {topTempleName} for peaceful darshan and blessings.
                    </li>
                  </ol>
                </div>
              )}

              {timeAvailable === '5hr' && (
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#2D2D2A]">Half Day: Heritage, Food & Scenic Sunset</span>
                    <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg">
                      Cost: ~₹350 / person
                    </span>
                  </div>
                  <ol className="relative border-l border-amber-300 ml-3 space-y-4 text-xs">
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">08:30 AM (1 hr):</strong> Hot {topFoodName} breakfast with traditional side chutneys and fresh filter brew.
                    </li>
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">10:00 AM (1.5 hrs):</strong> Architectural exploration of historic {topTempleName}.
                    </li>
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">04:30 PM (2 hrs):</strong> Sunset stroll at {topAttractionName} and explore local sights.
                    </li>
                  </ol>
                </div>
              )}

              {timeAvailable === 'fullday' && (
                <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#2D2D2A]">Full Day Grand Explorer: The Complete Experience</span>
                    <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg">
                      Cost: ~₹750 / person (Includes 3D Cinema)
                    </span>
                  </div>
                  <ol className="relative border-l border-amber-300 ml-3 space-y-4 text-xs">
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">Morning (06:30 - 09:30 AM):</strong> Sacred morning aarti at {topTempleName} followed by local breakfast with {topFoodName}.
                    </li>
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">Midday (10:30 AM - 02:00 PM):</strong> {secondAttraction} heritage tour & authentic regional thali lunch.
                    </li>
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">Evening (05:00 - 06:30 PM):</strong> Sunset viewpoints and scenic vistas at {topAttractionName}.
                    </li>
                    <li className="ml-4">
                      <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-amber-500 border border-white" />
                      <strong className="text-[#2D2D2A]">Night (07:00 - 10:00 PM):</strong> Live blockbuster movie at {topTheatreName} with 3D booked recliners.
                    </li>
                  </ol>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* QUESTION 6: WHAT SHOULD I DO IF I NEED HELP WHILE TRAVELLING? */}
        {/* ========================================================= */}
        {activeTab === 'emergency' && (
          <div className="space-y-5 animate-in fade-in duration-200">
            <div className="pb-3 border-b border-[#E5E2D9]">
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-lg bg-rose-100 text-rose-700">
                  <ShieldAlert className="w-5 h-5" />
                </span>
                <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                  Tourist Safety, Emergency Contacts & Local Language Help
                </h4>
              </div>
              <p className="text-xs text-[#8B8B6B] mt-0.5">
                Immediate 1-tap SOS assistance, district police numbers, nearby hospitals, and basic Kannada-English tourist phrases.
              </p>
            </div>

            {/* Quick Emergency Ticker */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { title: 'Police Emergency', number: '112', color: 'bg-rose-50 border-rose-200 text-rose-800' },
                { title: 'Tourist Helpline', number: '1363', color: 'bg-amber-50 border-amber-200 text-amber-800' },
                { title: 'Medical Ambulance', number: '108', color: 'bg-emerald-50 border-emerald-200 text-emerald-800' },
                { title: 'Women Helpline', number: '1091', color: 'bg-purple-50 border-purple-200 text-purple-800' },
              ].map((item) => (
                <div key={item.title} className={`p-3.5 rounded-2xl border ${item.color} flex flex-col justify-between`}>
                  <span className="text-[11px] font-bold uppercase">{item.title}</span>
                  <a
                    href={`tel:${item.number}`}
                    className="text-2xl font-serif font-extrabold flex items-center gap-1.5 hover:underline mt-1"
                  >
                    <PhoneCall className="w-4 h-4" />
                    <span>{item.number}</span>
                  </a>
                </div>
              ))}
            </div>

            {/* Local District Emergency Details */}
            <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3">
              <h5 className="font-bold text-xs text-[#2D2D2A] uppercase tracking-wider">
                {city.name} District Specific Authorities:
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-[#F4F1EA] flex justify-between items-center">
                  <div>
                    <strong className="block text-[#2D2D2A]">{city.name} Police Control Room</strong>
                    <span className="text-[11px] text-[#8B8B6B]">Central District Station</span>
                  </div>
                  <a
                    href="tel:08192270222"
                    className="px-3 py-1.5 rounded-lg bg-[#5A5A40] text-white font-bold hover:bg-[#484832]"
                  >
                    Call Police
                  </a>
                </div>
                <div className="p-3 rounded-xl bg-[#F4F1EA] flex justify-between items-center">
                  <div>
                    <strong className="block text-[#2D2D2A]">District Govt Hospital & Trauma Center</strong>
                    <span className="text-[11px] text-[#8B8B6B]">24x7 Emergency Services</span>
                  </div>
                  <a
                    href="tel:108"
                    className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-bold hover:bg-emerald-800"
                  >
                    Call 108
                  </a>
                </div>
              </div>
            </div>

            {/* Local Language Helper for Tourists */}
            <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Languages className="w-4 h-4 text-[#5A5A40]" />
                  <h5 className="font-bold text-xs text-[#2D2D2A] uppercase tracking-wider">
                    Quick Kannada Tourist Phrases (Local Helper):
                  </h5>
                </div>
                <span className="text-[10px] text-[#8B8B6B]">Tap phrase to copy to clipboard</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {phrases.map((phrase, idx) => (
                  <div
                    key={idx}
                    onClick={() => copyToClipboard(phrase.kannada)}
                    className="p-2.5 rounded-xl bg-[#FDFCF8] border border-[#E5E2D9] hover:bg-[#F4F1EA] cursor-pointer transition-all flex items-start justify-between gap-2"
                  >
                    <div>
                      <div className="font-bold text-[#2D2D2A]">{phrase.kannada}</div>
                      <div className="text-[11px] text-[#5A5A40] font-medium">{phrase.english}</div>
                      <div className="text-[10px] text-[#8B8B6B] mt-0.5">{phrase.usage}</div>
                    </div>
                    <button type="button" className="text-stone-400 hover:text-stone-700 shrink-0 mt-0.5">
                      {copiedText === phrase.kannada ? (
                        <Check className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
