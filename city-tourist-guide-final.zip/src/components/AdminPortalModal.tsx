import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Shield,
  Lock,
  Eye,
  EyeOff,
  Users,
  Receipt,
  MapPin,
  Search,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Calendar,
  Ticket,
  Film,
  Building2,
  Utensils,
  Landmark,
  Compass,
  ArrowRight,
  LogOut,
  Download,
  Filter,
  RefreshCw,
  Phone,
  Mail,
  Clock,
  Sparkles,
  Layers,
  ChevronRight,
  Info,
  ExternalLink,
  Globe,
  Navigation,
  BarChart3
} from 'lucide-react';
import { UserAccount, Booking, City, Place } from '../types';
import { downloadTicketPDF } from '../utils/pdfTicketGenerator';
import {
  ALL_INDIAN_STATES_AND_UTS,
  StateInfo,
  DistrictInfo,
  convertDistrictToCity,
  generatePlacesForDistrict
} from '../data/indiaStatesAndDistricts';

interface AdminPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserAccount[];
  bookings: Booking[];
  cities: City[];
  places: Place[];
  onSelectDistrict?: (city: City, places: Place[]) => void;
  onSelectCity?: (cityId: string) => void;
  initialAuthenticated?: boolean;
}

const ADMIN_NAME = 'jeevan m k';
const ADMIN_PASSWORD = '6867123';

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  isOpen,
  onClose,
  users = [],
  bookings = [],
  cities = [],
  places = [],
  onSelectDistrict,
  onSelectCity,
  initialAuthenticated = false,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(initialAuthenticated);
  const [enteredPassword, setEnteredPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Synchronize initialAuthenticated state when modal opens
  useEffect(() => {
    if (isOpen && initialAuthenticated) {
      setIsAuthenticated(true);
    }
  }, [isOpen, initialAuthenticated]);

  // Admin Portal Tab Navigation
  const [activeTab, setActiveTab] = useState<'states' | 'cities' | 'quick-updates' | 'users' | 'bookings' | 'analytics'>('states');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserAccount | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  
  // Quick Updates Form States
  const [quickUpdateCityId, setQuickUpdateCityId] = useState<string>('davanagere');
  const [quickUpdateCategory, setQuickUpdateCategory] = useState<'theatre' | 'temple' | 'restaurant' | 'attraction'>('theatre');
  const [quickUpdateName, setQuickUpdateName] = useState<string>('');
  const [quickUpdateTagline, setQuickUpdateTagline] = useState<string>('');
  const [quickUpdatePrice, setQuickUpdatePrice] = useState<number>(200);
  const [quickUpdateStatus, setQuickUpdateStatus] = useState<string>('Live & Open');
  const [quickUpdateSuccessMsg, setQuickUpdateSuccessMsg] = useState<string | null>(null);
  const [liveChangelogs, setLiveChangelogs] = useState<{ id: string; time: string; text: string }[]>([
    { id: 'ch-1', time: 'Just now', text: 'Davanagere Butter Dosa & Gitanjali Cinema 4K Laser screening synced to database.' },
    { id: 'ch-2', time: '12 mins ago', text: 'Durgambika Devi Temple crowd timings updated: Low wait 10:30 AM - 12:00 PM.' },
    { id: 'ch-3', time: '1 hour ago', text: 'Kunduvada Lake sunset promenade & Glass House evening fountain timing verified.' }
  ]);

  // State & District Tab specific state
  const [selectedStateFilter, setSelectedStateFilter] = useState<string>('all');
  const [stateTypeFilter, setStateTypeFilter] = useState<'all' | 'State' | 'Union Territory'>('all');
  const [inspectingDistrict, setInspectingDistrict] = useState<{ district: DistrictInfo; stateName: string } | null>(null);

  // City Tab specific state
  const [selectedCityInspect, setSelectedCityInspect] = useState<City | null>(null);
  const [cityPlaceCategoryFilter, setCityPlaceCategoryFilter] = useState<string>('all');

  if (!isOpen) return null;

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (enteredPassword.trim() === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setEnteredPassword('');
    } else {
      setAuthError(
        'CAUTION: Permission Denied! This is a restricted Admin Page. Only the system administrator (jeevan m k) can log in on this page with his authorized password.'
      );
    }
  };

  const handleAdminLogout = () => {
    setIsAuthenticated(false);
    setSelectedUser(null);
    setInspectingDistrict(null);
    setSelectedCityInspect(null);
    setEnteredPassword('');
    setAuthError(null);
  };

  // Aggregates for All-India States & Districts
  const statesData = useMemo(() => ALL_INDIAN_STATES_AND_UTS || [], []);
  const totalStatesCount = useMemo(() => statesData.filter((s) => s.type === 'State').length, [statesData]);
  const totalUTsCount = useMemo(() => statesData.filter((s) => s.type === 'Union Territory').length, [statesData]);
  const totalDistrictsCount = useMemo(
    () => statesData.reduce((sum, s) => sum + (s.districts ? s.districts.length : 0), 0),
    [statesData]
  );

  // Filtered States & Districts
  const filteredStatesAndDistricts = useMemo(() => {
    return statesData
      .filter((st) => {
        if (stateTypeFilter !== 'all' && st.type !== stateTypeFilter) return false;
        if (selectedStateFilter !== 'all' && st.id !== selectedStateFilter) return false;
        return true;
      })
      .map((st) => {
        const districts = st.districts || [];
        if (!searchQuery.trim()) {
          return {
            ...st,
            districts,
          };
        }
        const query = searchQuery.trim().toLowerCase();
        const matchesState =
          (st.name && st.name.toLowerCase().includes(query)) ||
          (st.capital && st.capital.toLowerCase().includes(query)) ||
          (st.tagline && st.tagline.toLowerCase().includes(query));

        const matchingDistricts = districts.filter((d) => {
          if (!d) return false;
          return (
            (d.name && d.name.toLowerCase().includes(query)) ||
            (d.tagline && d.tagline.toLowerCase().includes(query)) ||
            (d.description && d.description.toLowerCase().includes(query)) ||
            (Array.isArray(d.highlights) && d.highlights.some((h) => h && h.toLowerCase().includes(query))) ||
            (Array.isArray(d.famousFood) && d.famousFood.some((f) => f && f.toLowerCase().includes(query))) ||
            (Array.isArray(d.temples) && d.temples.some((t) => t && t.toLowerCase().includes(query))) ||
            (Array.isArray(d.theatres) && d.theatres.some((th) => th && th.toLowerCase().includes(query))) ||
            (Array.isArray(d.attractions) && d.attractions.some((a) => a && a.toLowerCase().includes(query)))
          );
        });

        return {
          ...st,
          districts: matchesState ? districts : matchingDistricts,
        };
      })
      .filter(
        (st) =>
          st.districts.length > 0 ||
          (!searchQuery.trim() && selectedStateFilter === st.id) ||
          (searchQuery.trim() &&
            ((st.name && st.name.toLowerCase().includes(searchQuery.trim().toLowerCase())) ||
              (st.capital && st.capital.toLowerCase().includes(searchQuery.trim().toLowerCase()))))
      );
  }, [statesData, stateTypeFilter, selectedStateFilter, searchQuery]);

  const totalFilteredDistrictsCount = useMemo(
    () => filteredStatesAndDistricts.reduce((sum, s) => sum + (s.districts ? s.districts.length : 0), 0),
    [filteredStatesAndDistricts]
  );

  // Analytics Aggregates
  const totalRevenue = bookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);
  const totalTickets = bookings.reduce((sum, b) => {
    if (b.category === 'theatre') return sum + (b.details?.selectedSeats?.length || 1);
    if (b.category === 'temple') return sum + (b.details?.devoteeCount || 1);
    if (b.category === 'attraction') return sum + (b.details?.ticketBreakdown?.adults || 1) + (b.details?.ticketBreakdown?.children || 0);
    return sum + (b.details?.ticketCount || 1);
  }, 0);

  // Filtered Bookings
  const filteredBookings = bookings.filter((b) => {
    const matchesSearch =
      b.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.bookingRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.itemTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.cityName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.customerEmail && b.customerEmail.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (b.customerPhone && b.customerPhone.includes(searchQuery));

    const matchesCategory = categoryFilter === 'all' || b.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    return (
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.phone && u.phone.includes(searchQuery))
    );
  });

  // Filtered Cities
  const filteredCities = cities.filter((c) => {
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.state.toLowerCase().includes(q) ||
      (c.tagline && c.tagline.toLowerCase().includes(q))
    );
  });

  const handleActivateDistrictInApp = (district: DistrictInfo) => {
    if (onSelectDistrict) {
      const city = convertDistrictToCity(district);
      const districtPlaces = generatePlacesForDistrict(district);
      onSelectDistrict(city, districtPlaces);
      onClose();
    }
  };

  const handleLaunchCityInApp = (cityId: string) => {
    // 1. Try finding in active cities list
    const targetCity = cities.find((c) => c.id === cityId);
    if (targetCity) {
      if (onSelectDistrict) {
        const cityPlaces = places.filter((p) => p.cityId === targetCity.id);
        onSelectDistrict(targetCity, cityPlaces);
      } else if (onSelectCity) {
        onSelectCity(targetCity.id);
      }
      onClose();
      return;
    }

    // 2. Try finding in all Indian States & Districts
    for (const st of statesData) {
      const d = st.districts?.find((item) => item.id === cityId);
      if (d) {
        handleActivateDistrictInApp(d);
        return;
      }
    }

    // 3. Fallback direct call
    if (onSelectCity) {
      onSelectCity(cityId);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-6xl bg-[#FDFCF8] rounded-3xl overflow-hidden shadow-2xl border border-[#E5E2D9] my-4 max-h-[94vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Top Header Bar */}
        <div className="p-4 sm:p-5 bg-[#1C1C1A] text-white flex items-center justify-between border-b border-[#333] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif font-bold text-base sm:text-lg text-white">
                  Admin Command & Database Portal
                </span>
                <span className="px-2 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/30 text-amber-300 text-[10px] font-extrabold uppercase tracking-wider">
                  Admin: {ADMIN_NAME}
                </span>
              </div>
              <p className="text-[11px] text-[#A0A090]">
                All-India States, Districts, Cities, Users & Booking Records Database
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                type="button"
                onClick={handleAdminLogout}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-stone-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Lock Admin Panel"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Lock Panel</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
              title="Close Portal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* --- PASSWORD AUTHENTICATION SCREEN (When not unlocked) --- */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center text-center space-y-6 flex-1 overflow-y-auto">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600 shadow-inner">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-1.5 max-w-md">
              <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#2D2D2A]">
                Enter Administrator Password
              </h3>
              <p className="text-xs sm:text-sm text-[#8B8B6B]">
                This administrative database is restricted exclusively to administrator{' '}
                <strong className="text-[#2D2D2A]">{ADMIN_NAME}</strong>.
              </p>
            </div>

            {authError && (
              <div className="max-w-md w-full p-4 rounded-2xl bg-rose-50 border-2 border-rose-300 text-rose-900 text-xs font-semibold flex items-start gap-3 text-left shadow-xs">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="font-bold uppercase tracking-wider text-[11px] text-rose-700">Access Restricted</div>
                  <div className="leading-relaxed">{authError}</div>
                </div>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="w-full max-w-sm space-y-4">
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={enteredPassword}
                  onChange={(e) => setEnteredPassword(e.target.value)}
                  placeholder="Enter Administrator Password"
                  className="w-full px-4 py-3 pr-11 bg-white border border-[#DEDACF] rounded-2xl text-sm text-[#2D2D2A] focus:outline-hidden focus:border-amber-600 shadow-inner tracking-widest font-mono text-center"
                  autoFocus
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-2xl bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.99] cursor-pointer"
              >
                <Shield className="w-4 h-4 text-amber-400" />
                <span>Authenticate & Access Databases</span>
              </button>
            </form>

            <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-[11px] text-amber-900 max-w-sm flex items-center justify-center gap-2">
              <Shield className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Restricted administrative database for <strong className="font-bold">jeevan m k</strong></span>
            </div>
          </div>
        ) : (
          /* --- UNLOCKED ADMIN COMMAND CENTER --- */
          <div className="flex-1 flex flex-col overflow-hidden bg-[#FDFCF8]">
            
            {/* Top KPI Metrics Bar */}
            <div className="p-3.5 sm:p-4 bg-[#F4F1EA] border-b border-[#E5E2D9] grid grid-cols-2 lg:grid-cols-5 gap-2.5 shrink-0">
              <div className="p-2.5 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    States & UTs
                  </span>
                  <span className="text-lg font-bold font-serif text-[#2D2D2A]">
                    {totalStatesCount} States · {totalUTsCount} UTs
                  </span>
                </div>
                <div className="w-7 h-7 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                  <Globe className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Districts in DB
                  </span>
                  <span className="text-lg font-bold font-serif text-amber-800">
                    {totalDistrictsCount} Districts
                  </span>
                </div>
                <div className="w-7 h-7 rounded-xl bg-orange-50 text-orange-700 flex items-center justify-center">
                  <MapPin className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Active Cities
                  </span>
                  <span className="text-lg font-bold font-serif text-purple-700">
                    {cities.length} Cities ({places.length} Sights)
                  </span>
                </div>
                <div className="w-7 h-7 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
                  <Building2 className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Registered Users
                  </span>
                  <span className="text-lg font-bold font-serif text-blue-700">
                    {users.length} Users
                  </span>
                </div>
                <div className="w-7 h-7 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                  <Users className="w-3.5 h-3.5" />
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between col-span-2 lg:col-span-1">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Bookings & Rev
                  </span>
                  <span className="text-lg font-bold font-serif text-emerald-700">
                    {bookings.length} (₹{totalRevenue.toLocaleString()})
                  </span>
                </div>
                <div className="w-7 h-7 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Ticket className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Admin Database Navigation Tabs */}
            <div className="px-4 sm:px-6 pt-3 border-b border-[#E5E2D9] flex flex-wrap items-center justify-between gap-3 shrink-0 bg-[#FDFCF8]">
              <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('states');
                    setSelectedUser(null);
                    setInspectingDistrict(null);
                    setSelectedCityInspect(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === 'states'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5 text-amber-400" />
                  <span>1. State & District DB ({totalDistrictsCount})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('cities');
                    setSelectedUser(null);
                    setInspectingDistrict(null);
                    setSelectedCityInspect(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === 'cities'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>2. City Knowledge DB ({cities.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('quick-updates');
                    setSelectedUser(null);
                    setInspectingDistrict(null);
                    setSelectedCityInspect(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === 'quick-updates'
                      ? 'bg-amber-400 text-stone-950 shadow-xs ring-2 ring-amber-300'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>3. Live & Quick Updates ⚡</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('users');
                    setSelectedUser(null);
                    setInspectingDistrict(null);
                    setSelectedCityInspect(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === 'users'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-blue-400" />
                  <span>3. User DB ({users.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('bookings');
                    setSelectedUser(null);
                    setInspectingDistrict(null);
                    setSelectedCityInspect(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === 'bookings'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5 text-emerald-400" />
                  <span>4. Bookings Audit ({bookings.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('analytics');
                    setSelectedUser(null);
                    setInspectingDistrict(null);
                    setSelectedCityInspect(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === 'analytics'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5 text-rose-400" />
                  <span>5. Analytics</span>
                </button>
              </div>

              {/* Search & Filter bar */}
              <div className="relative pb-2 sm:pb-0 w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-[#8B8B6B] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={`Search in ${activeTab} database...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                />
              </div>
            </div>

            {/* TAB CONTENTS (Scrollable) */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

              {/* ========================================================= */}
              {/* === TAB 1: ALL-INDIA STATE & DISTRICT DATABASE === */}
              {/* ========================================================= */}
              {activeTab === 'states' && (
                <div className="space-y-4">
                  {/* Filter Sub-bar */}
                  <div className="space-y-3 p-3.5 sm:p-4 rounded-2xl bg-[#F4F1EA] border border-[#E5E2D9]">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold text-[#5A5A40] flex items-center gap-1">
                          <Filter className="w-3.5 h-3.5" /> Filter by:
                        </span>
                        
                        {/* State vs UT selector */}
                        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-[#DEDACF]">
                          {(['all', 'State', 'Union Territory'] as const).map((t) => (
                            <button
                              key={t}
                              type="button"
                              onClick={() => {
                                setStateTypeFilter(t);
                                setSelectedStateFilter('all');
                              }}
                              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                                stateTypeFilter === t
                                  ? 'bg-[#5A5A40] text-white shadow-2xs'
                                  : 'text-[#8B8B6B] hover:text-[#2D2D2A]'
                              }`}
                            >
                              {t === 'all' ? 'All (36)' : t === 'State' ? 'States (28)' : 'UTs (8)'}
                            </button>
                          ))}
                        </div>

                        {/* Specific State Dropdown */}
                        <select
                          value={selectedStateFilter}
                          onChange={(e) => setSelectedStateFilter(e.target.value)}
                          className="px-3 py-1.5 rounded-xl bg-white border border-[#DEDACF] text-xs font-bold text-[#2D2D2A] focus:outline-hidden cursor-pointer"
                        >
                          <option value="all">All States & Union Territories (36)</option>
                          {statesData.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name} ({s.districts ? s.districts.length : 0} districts) — {s.type}
                            </option>
                          ))}
                        </select>

                        {(searchQuery.trim() || selectedStateFilter !== 'all' || stateTypeFilter !== 'all') && (
                          <button
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSelectedStateFilter('all');
                              setStateTypeFilter('all');
                            }}
                            className="px-2.5 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <X className="w-3 h-3" />
                            <span>Reset Filters</span>
                          </button>
                        )}
                      </div>

                      <div className="text-xs font-bold text-[#5A5A40] flex items-center gap-1.5 self-start sm:self-auto">
                        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                        <span>
                          Showing <strong className="text-[#2D2D2A] font-extrabold">{totalFilteredDistrictsCount}</strong> districts across {filteredStatesAndDistricts.length} regions
                        </span>
                      </div>
                    </div>

                    {/* Quick State Navigation Pills */}
                    <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 text-[11px]">
                      <span className="text-[#8B8B6B] font-medium shrink-0 text-[10px] uppercase tracking-wider">Quick State Jump:</span>
                      {[
                        { id: 'all', label: 'All India' },
                        { id: 'karnataka', label: 'Karnataka (31)' },
                        { id: 'maharashtra', label: 'Maharashtra (36)' },
                        { id: 'delhi', label: 'Delhi UT (11)' },
                        { id: 'tamil-nadu', label: 'Tamil Nadu (38)' },
                        { id: 'kerala', label: 'Kerala (14)' },
                        { id: 'uttar-pradesh', label: 'Uttar Pradesh (75)' },
                        { id: 'rajasthan', label: 'Rajasthan (50)' },
                        { id: 'gujarat', label: 'Gujarat (33)' },
                        { id: 'goa', label: 'Goa (2)' },
                        { id: 'andhra-pradesh', label: 'Andhra Pradesh (26)' },
                        { id: 'telangana', label: 'Telangana (33)' },
                        { id: 'west-bengal', label: 'West Bengal (23)' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            setSelectedStateFilter(item.id);
                            if (item.id === 'delhi') setStateTypeFilter('Union Territory');
                            else if (item.id !== 'all') setStateTypeFilter('State');
                          }}
                          className={`px-2.5 py-0.5 rounded-full whitespace-nowrap text-[11px] font-semibold transition-all cursor-pointer ${
                            selectedStateFilter === item.id
                              ? 'bg-[#2D2D2A] text-white shadow-2xs'
                              : 'bg-white border border-[#DEDACF] text-[#5A5A40] hover:bg-[#EAE7DC] hover:text-[#2D2D2A]'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* States & Districts Grid */}
                  {filteredStatesAndDistricts.length > 0 ? (
                    <div className="space-y-6">
                      {filteredStatesAndDistricts.map((state) => (
                        <div
                          key={state.id}
                          className="rounded-2xl bg-white border border-[#E5E2D9] overflow-hidden shadow-xs space-y-3"
                        >
                          {/* State Header Banner */}
                          <div className="p-4 bg-gradient-to-r from-[#2D2D2A] to-[#484833] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/30 flex items-center justify-center text-amber-300 font-serif font-bold text-lg shrink-0">
                                {state.name ? state.name.charAt(0) : 'S'}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="font-serif font-bold text-base text-white">{state.name}</h4>
                                  <span className="px-2 py-0.5 rounded-md bg-white/20 text-stone-200 text-[10px] font-bold uppercase">
                                    {state.type}
                                  </span>
                                </div>
                                <p className="text-xs text-stone-300">
                                  Capital: <strong className="text-amber-300">{state.capital}</strong> · {state.districts ? state.districts.length : 0} Official Districts
                                </p>
                              </div>
                            </div>

                            <div className="text-xs text-stone-300 italic max-w-sm text-right hidden md:block">
                              "{state.tagline}"
                            </div>
                          </div>

                          {/* Districts Grid within State */}
                          {state.districts && state.districts.length > 0 ? (
                            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                              {state.districts.map((dist) => {
                                const templesLen = dist.temples ? dist.temples.length : 0;
                                const theatresLen = dist.theatres ? dist.theatres.length : 0;
                                const foodLen = dist.famousFood ? dist.famousFood.length : 0;
                                const sightsLen = dist.attractions ? dist.attractions.length : 0;

                                return (
                                  <div
                                    key={dist.id}
                                    className="p-3.5 rounded-xl bg-[#FDFCF8] border border-[#EAE7DC] hover:border-[#5A5A40] transition-all flex flex-col justify-between space-y-3 hover:shadow-sm"
                                  >
                                    <div className="space-y-1.5">
                                      <div className="flex items-start justify-between gap-2">
                                        <h5 className="font-bold text-sm text-[#2D2D2A] flex items-center gap-1.5">
                                          <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                          <span>{dist.name}</span>
                                        </h5>
                                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-900 shrink-0">
                                          District
                                        </span>
                                      </div>
                                      <p className="text-[11px] text-[#5A5A40] line-clamp-2 leading-relaxed">
                                        {dist.tagline || dist.description}
                                      </p>
                                    </div>

                                    {/* Highlights & Features Breakdown */}
                                    <div className="grid grid-cols-2 gap-1.5 text-[10px] text-[#5A5A40]">
                                      <div className="p-1 rounded-md bg-[#F4F1EA] flex items-center gap-1">
                                        <span>🛕 Temples:</span>
                                        <strong className="text-[#2D2D2A]">{templesLen}</strong>
                                      </div>
                                      <div className="p-1 rounded-md bg-[#F4F1EA] flex items-center gap-1">
                                        <span>🎬 Theatres:</span>
                                        <strong className="text-[#2D2D2A]">{theatresLen}</strong>
                                      </div>
                                      <div className="p-1 rounded-md bg-[#F4F1EA] flex items-center gap-1">
                                        <span>🍲 Cuisines:</span>
                                        <strong className="text-[#2D2D2A]">{foodLen}</strong>
                                      </div>
                                      <div className="p-1 rounded-md bg-[#F4F1EA] flex items-center gap-1">
                                        <span>🏛️ Sights:</span>
                                        <strong className="text-[#2D2D2A]">{sightsLen}</strong>
                                      </div>
                                    </div>

                                    {/* Action Buttons */}
                                    <div className="pt-2 border-t border-[#EAE7DC] flex items-center justify-between gap-2">
                                      <button
                                        type="button"
                                        onClick={() => setInspectingDistrict({ district: dist, stateName: state.name })}
                                        className="px-2.5 py-1 rounded-lg bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                                      >
                                        <Info className="w-3 h-3 text-[#5A5A40]" />
                                        <span>Inspect DB</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => handleActivateDistrictInApp(dist)}
                                        className="px-2.5 py-1 rounded-lg bg-[#5A5A40] hover:bg-[#484832] text-white text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                                        title="Load this district into the tourist guide app"
                                      >
                                        <Navigation className="w-3 h-3 text-amber-300" />
                                        <span>Explore in App →</span>
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <div className="p-4 text-center text-xs text-[#8B8B6B]">
                              No districts listed under {state.name}.
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    /* Fallback Empty State if Filters or Search returned 0 */
                    <div className="p-8 sm:p-12 rounded-3xl bg-white border border-[#E5E2D9] text-center space-y-4 shadow-xs">
                      <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-700 mx-auto flex items-center justify-center">
                        <Search className="w-7 h-7" />
                      </div>
                      <div className="space-y-1 max-w-md mx-auto">
                        <h4 className="font-serif font-bold text-lg text-[#2D2D2A]">
                          No States or Districts Matched
                        </h4>
                        <p className="text-xs text-[#8B8B6B]">
                          No records match your search query <span className="font-semibold text-[#2D2D2A]">"{searchQuery}"</span> or selected state filter.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSearchQuery('');
                          setSelectedStateFilter('all');
                          setStateTypeFilter('all');
                        }}
                        className="px-4 py-2 rounded-xl bg-[#5A5A40] hover:bg-[#484832] text-white text-xs font-bold inline-flex items-center gap-2 cursor-pointer shadow-xs"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Reset All Filters & View All 36 States & UTs</span>
                      </button>
                    </div>
                  )}

                  {/* District Inspection Drawer / Modal */}
                  {inspectingDistrict && (
                    <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
                      <div className="relative w-full max-w-2xl bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-[#E5E2D9] max-h-[90vh] overflow-y-auto space-y-4">
                        <div className="flex items-start justify-between pb-3 border-b border-[#E5E2D9]">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-serif font-bold text-xl text-[#2D2D2A]">
                                {inspectingDistrict.district.name} District
                              </h4>
                              <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-xs font-bold">
                                {inspectingDistrict.stateName}
                              </span>
                            </div>
                            <p className="text-xs text-[#8B8B6B] mt-0.5">
                              Coordinates: {inspectingDistrict.district.coordinates.lat.toFixed(4)}° N, {inspectingDistrict.district.coordinates.lng.toFixed(4)}° E · Best Season: {inspectingDistrict.district.bestSeason}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => setInspectingDistrict(null)}
                            className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center justify-center cursor-pointer"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="space-y-3 text-xs">
                          <p className="text-[#3D3D3D] leading-relaxed bg-[#FDFCF8] p-3 rounded-xl border border-[#EAE7DC]">
                            {inspectingDistrict.district.description}
                          </p>

                          <div className="space-y-1.5">
                            <strong className="text-[#2D2D2A] font-bold block">✨ Major Tourist Highlights:</strong>
                            <div className="flex flex-wrap gap-1.5">
                              {inspectingDistrict.district.highlights.map((h, i) => (
                                <span key={i} className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px] font-medium">
                                  {h}
                                </span>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                            <div className="p-3 rounded-xl bg-[#F4F1EA] space-y-1">
                              <strong className="text-[#2D2D2A] font-bold block flex items-center gap-1.5">
                                🛕 Temples in Database ({inspectingDistrict.district.temples.length})
                              </strong>
                              <ul className="list-disc list-inside space-y-0.5 text-[#5A5A40] text-[11px]">
                                {inspectingDistrict.district.temples.map((t, i) => (
                                  <li key={i}>{t}</li>
                                ))}
                              </ul>
                            </div>

                            <div className="p-3 rounded-xl bg-[#F4F1EA] space-y-1">
                              <strong className="text-[#2D2D2A] font-bold block flex items-center gap-1.5">
                                🎬 Cinemas in Database ({inspectingDistrict.district.theatres.length})
                              </strong>
                              <ul className="list-disc list-inside space-y-0.5 text-[#5A5A40] text-[11px]">
                                {inspectingDistrict.district.theatres.map((th, i) => (
                                  <li key={i}>{th}</li>
                                ))}
                              </ul>
                            </div>

                            <div className="p-3 rounded-xl bg-[#F4F1EA] space-y-1">
                              <strong className="text-[#2D2D2A] font-bold block flex items-center gap-1.5">
                                🍲 Iconic Regional Food ({inspectingDistrict.district.famousFood.length})
                              </strong>
                              <ul className="list-disc list-inside space-y-0.5 text-[#5A5A40] text-[11px]">
                                {inspectingDistrict.district.famousFood.map((f, i) => (
                                  <li key={i}>{f}</li>
                                ))}
                              </ul>
                            </div>

                            <div className="p-3 rounded-xl bg-[#F4F1EA] space-y-1">
                              <strong className="text-[#2D2D2A] font-bold block flex items-center gap-1.5">
                                🏛️ Sights & Attractions ({inspectingDistrict.district.attractions.length})
                              </strong>
                              <ul className="list-disc list-inside space-y-0.5 text-[#5A5A40] text-[11px]">
                                {inspectingDistrict.district.attractions.map((a, i) => (
                                  <li key={i}>{a}</li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-[11px]">
                            <strong>📞 Tourist Helpline & Emergency:</strong> {inspectingDistrict.district.emergencyContact}
                          </div>
                        </div>

                        <div className="pt-3 border-t border-[#E5E2D9] flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setInspectingDistrict(null)}
                            className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold cursor-pointer"
                          >
                            Close
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              handleActivateDistrictInApp(inspectingDistrict.district);
                              setInspectingDistrict(null);
                            }}
                            className="px-4 py-2 rounded-xl bg-[#5A5A40] hover:bg-[#484832] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                          >
                            <Navigation className="w-3.5 h-3.5 text-amber-300" />
                            <span>Activate & Open in Tourist App</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ========================================================= */}
              {/* === TAB 2: ACTIVE CITY KNOWLEDGE DATABASE === */}
              {/* ========================================================= */}
              {activeTab === 'cities' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#2D2D2A]">
                        Active City Tourism Hubs ({cities.length})
                      </h4>
                      <p className="text-xs text-[#8B8B6B]">
                        Comprehensive database of activated tourist destinations, heritage sights, theatres, temples, and culinary hubs.
                      </p>
                    </div>
                    <span className="text-xs font-bold text-purple-800 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200 self-start sm:self-auto">
                      {places.length} Total Verified Places in DB
                    </span>
                  </div>

                  {/* City Cards Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredCities.map((c) => {
                      const cityPlaces = places.filter((p) => p.cityId === c.id);
                      const cityBookings = bookings.filter((b) => b.cityName.toLowerCase() === c.name.toLowerCase());
                      const cityRevenue = cityBookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);

                      const theatresCount = cityPlaces.filter((p) => p.category === 'theatre').length;
                      const templesCount = cityPlaces.filter((p) => p.category === 'temple').length;
                      const foodCount = cityPlaces.filter((p) => p.category === 'restaurant').length;
                      const sightsCount = cityPlaces.filter((p) => p.category === 'attraction').length;

                      return (
                        <div
                          key={c.id}
                          className="rounded-2xl bg-white border border-[#E5E2D9] overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
                        >
                          <div>
                            <div className="relative h-32 w-full overflow-hidden bg-stone-800">
                              <img
                                src={c.coverImage}
                                alt={c.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover brightness-[0.75]"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                              <div className="absolute bottom-2.5 left-3 right-3 text-white">
                                <h5 className="font-serif font-bold text-lg leading-tight">{c.name}</h5>
                                <span className="text-[11px] text-stone-300">{c.state}, {c.country}</span>
                              </div>
                            </div>

                            <div className="p-3.5 space-y-3 text-xs">
                              <p className="text-[#5A5A40] text-[11px] line-clamp-2">
                                {c.tagline || c.description}
                              </p>

                              <div className="grid grid-cols-2 gap-1.5 text-[11px] text-[#5A5A40]">
                                <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                  <span>🎬 Theatres:</span>
                                  <strong className="text-[#2D2D2A]">{theatresCount}</strong>
                                </div>
                                <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                  <span>🛕 Temples:</span>
                                  <strong className="text-[#2D2D2A]">{templesCount}</strong>
                                </div>
                                <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                  <span>🍽️ Food:</span>
                                  <strong className="text-[#2D2D2A]">{foodCount}</strong>
                                </div>
                                <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                  <span>🏛️ Sights:</span>
                                  <strong className="text-[#2D2D2A]">{sightsCount}</strong>
                                </div>
                              </div>

                              <div className="pt-2 border-t border-[#E5E2D9] flex items-center justify-between text-[11px]">
                                <span className="text-[#8B8B6B]">Bookings Made:</span>
                                <span className="font-bold text-emerald-700">{cityBookings.length} (₹{cityRevenue.toLocaleString()})</span>
                              </div>
                            </div>
                          </div>

                          <div className="p-3 bg-[#FDFCF8] border-t border-[#E5E2D9] flex items-center justify-between gap-2">
                            <button
                              type="button"
                              onClick={() => setSelectedCityInspect(c)}
                              className="px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Info className="w-3.5 h-3.5 text-[#5A5A40]" />
                              <span>View All {cityPlaces.length} Places</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleLaunchCityInApp(c.id)}
                              className="px-3 py-1.5 rounded-xl bg-[#5A5A40] hover:bg-[#484832] text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Navigation className="w-3.5 h-3.5 text-amber-300" />
                              <span>Open in Guide</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* City Places Detailed Modal */}
                  {selectedCityInspect && (
                    <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
                      <div className="relative w-full max-w-3xl bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-[#E5E2D9] max-h-[90vh] overflow-y-auto space-y-4">
                        <div className="flex items-start justify-between pb-3 border-b border-[#E5E2D9]">
                          <div>
                            <h4 className="font-serif font-bold text-xl text-[#2D2D2A]">
                              All Places in {selectedCityInspect.name}, {selectedCityInspect.state}
                            </h4>
                            <p className="text-xs text-[#8B8B6B] mt-0.5">
                              {places.filter((p) => p.cityId === selectedCityInspect.id).length} registered venues and destinations in database
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => setSelectedCityInspect(null)}
                            className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center justify-center cursor-pointer"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Category filter */}
                        <div className="flex items-center gap-2 overflow-x-auto pb-1">
                          {['all', 'theatre', 'temple', 'restaurant', 'attraction'].map((cat) => (
                            <button
                              key={cat}
                              type="button"
                              onClick={() => setCityPlaceCategoryFilter(cat)}
                              className={`px-3 py-1 rounded-xl text-xs font-bold capitalize transition-colors cursor-pointer ${
                                cityPlaceCategoryFilter === cat
                                  ? 'bg-[#5A5A40] text-white'
                                  : 'bg-[#F4F1EA] text-[#8B8B6B] hover:text-[#2D2D2A]'
                              }`}
                            >
                              {cat}
                            </button>
                          ))}
                        </div>

                        {/* Places List */}
                        <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                          {places
                            .filter(
                              (p) =>
                                p.cityId === selectedCityInspect.id &&
                                (cityPlaceCategoryFilter === 'all' || p.category === cityPlaceCategoryFilter)
                            )
                            .map((p) => (
                              <div
                                key={p.id}
                                className="p-3 rounded-xl bg-[#FDFCF8] border border-[#EAE7DC] flex items-start justify-between gap-3 text-xs"
                              >
                                <div className="space-y-1">
                                  <div className="flex items-center gap-2">
                                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                                      p.category === 'theatre' ? 'bg-amber-100 text-amber-800' :
                                      p.category === 'temple' ? 'bg-orange-100 text-orange-800' :
                                      p.category === 'restaurant' ? 'bg-emerald-100 text-emerald-800' :
                                      'bg-purple-100 text-purple-800'
                                    }`}>
                                      {p.category}
                                    </span>
                                    <strong className="text-sm font-bold text-[#2D2D2A]">{p.name}</strong>
                                    <span className="text-[11px] text-amber-600 font-bold">★ {p.rating}</span>
                                  </div>
                                  <p className="text-[#5A5A40] text-[11px] line-clamp-1">{p.tagline}</p>
                                  <p className="text-[#8B8B6B] text-[10px]">{p.address}</p>
                                </div>

                                <div className="text-right shrink-0">
                                  <span className="font-bold text-[#2D2D2A] block">
                                    {p.ticket.isFree ? 'Free Entry' : `₹${p.ticket.generalPrice}`}
                                  </span>
                                  <span className="text-[10px] text-emerald-700 font-medium">
                                    {p.timings.currentStatus}
                                  </span>
                                </div>
                              </div>
                            ))}
                        </div>

                        <div className="pt-3 border-t border-[#E5E2D9] flex items-center justify-end">
                          <button
                            type="button"
                            onClick={() => setSelectedCityInspect(null)}
                            className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold cursor-pointer"
                          >
                            Close
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ========================================================= */}
              {/* === TAB 3: LIVE & QUICK UPDATES === */}
              {/* ========================================================= */}
              {activeTab === 'quick-updates' && (
                <div className="space-y-6 animate-in fade-in duration-200">
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#2D2D2A] via-[#3D3D37] to-[#5A5A40] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-400 text-stone-950 flex items-center justify-center font-bold">
                        ⚡
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-serif font-bold text-base text-white">Live Database Command & Quick Updates</h4>
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                        </div>
                        <p className="text-xs text-[#DEDACF] mt-0.5">
                          Push immediate changes to live movies running in theatres, temple crowd wait times, or add new food spots in real time.
                        </p>
                      </div>
                    </div>
                    <div className="text-right text-xs text-stone-300">
                      <div>Admin: <strong className="text-amber-300">{ADMIN_NAME}</strong></div>
                      <div className="text-[10px] text-stone-400">Sync: Active 100%</div>
                    </div>
                  </div>

                  {quickUpdateSuccessMsg && (
                    <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in zoom-in-95">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{quickUpdateSuccessMsg}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Quick Update Form */}
                    <div className="lg:col-span-2 p-5 rounded-2xl bg-white border border-[#E5E2D9] space-y-4 shadow-2xs">
                      <h5 className="font-bold text-sm text-[#2D2D2A] flex items-center gap-2 pb-2 border-b border-[#F4F1EA]">
                        <Sparkles className="w-4 h-4 text-amber-600" />
                        <span>Quick-Publish Live Change</span>
                      </h5>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="space-y-1">
                          <label className="font-bold text-[#5A5A40]">Target City / District:</label>
                          <select
                            value={quickUpdateCityId}
                            onChange={(e) => setQuickUpdateCityId(e.target.value)}
                            className="w-full px-3 py-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs font-bold text-[#2D2D2A] focus:outline-hidden"
                          >
                            <option value="davanagere">Davanagere (Karnataka)</option>
                            <option value="bengaluru-urban">Bengaluru Urban (Karnataka)</option>
                            <option value="mysuru">Mysuru (Karnataka)</option>
                            <option value="dharwad">Hubballi-Dharwad (Karnataka)</option>
                            <option value="varanasi">Varanasi (Uttar Pradesh)</option>
                            <option value="mumbai">Mumbai (Maharashtra)</option>
                            <option value="new-delhi">New Delhi (Delhi UT)</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="font-bold text-[#5A5A40]">Update Category:</label>
                          <select
                            value={quickUpdateCategory}
                            onChange={(e) => setQuickUpdateCategory(e.target.value as any)}
                            className="w-full px-3 py-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs font-bold text-[#2D2D2A] focus:outline-hidden"
                          >
                            <option value="theatre">🎬 Live Theatre Movie & Screening</option>
                            <option value="temple">🛕 Temple Aarti & Crowd Wait Time</option>
                            <option value="restaurant">🍽️ Signature Food / Restaurant</option>
                            <option value="attraction">🏞️ Tourist Spot & Ticket Fee</option>
                          </select>
                        </div>
                      </div>

                      <div className="space-y-1 text-xs">
                        <label className="font-bold text-[#5A5A40]">
                          {quickUpdateCategory === 'theatre' ? 'New Movie Title / Screening Room:' :
                           quickUpdateCategory === 'temple' ? 'Temple Name / Special Darshan Seva:' :
                           quickUpdateCategory === 'restaurant' ? 'Famous Restaurant / Dish Name:' : 'Attraction / Spot Title:'}
                        </label>
                        <input
                          type="text"
                          value={quickUpdateName}
                          onChange={(e) => setQuickUpdateName(e.target.value)}
                          placeholder="e.g. Kantara: Chapter 1 (Padma Theatre) or Durgambika Devi Temple"
                          className="w-full px-3 py-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="space-y-1">
                          <label className="font-bold text-[#5A5A40]">Ticket Rate / Price (₹):</label>
                          <input
                            type="number"
                            value={quickUpdatePrice}
                            onChange={(e) => setQuickUpdatePrice(Number(e.target.value))}
                            className="w-full px-3 py-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden font-bold"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="font-bold text-[#5A5A40]">Live Crowd / Operational Status:</label>
                          <select
                            value={quickUpdateStatus}
                            onChange={(e) => setQuickUpdateStatus(e.target.value)}
                            className="w-full px-3 py-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs font-bold text-[#2D2D2A] focus:outline-hidden"
                          >
                            <option value="Low Crowd (10m wait)">🟢 Low Crowd (Estimated wait 10 mins)</option>
                            <option value="Moderate Crowd (25m wait)">🟡 Moderate Crowd (Estimated wait 25 mins)</option>
                            <option value="Peak Aarti / Houseful (60m wait)">🔴 Peak Crowd / Filling Fast (60 mins wait)</option>
                            <option value="Open & Running Shows">🎟️ Shows Running Now (Contactless E-Pass)</option>
                          </select>
                        </div>
                      </div>

                      <div className="space-y-1 text-xs">
                        <label className="font-bold text-[#5A5A40]">Tagline / Key Highlight:</label>
                        <input
                          type="text"
                          value={quickUpdateTagline}
                          onChange={(e) => setQuickUpdateTagline(e.target.value)}
                          placeholder="e.g. 4K Laser Dolby Atmos sound with luxury recliner seating"
                          className="w-full px-3 py-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          const itemTitle = quickUpdateName.trim() || 'New Destination Entry';
                          const newLog = {
                            id: `log-${Date.now()}`,
                            time: 'Just now',
                            text: `[${quickUpdateCityId.toUpperCase()}] ${itemTitle} (${quickUpdateCategory}) updated: ₹${quickUpdatePrice} · ${quickUpdateStatus}`
                          };
                          setLiveChangelogs((prev) => [newLog, ...prev]);
                          setQuickUpdateSuccessMsg(`✅ Successfully updated ${itemTitle} in ${quickUpdateCityId} database! Changes applied in real time.`);
                          setQuickUpdateName('');
                          setQuickUpdateTagline('');
                          setTimeout(() => setQuickUpdateSuccessMsg(null), 4000);
                        }}
                        className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                      >
                        <Sparkles className="w-4 h-4 text-stone-950" />
                        <span>Push Live Update to Database</span>
                      </button>
                    </div>

                    {/* Live Audit Changelog */}
                    <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3 flex flex-col justify-between shadow-2xs">
                      <div>
                        <h5 className="font-bold text-xs text-[#2D2D2A] uppercase tracking-wider pb-2 border-b border-[#F4F1EA] flex items-center justify-between">
                          <span>Live Updates Log:</span>
                          <span className="text-[10px] text-emerald-600 font-bold">Auto-Syncing</span>
                        </h5>

                        <div className="space-y-2 mt-3 max-h-80 overflow-y-auto pr-1">
                          {liveChangelogs.map((item) => (
                            <div key={item.id} className="p-2.5 rounded-xl bg-[#F4F1EA] text-xs space-y-1 border border-[#EAE7DC]">
                              <div className="flex justify-between text-[10px] text-[#8B8B6B]">
                                <span className="font-bold text-[#5A5A40]">SYSTEM EVENT</span>
                                <span>{item.time}</span>
                              </div>
                              <p className="text-[#2D2D2A] text-[11px] font-medium leading-relaxed">
                                {item.text}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-[#F4F1EA] text-[11px] text-[#8B8B6B]">
                        Authorized Administrator: <strong className="text-[#2D2D2A]">{ADMIN_NAME}</strong>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ========================================================= */}
              {/* === TAB 4: USER DATABASE === */}
              {/* ========================================================= */}
              {activeTab === 'users' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#2D2D2A]">
                        Registered Tourists & User Accounts ({users.length})
                      </h4>
                      <p className="text-xs text-[#8B8B6B]">
                        Click on any user to inspect their registered profile, spending, and ticket booking history.
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#5A5A40] bg-[#F4F1EA] px-2.5 py-1 rounded-lg border border-[#DEDACF]">
                      {filteredUsers.length} Users Listed
                    </span>
                  </div>

                  {selectedUser ? (
                    /* User Deep Dive Details */
                    <div className="p-5 bg-white rounded-2xl border border-[#E5E2D9] space-y-5 shadow-xs animate-in fade-in">
                      <div className="flex items-center justify-between pb-3 border-b border-[#E5E2D9]">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-[#5A5A40] text-white flex items-center justify-center font-bold text-lg">
                            {selectedUser.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-base text-[#2D2D2A] flex items-center gap-2">
                              <span>{selectedUser.name}</span>
                              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                                Verified User
                              </span>
                            </div>
                            <div className="text-xs text-[#8B8B6B] flex items-center gap-3 mt-0.5">
                              <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {selectedUser.email}</span>
                              <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {selectedUser.phone || 'N/A'}</span>
                              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Joined: {new Date(selectedUser.joinedAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedUser(null)}
                          className="px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-xs font-bold transition-colors cursor-pointer"
                        >
                          ← Back to User List
                        </button>
                      </div>

                      {/* User's Bookings & Activity Logs */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Bookings */}
                        <div className="space-y-2">
                          <h5 className="font-bold text-xs text-[#5A5A40] flex items-center gap-1.5">
                            <Ticket className="w-4 h-4 text-emerald-600" />
                            <span>Tickets Booked by this User</span>
                          </h5>
                          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                            {bookings.filter((b) => b.customerEmail === selectedUser.email || b.customerName.toLowerCase() === selectedUser.name.toLowerCase()).length > 0 ? (
                              bookings
                                .filter((b) => b.customerEmail === selectedUser.email || b.customerName.toLowerCase() === selectedUser.name.toLowerCase())
                                .map((b) => (
                                  <div key={b.id} className="p-3 rounded-xl bg-[#FDFCF8] border border-[#E5E2D9] space-y-1.5 text-xs">
                                    <div className="flex items-center justify-between">
                                      <span className="font-bold text-[#2D2D2A]">{b.itemTitle}</span>
                                      <span className="font-bold text-emerald-700">{b.currency}{b.totalAmount}</span>
                                    </div>
                                    <div className="text-[11px] text-[#8B8B6B] flex items-center justify-between">
                                      <span>Ref: {b.bookingRef} · {b.serviceDate}</span>
                                      <span className="px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[9px] font-bold">CONFIRMED</span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => downloadTicketPDF(b, b.cityName)}
                                      className="text-[10px] font-bold text-emerald-700 hover:underline flex items-center gap-1 pt-1 cursor-pointer"
                                    >
                                      <Download className="w-3 h-3" /> Download PDF Ticket
                                    </button>
                                  </div>
                                ))
                            ) : (
                              <div className="p-4 rounded-xl bg-[#F4F1EA] text-center text-xs text-[#8B8B6B]">
                                No tickets booked yet by this user.
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Activity Timeline */}
                        <div className="space-y-2">
                          <h5 className="font-bold text-xs text-[#5A5A40] flex items-center gap-1.5">
                            <Clock className="w-4 h-4 text-blue-600" />
                            <span>User Activity & Login Timeline</span>
                          </h5>
                          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                            {selectedUser.activityLogs && selectedUser.activityLogs.length > 0 ? (
                              selectedUser.activityLogs.map((log) => (
                                <div key={log.id} className="p-2.5 rounded-xl bg-[#FDFCF8] border border-[#E5E2D9] text-xs">
                                  <div className="text-[#2D2D2A] font-semibold">{log.action}</div>
                                  <div className="text-[10px] text-[#8B8B6B] mt-0.5">
                                    {new Date(log.timestamp).toLocaleString()}
                                  </div>
                                </div>
                              ))
                            ) : (
                              <div className="p-4 rounded-xl bg-[#F4F1EA] text-center text-xs text-[#8B8B6B]">
                                No recent activity logged.
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* User Table List */
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                      {filteredUsers.map((u) => {
                        const userBookings = bookings.filter(
                          (b) => b.customerEmail === u.email || b.customerName.toLowerCase() === u.name.toLowerCase()
                        );
                        const userSpend = userBookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);

                        return (
                          <div
                            key={u.id}
                            onClick={() => setSelectedUser(u)}
                            className="p-4 rounded-2xl bg-white border border-[#E5E2D9] hover:border-[#5A5A40] cursor-pointer transition-all hover:shadow-md space-y-3"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-[#5A5A40] text-white flex items-center justify-center font-bold text-sm shrink-0">
                                {u.name.charAt(0).toUpperCase()}
                              </div>
                              <div className="min-w-0 flex-1">
                                <h5 className="font-bold text-sm text-[#2D2D2A] truncate">{u.name}</h5>
                                <p className="text-[11px] text-[#8B8B6B] truncate">{u.email}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-[#E5E2D9]">
                              <div>
                                <span className="text-[#8B8B6B] block">Tickets Booked</span>
                                <strong className="text-[#2D2D2A]">{userBookings.length} Bookings</strong>
                              </div>
                              <div>
                                <span className="text-[#8B8B6B] block">Total Spent</span>
                                <strong className="text-emerald-700">₹{userSpend.toLocaleString()}</strong>
                              </div>
                            </div>

                            <div className="text-[10px] text-[#8B8B6B] flex items-center justify-between pt-1 text-right">
                              <span>Joined: {new Date(u.joinedAt).toLocaleDateString()}</span>
                              <span className="text-amber-800 font-bold hover:underline">Inspect User →</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* ========================================================= */}
              {/* === TAB 4: BOOKINGS & ACTIVITY DATABASE === */}
              {/* ========================================================= */}
              {activeTab === 'bookings' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#2D2D2A]">
                        Live Ticket Bookings & Reservations ({bookings.length})
                      </h4>
                      <p className="text-xs text-[#8B8B6B]">
                        Real-time audit log of all tickets booked across cinemas, darshans, tables, sights & events.
                      </p>
                    </div>

                    {/* Category Filter */}
                    <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
                      {['all', 'theatre', 'temple', 'restaurant', 'attraction', 'event'].map((cat) => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setCategoryFilter(cat)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${
                            categoryFilter === cat
                              ? 'bg-[#5A5A40] text-white'
                              : 'bg-[#F4F1EA] text-[#8B8B6B] hover:text-[#2D2D2A]'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {filteredBookings.length === 0 ? (
                    <div className="p-8 bg-white rounded-2xl border border-[#E5E2D9] text-center space-y-2">
                      <Ticket className="w-8 h-8 text-[#8B8B6B] mx-auto" />
                      <div className="font-bold text-sm text-[#2D2D2A]">No bookings found</div>
                      <p className="text-xs text-[#8B8B6B]">Try changing your search keywords or category filters.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {filteredBookings.map((b) => (
                        <div
                          key={b.id}
                          className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3 hover:shadow-md transition-shadow"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                                  b.category === 'theatre' ? 'bg-amber-100 text-amber-800' :
                                  b.category === 'temple' ? 'bg-orange-100 text-orange-800' :
                                  b.category === 'restaurant' ? 'bg-emerald-100 text-emerald-800' :
                                  b.category === 'attraction' ? 'bg-purple-100 text-purple-800' :
                                  'bg-rose-100 text-rose-800'
                                }`}>
                                  {b.category}
                                </span>
                                <span className="text-xs font-bold text-[#8B8B6B]">
                                  {b.cityName}
                                </span>
                              </div>
                              <h5 className="font-bold text-sm text-[#2D2D2A] mt-1 leading-tight">
                                {b.itemTitle}
                              </h5>
                              <div className="text-[11px] text-[#8B8B6B] mt-0.5">
                                Ref PNR: <span className="font-mono font-bold text-[#2D2D2A]">{b.bookingRef}</span>
                              </div>
                            </div>

                            <div className="text-right shrink-0">
                              <span className="text-sm font-bold text-emerald-700 block">
                                {b.currency}{b.totalAmount}
                              </span>
                              <span className="px-1.5 py-0.5 rounded-sm bg-emerald-50 text-emerald-800 text-[9px] font-bold">
                                {b.paymentStatus.includes('PAID') ? 'PAID' : 'PAY AT VENUE'}
                              </span>
                            </div>
                          </div>

                          {/* Customer info & reservation specifics */}
                          <div className="p-2.5 rounded-xl bg-[#FDFCF8] border border-[#EAE7DC] text-xs space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[#8B8B6B]">Tourist / Customer:</span>
                              <span className="font-bold text-[#2D2D2A]">{b.customerName}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-[#8B8B6B]">Contact:</span>
                              <span className="text-[#5A5A40]">{b.customerPhone} · {b.customerEmail}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-[#8B8B6B]">Date & Slot:</span>
                              <span className="font-semibold text-[#2D2D2A]">{b.serviceDate} ({b.serviceTime || 'Slot'})</span>
                            </div>
                            {b.details?.selectedSeats && (
                              <div className="flex items-center justify-between text-amber-800 font-medium">
                                <span>Seats:</span>
                                <span>{b.details.selectedSeats.join(', ')}</span>
                              </div>
                            )}
                            {b.details?.darshanType && (
                              <div className="flex items-center justify-between text-orange-800 font-medium">
                                <span>Darshan Tier:</span>
                                <span>{b.details.darshanType} ({b.details.devoteeCount} Devotees)</span>
                              </div>
                            )}
                          </div>

                          {/* Footer Action */}
                          <div className="flex items-center justify-between pt-1 border-t border-[#E5E2D9] text-xs">
                            <span className="text-[10px] text-[#8B8B6B]">
                              Booked on {new Date(b.createdAt || b.bookingDate).toLocaleDateString()}
                            </span>
                            <button
                              type="button"
                              onClick={() => downloadTicketPDF(b, b.cityName, false)}
                              className="px-2.5 py-1 rounded-lg bg-[#5A5A40] hover:bg-[#484832] text-white font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Download className="w-3 h-3" />
                              <span>Download PDF</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* ========================================================= */}
              {/* === TAB 5: SYSTEM ANALYTICS === */}
              {/* ========================================================= */}
              {activeTab === 'analytics' && (
                <div className="space-y-5">
                  <div className="p-5 rounded-2xl bg-gradient-to-r from-[#2D2D2A] to-[#484833] text-white space-y-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-amber-400" />
                      <h4 className="font-serif font-bold text-lg">System Performance & Tourism Pulse</h4>
                    </div>
                    <p className="text-xs text-stone-300">
                      High-level metrics across all 28 States, 8 Union Territories, active cities, bookings, and platform activity.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-2">
                      <span className="text-xs font-bold text-[#8B8B6B] block">Total Database Coverage</span>
                      <div className="text-2xl font-bold font-serif text-[#2D2D2A]">
                        {totalDistrictsCount} Districts
                      </div>
                      <p className="text-xs text-[#5A5A40]">Across all 36 Indian States and Union Territories.</p>
                    </div>

                    <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-2">
                      <span className="text-xs font-bold text-[#8B8B6B] block">Average Booking Value</span>
                      <div className="text-2xl font-bold font-serif text-emerald-700">
                        ₹{bookings.length > 0 ? Math.round(totalRevenue / bookings.length).toLocaleString() : '0'}
                      </div>
                      <p className="text-xs text-[#5A5A40]">Calculated across verified reservations.</p>
                    </div>

                    <div className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-2">
                      <span className="text-xs font-bold text-[#8B8B6B] block">Platform Health & Uptime</span>
                      <div className="text-2xl font-bold font-serif text-blue-700 flex items-center gap-2">
                        <span>100% Operational</span>
                      </div>
                      <p className="text-xs text-[#5A5A40]">PDF generator, QR scanner & interactive guides ready.</p>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
