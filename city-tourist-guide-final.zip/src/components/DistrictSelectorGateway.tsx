import React, { useState, useMemo } from 'react';
import { 
  Search, 
  MapPin, 
  Compass, 
  Sparkles, 
  ArrowRight, 
  Film, 
  UtensilsCrossed, 
  Landmark, 
  Layers,
  ChevronRight,
  Filter,
  Check
} from 'lucide-react';
import { 
  ALL_INDIAN_STATES_AND_UTS, 
  StateInfo, 
  DistrictInfo, 
  convertDistrictToCity, 
  generatePlacesForDistrict 
} from '../data/indiaStatesAndDistricts';
import { City, Place } from '../types';

interface DistrictSelectorGatewayProps {
  onSelectDistrict: (city: City, places: Place[]) => void;
  activeCityId?: string;
}

export const DistrictSelectorGateway: React.FC<DistrictSelectorGatewayProps> = ({
  onSelectDistrict,
  activeCityId,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStateId, setSelectedStateId] = useState<string>('karnataka'); // Default to Karnataka with Davanagere, Bangalore, Mysore, etc.

  // Extract all states
  const states = useMemo(() => ALL_INDIAN_STATES_AND_UTS || [], []);
  const currentState = useMemo(
    () => states.find((s) => s.id === selectedStateId) || states[0],
    [states, selectedStateId]
  );

  // Filter districts based on search or selected state
  const displayedDistricts = useMemo(() => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const allDistricts: { district: DistrictInfo; stateName: string }[] = [];
      states.forEach((st) => {
        st.districts.forEach((d) => {
          if (
            d.name.toLowerCase().includes(q) ||
            d.tagline.toLowerCase().includes(q) ||
            d.famousFood.some((f) => f.toLowerCase().includes(q)) ||
            d.highlights.some((h) => h.toLowerCase().includes(q)) ||
            st.name.toLowerCase().includes(q)
          ) {
            allDistricts.push({ district: d, stateName: st.name });
          }
        });
      });
      return allDistricts;
    }

    return (currentState.districts || []).map((d) => ({
      district: d,
      stateName: currentState.name,
    }));
  }, [states, currentState, searchQuery]);

  const handlePickDistrict = (dist: DistrictInfo) => {
    const city = convertDistrictToCity(dist);
    const places = generatePlacesForDistrict(dist);
    onSelectDistrict(city, places);
  };

  return (
    <div className="w-full space-y-6">
      
      {/* Hero Welcome Banner - Clean, Uncluttered, Inspiring */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#2D2D2A] via-[#3E3E37] to-[#5A5A40] text-white p-6 sm:p-10 shadow-xl border border-stone-800">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/30 text-amber-300 text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Welcome to City Tourist Guide · Choose Your Destination</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-serif font-extrabold tracking-tight text-white leading-tight">
            Explore the City or District You Want
          </h2>

          <p className="text-sm sm:text-base text-[#DEDACF] leading-relaxed max-w-2xl">
            Select any district below (like <strong className="text-amber-300 font-bold">Davanagere</strong>, Bengaluru, or Mysuru) to unlock curated attractions, live running cinema shows, sacred crowd hours, famous local cuisines, and travel cost estimates.
          </p>

          {/* Clean Search Input */}
          <div className="relative max-w-xl pt-2">
            <Search className="w-5 h-5 text-stone-400 absolute left-4 top-1/2 -translate-y-1/2 pt-1" />
            <input
              type="text"
              placeholder="Search by district name, famous food (e.g. Benne Dosa), or temple..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white text-stone-900 placeholder:text-stone-400 text-sm font-medium border border-stone-200 focus:outline-hidden focus:ring-2 focus:ring-amber-400 shadow-md"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 pt-1 text-xs text-stone-400 hover:text-stone-700 font-bold"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {/* State Switcher & Quick Navigation Bar */}
      {!searchQuery && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Compass className="w-5 h-5 text-[#5A5A40]" />
              <h3 className="font-serif font-bold text-lg text-[#2D2D2A]">
                Select Region or Jump to Popular Districts:
              </h3>
            </div>

            {/* State Switcher Dropdown */}
            <select
              value={selectedStateId}
              onChange={(e) => setSelectedStateId(e.target.value)}
              className="px-3.5 py-2 rounded-xl bg-white border border-[#DEDACF] text-xs font-bold text-[#2D2D2A] focus:outline-hidden cursor-pointer shadow-xs"
            >
              {states.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name} ({st.districts.length} Districts) — {st.type}
                </option>
              ))}
            </select>
          </div>

          {/* Quick-Jump District Chips (Highlighting Karnataka Districts) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin text-xs">
            <span className="text-[#8B8B6B] font-bold text-[11px] uppercase tracking-wider shrink-0">
              Quick Pick:
            </span>
            {[
              { id: 'davanagere', name: 'Davanagere ⭐', stateId: 'karnataka' },
              { id: 'bengaluru-urban', name: 'Bengaluru Urban', stateId: 'karnataka' },
              { id: 'mysuru', name: 'Mysuru (Palace City)', stateId: 'karnataka' },
              { id: 'dharwad', name: 'Hubballi-Dharwad', stateId: 'karnataka' },
              { id: 'dakshina-kannada', name: 'Mangaluru Coastal', stateId: 'karnataka' },
              { id: 'shivamogga', name: 'Shivamogga (Jog Falls)', stateId: 'karnataka' },
              { id: 'belagavi', name: 'Belagavi', stateId: 'karnataka' },
              { id: 'udupi', name: 'Udupi (Krishna Temple)', stateId: 'karnataka' },
              { id: 'hassan', name: 'Hassan (Belur-Halebeedu)', stateId: 'karnataka' },
              { id: 'ballari', name: 'Ballari (Hampi Ruins)', stateId: 'karnataka' },
              { id: 'mumbai', name: 'Mumbai City', stateId: 'maharashtra' },
              { id: 'new-delhi', name: 'New Delhi', stateId: 'delhi' },
            ].map((chip) => {
              const isSelected = activeCityId === chip.id;
              return (
                <button
                  key={chip.id}
                  type="button"
                  onClick={() => {
                    const foundState = states.find((s) => s.id === chip.stateId);
                    if (foundState) {
                      const foundDist = foundState.districts.find((d) => d.id === chip.id);
                      if (foundDist) {
                        handlePickDistrict(foundDist);
                      }
                    }
                  }}
                  className={`px-3.5 py-1.5 rounded-full whitespace-nowrap font-bold text-xs transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-white hover:bg-[#F4F1EA] text-[#5A5A40] border border-[#DEDACF]'
                  }`}
                >
                  {chip.name}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* District Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {displayedDistricts.map(({ district, stateName }) => {
          const isCurrentActive = activeCityId === district.id;

          return (
            <div
              key={district.id}
              onClick={() => handlePickDistrict(district)}
              className={`group rounded-3xl bg-white border overflow-hidden shadow-xs hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                isCurrentActive
                  ? 'border-amber-400 ring-2 ring-amber-400/50 shadow-md'
                  : 'border-[#E5E2D9] hover:border-[#5A5A40]'
              }`}
            >
              <div>
                {/* Photo Header */}
                <div className="relative h-44 w-full overflow-hidden bg-stone-900">
                  <img
                    src={district.coverImage}
                    alt={district.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-[0.82]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase bg-black/60 text-white backdrop-blur-md border border-white/20">
                      📍 {stateName}
                    </span>
                    {district.id === 'davanagere' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-amber-400 text-stone-950">
                        Popular Pick
                      </span>
                    )}
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <h4 className="font-serif font-bold text-xl leading-tight text-white flex items-center justify-between">
                      <span>{district.name}</span>
                      <ArrowRight className="w-5 h-5 text-amber-300 transform group-hover:translate-x-1 transition-transform" />
                    </h4>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-4 space-y-3 text-xs">
                  <p className="text-[#5A5A40] text-xs font-medium leading-relaxed line-clamp-2">
                    {district.tagline}
                  </p>

                  {/* Highlights & Highlights Tags */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-start gap-1.5 text-[11px] text-[#2D2D2A]">
                      <UtensilsCrossed className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span className="line-clamp-1 font-semibold">
                        {district.famousFood?.[0] || 'Local Gastronomy'}
                      </span>
                    </div>

                    <div className="flex items-start gap-1.5 text-[11px] text-[#2D2D2A]">
                      <Landmark className="w-3.5 h-3.5 text-[#5A5A40] shrink-0 mt-0.5" />
                      <span className="line-clamp-1">
                        {district.temples?.[0] || 'Historical Sacred Shrines'}
                      </span>
                    </div>

                    <div className="flex items-start gap-1.5 text-[11px] text-[#2D2D2A]">
                      <Film className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">
                        {district.theatres?.[0] || '4K Laser Cinemas Running Live'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Action Footer */}
              <div className="p-3 bg-[#FDFCF8] border-t border-[#F4F1EA] flex items-center justify-between">
                <span className="text-[11px] text-[#8B8B6B]">
                  {district.highlights?.length || 4}+ Curated Points
                </span>
                <span className="text-xs font-bold text-[#5A5A40] group-hover:text-[#2D2D2A] flex items-center gap-1">
                  <span>Explore District</span>
                  <ChevronRight className="w-4 h-4" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
