import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { 
  X, 
  Film, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  Ticket, 
  Eye, 
  RotateCcw, 
  Layers, 
  Maximize2,
  ChevronDown,
  ChevronUp,
  Download,
  Calendar,
  Clock,
  MapPin,
  Info
} from 'lucide-react';
import { Place, MovieShow } from '../types';
import { generateTicketQRCodeDataURL, downloadTicketPDF } from '../utils/pdfTicketGenerator';

interface ThreeDTheatreBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  theatre: Place;
  movie?: MovieShow;
  showtime?: any;
  onBookingConfirmed: (bookingData: {
    movieTitle: string;
    theatreName: string;
    showtime: string;
    seats: string[];
    totalAmount: number;
    bookingRef: string;
  }) => void;
}

interface Seat3D {
  id: string;
  row: string;
  col: number;
  tier: 'Recliner' | 'Gold' | 'Silver';
  price: number;
  status: 'available' | 'booked' | 'selected';
  x: number;
  y: number;
  z: number;
  mesh?: THREE.Group;
}

export const ThreeDTheatreBookingModal: React.FC<ThreeDTheatreBookingModalProps> = ({
  isOpen,
  onClose,
  theatre,
  movie,
  showtime,
  onBookingConfirmed,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());
  const seatsRef = useRef<Seat3D[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const targetCamPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 10, 22));
  const targetCamLookRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 3, 0));

  // Fallback movie details if not provided
  const activeMovie = movie || theatre.movies?.[0] || {
    id: 'mov-default',
    title: 'Kantara: Chapter 1',
    poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&q=80',
    language: 'Kannada, Hindi, Telugu, English',
    format: 'Dolby Atmos 4K Laser 3D',
    duration: '2h 45m',
    genre: ['Mythological Action', 'Folklore Thriller'],
    rating: 9.3,
  };

  const activeShow = showtime || {
    id: 'show-prime',
    time: '06:30 PM',
    price: 250,
    currency: '₹',
    seatAvailability: 'Available',
    screenType: 'Screen 1 (Laser 4K)',
  };

  // State
  const [selectedSeatIds, setSelectedSeatIds] = useState<string[]>(['E7', 'E8']);
  const [hoveredSeat, setHoveredSeat] = useState<Seat3D | null>(null);
  const [isViewFromSeat, setIsViewFromSeat] = useState(false);
  const [currentSeatViewId, setCurrentSeatViewId] = useState<string | null>(null);
  const [isBottomDockCollapsed, setIsBottomDockCollapsed] = useState(false);
  const [viewMode, setViewMode] = useState<'3d' | '2d'>('3d');
  const [isSoundOn, setIsSoundOn] = useState(true);
  const [isBookingSuccess, setIsBookingSuccess] = useState(false);
  const [bookingConfirmation, setBookingConfirmation] = useState<{
    ref: string;
    qr: string;
    seats: string[];
    amount: number;
  } | null>(null);

  // Initialize Seat Grid
  const initializeSeats = (): Seat3D[] => {
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const colsPerRow = 12;
    const list: Seat3D[] = [];

    rows.forEach((row, rIdx) => {
      let tier: 'Recliner' | 'Gold' | 'Silver' = 'Silver';
      let price = activeShow.price;

      if (row === 'A' || row === 'B') {
        tier = 'Recliner';
        price = activeShow.price + 180;
      } else if (row === 'C' || row === 'D' || row === 'E') {
        tier = 'Gold';
        price = activeShow.price + 60;
      } else {
        tier = 'Silver';
        price = activeShow.price;
      }

      for (let c = 1; c <= colsPerRow; c++) {
        // Pre-book a few random seats for realism
        const isBooked = (rIdx === 2 && (c === 5 || c === 6)) || 
                         (rIdx === 4 && (c === 3 || c === 4)) || 
                         (rIdx === 0 && (c === 8 || c === 9));

        const seatId = `${row}${c}`;
        const isPreselected = seatId === 'E7' || seatId === 'E8';

        // 3D positioning
        // Curved amphitheatre arc
        const xOffset = (c - (colsPerRow + 1) / 2) * 1.5;
        const zOffset = 14 - rIdx * 2.4;
        const yOffset = (7 - rIdx) * 0.75 + 0.4;

        list.push({
          id: seatId,
          row,
          col: c,
          tier,
          price,
          status: isBooked ? 'booked' : isPreselected ? 'selected' : 'available',
          x: xOffset,
          y: yOffset,
          z: zOffset,
        });
      }
    });

    return list;
  };

  // Build Three.js 3D Cinema Hall
  useEffect(() => {
    if (!isOpen || viewMode !== '3d' || !mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 560;

    // Detect software rendering guard
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch (e) {
        return true;
      }
    })();

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0e0e11);
    scene.fog = new THREE.FogExp2(0x0e0e11, 0.025);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.set(0, 10, 22);
    camera.lookAt(0, 3, 0);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: !isSoftwareGl, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.replaceChildren(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x221a24, 1.2);
    scene.add(ambientLight);

    // Warm ceiling downlights
    const downLight = new THREE.DirectionalLight(0xffeedd, 1.0);
    downLight.position.set(0, 18, 10);
    scene.add(downLight);

    // Projector light beam from rear booth
    const projectorLight = new THREE.SpotLight(0xaad4ff, 12, 45, Math.PI / 7, 0.45);
    projectorLight.position.set(0, 12, 28);
    projectorLight.target.position.set(0, 4, -4);
    scene.add(projectorLight);
    scene.add(projectorLight.target);

    // Screen ambient glow
    const screenGlowLight = new THREE.PointLight(0x4095ff, 4, 25);
    screenGlowLight.position.set(0, 4, -2);
    scene.add(screenGlowLight);

    // 5. Curved 3D Silver Cinema Screen
    const screenGeo = new THREE.CylinderGeometry(24, 24, 9, 32, 1, true, -Math.PI / 7, (2 * Math.PI) / 7);
    const screenCanvas = document.createElement('canvas');
    screenCanvas.width = 1024;
    screenCanvas.height = 512;
    const ctx = screenCanvas.getContext('2d');
    if (ctx) {
      // Draw simulated movie scene on screen
      const grad = ctx.createLinearGradient(0, 0, 1024, 512);
      grad.addColorStop(0, '#100a1c');
      grad.addColorStop(0.5, '#2e1c3b');
      grad.addColorStop(1, '#09152b');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1024, 512);

      // Silver screen border & text
      ctx.strokeStyle = '#e2b34a';
      ctx.lineWidth = 14;
      ctx.strokeRect(20, 20, 984, 472);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 44px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(activeMovie.title.toUpperCase(), 512, 200);

      ctx.fillStyle = '#f5c542';
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText(`⚡ DOLBY ATMOS 7.1 · 4K LASER 3D · ${activeShow.screenType}`, 512, 260);

      ctx.fillStyle = '#cbd5e1';
      ctx.font = '22px sans-serif';
      ctx.fillText(`LIVE SCREENING NOW · ${activeShow.time} SHOW`, 512, 320);
    }
    const screenTexture = new THREE.CanvasTexture(screenCanvas);
    screenTexture.colorSpace = THREE.SRGBColorSpace;

    const screenMat = new THREE.MeshStandardMaterial({
      map: screenTexture,
      roughness: 0.25,
      metalness: 0.1,
      emissive: new THREE.Color(0x1a2638),
      emissiveIntensity: 0.8,
      side: THREE.DoubleSide,
    });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.set(0, 4.5, -4);
    screenMesh.rotation.y = Math.PI;
    scene.add(screenMesh);

    // Screen frame
    const frameGeo = new THREE.BoxGeometry(22, 0.4, 0.8);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x1f1f23, roughness: 0.7 });
    const topFrame = new THREE.Mesh(frameGeo, frameMat);
    topFrame.position.set(0, 9.2, -4);
    scene.add(topFrame);
    const bottomFrame = new THREE.Mesh(frameGeo, frameMat);
    bottomFrame.position.set(0, -0.2, -4);
    scene.add(bottomFrame);

    // 6. Tiered Auditorium Steps & Carpet
    for (let i = 0; i < 9; i++) {
      const stepWidth = 24;
      const stepDepth = 2.6;
      const stepHeight = 0.75;
      const stepGeo = new THREE.BoxGeometry(stepWidth, stepHeight, stepDepth);
      const stepMat = new THREE.MeshStandardMaterial({
        color: i % 2 === 0 ? 0x18151f : 0x14121a,
        roughness: 0.9,
      });
      const stepMesh = new THREE.Mesh(stepGeo, stepMat);
      stepMesh.position.set(0, (7 - i) * 0.75, 14 - i * 2.4);
      scene.add(stepMesh);
    }

    // Aisle LED runner lights
    const aislePoints = [
      new THREE.Vector3(-10.5, 0.2, -2),
      new THREE.Vector3(-10.5, 6.5, 16),
      new THREE.Vector3(10.5, 0.2, -2),
      new THREE.Vector3(10.5, 6.5, 16),
    ];
    aislePoints.forEach((pt) => {
      const ledLight = new THREE.PointLight(0xf59e0b, 1.2, 4);
      ledLight.position.copy(pt);
      scene.add(ledLight);
    });

    // 7. Generate 3D Interactive Seats
    const seatList = initializeSeats();
    seatsRef.current = seatList;

    // Materials
    const matAvailableSilver = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.5 });
    const matAvailableGold = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.4 });
    const matAvailableRecliner = new THREE.MeshStandardMaterial({ color: 0x881337, roughness: 0.35 });
    const matSelected = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.2, emissive: 0x064e3b, emissiveIntensity: 0.5 });
    const matBooked = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 });

    seatList.forEach((seat) => {
      const seatGroup = new THREE.Group();
      (seatGroup as any).seatData = seat;

      // Select material
      let seatMat = matAvailableSilver;
      if (seat.status === 'selected') seatMat = matSelected;
      else if (seat.status === 'booked') seatMat = matBooked;
      else if (seat.tier === 'Recliner') seatMat = matAvailableRecliner;
      else if (seat.tier === 'Gold') seatMat = matAvailableGold;

      // Cushion
      const cushionGeo = new THREE.BoxGeometry(0.9, 0.25, 0.85);
      const cushion = new THREE.Mesh(cushionGeo, seatMat);
      cushion.position.y = 0.25;
      seatGroup.add(cushion);

      // Backrest
      const backGeo = new THREE.BoxGeometry(0.9, 1.0, 0.22);
      const back = new THREE.Mesh(backGeo, seatMat);
      back.position.set(0, 0.8, -0.32);
      back.rotation.x = -0.12;
      seatGroup.add(back);

      // Headrest
      const headGeo = new THREE.BoxGeometry(0.65, 0.35, 0.24);
      const head = new THREE.Mesh(headGeo, seatMat);
      head.position.set(0, 1.4, -0.4);
      seatGroup.add(head);

      // Armrests
      const armGeo = new THREE.BoxGeometry(0.14, 0.35, 0.7);
      const armMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6 });
      const leftArm = new THREE.Mesh(armGeo, armMat);
      leftArm.position.set(-0.52, 0.5, -0.05);
      const rightArm = new THREE.Mesh(armGeo, armMat);
      rightArm.position.set(0.52, 0.5, -0.05);
      seatGroup.add(leftArm);
      seatGroup.add(rightArm);

      seatGroup.position.set(seat.x, seat.y, seat.z);
      // Gentle orientation toward center screen
      seatGroup.lookAt(0, 3, -4);
      seat.mesh = seatGroup;

      scene.add(seatGroup);
    });

    // 8. Robust 360° Hand Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.rotateSpeed = 0.95;
    controls.zoomSpeed = 1.1;
    controls.panSpeed = 0.8;
    controls.minDistance = 5;
    controls.maxDistance = 38;
    controls.maxPolarAngle = Math.PI / 2 + 0.05; // Keep camera above floor
    controls.minPolarAngle = 0.05;
    controls.target.set(0, 3, 0);
    controlsRef.current = controls;

    // Distinguish genuine click (tap seat) from 360° hand rotation drag
    let pointerDownPos = { x: 0, y: 0 };
    let pointerDownTime = 0;

    const handlePointerDown = (e: PointerEvent) => {
      pointerDownPos = { x: e.clientX, y: e.clientY };
      pointerDownTime = performance.now();
    };

    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      // Hover detection
      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      const intersects = raycasterRef.current.intersectObjects(scene.children, true);

      let foundSeat: Seat3D | null = null;
      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && curr !== scene) {
          if ((curr as any).seatData) {
            foundSeat = (curr as any).seatData;
            break;
          }
          curr = curr.parent;
        }
        if (foundSeat) break;
      }
      setHoveredSeat(foundSeat);
    };

    const handlePointerUp = (e: PointerEvent) => {
      const dist = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
      const duration = performance.now() - pointerDownTime;

      // If user moved more than 7px or held longer than 450ms, it was a 360° rotation drag, NOT a seat tap!
      if (dist > 7 || duration > 450) return;

      const rect = container.getBoundingClientRect();
      mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      const intersects = raycasterRef.current.intersectObjects(scene.children, true);

      for (const hit of intersects) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && curr !== scene) {
          if ((curr as any).seatData) {
            const seat = (curr as any).seatData as Seat3D;
            if (seat.status !== 'booked') {
              toggleSeatSelection(seat.id);
            }
            return;
          }
          curr = curr.parent;
        }
      }
    };

    container.addEventListener('pointerdown', handlePointerDown);
    container.addEventListener('pointermove', handlePointerMove);
    container.addEventListener('pointerup', handlePointerUp);

    // 9. Continuous Smooth Render Loop with OrbitControls Update
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // 10. Robust ResizeObserver (guarantees pixel-perfect sizing on open & resize)
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      controls.dispose();
      container.removeEventListener('pointerdown', handlePointerDown);
      container.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('pointerup', handlePointerUp);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
    };
  }, [isOpen, viewMode, activeMovie, activeShow]);

  // Update Seat Colors in Three.js Scene on Selection Change
  useEffect(() => {
    if (!sceneRef.current || viewMode !== '3d') return;

    seatsRef.current.forEach((seat) => {
      const isSelected = selectedSeatIds.includes(seat.id);
      if (!seat.mesh) return;

      const newStatus = seat.status === 'booked' ? 'booked' : isSelected ? 'selected' : 'available';
      seat.status = newStatus;

      let targetColor = 0x475569;
      let emissiveColor = 0x000000;
      let emissiveIntensity = 0;

      if (newStatus === 'selected') {
        targetColor = 0x10b981;
        emissiveColor = 0x064e3b;
        emissiveIntensity = 0.6;
      } else if (newStatus === 'booked') {
        targetColor = 0x1e293b;
      } else if (seat.tier === 'Recliner') {
        targetColor = 0x881337;
      } else if (seat.tier === 'Gold') {
        targetColor = 0xb45309;
      }

      seat.mesh.traverse((child) => {
        if ((child as THREE.Mesh).isMesh && (child as THREE.Mesh).material) {
          const mat = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
          if (mat.name !== 'armrest') {
            mat.color.setHex(targetColor);
            if (mat.emissive) {
              mat.emissive.setHex(emissiveColor);
              mat.emissiveIntensity = emissiveIntensity;
            }
          }
        }
      });
    });
  }, [selectedSeatIds, viewMode]);

  // Toggle Seat Selection
  const toggleSeatSelection = (seatId: string) => {
    setSelectedSeatIds((prev) => {
      if (prev.includes(seatId)) {
        return prev.filter((id) => id !== seatId);
      } else {
        if (prev.length >= 8) {
          alert('Maximum 8 tickets per transaction');
          return prev;
        }
        return [...prev, seatId];
      }
    });
  };

  // Switch Camera to View Directly from Seat
  const handlePreviewViewFromSeat = (seatId: string) => {
    const seat = seatsRef.current.find((s) => s.id === seatId);
    if (!seat || !cameraRef.current || !controlsRef.current) return;

    setIsViewFromSeat(true);
    setCurrentSeatViewId(seatId);

    // Camera placed directly at seat eye-level, target focused on screen
    cameraRef.current.position.set(seat.x, seat.y + 1.15, seat.z - 0.15);
    controlsRef.current.target.set(0, 4.5, -4);
    controlsRef.current.update();
  };

  const handleResetCamera = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    setIsViewFromSeat(false);
    setCurrentSeatViewId(null);
    cameraRef.current.position.set(0, 10, 22);
    controlsRef.current.target.set(0, 3, 0);
    controlsRef.current.update();
  };

  // Price Calculation
  const calculateTotal = () => {
    let sum = 0;
    selectedSeatIds.forEach((id) => {
      const row = id.charAt(0);
      if (row === 'A' || row === 'B') sum += activeShow.price + 180;
      else if (row === 'C' || row === 'D' || row === 'E') sum += activeShow.price + 60;
      else sum += activeShow.price;
    });
    return sum;
  };

  // Booking Execution
  const handleConfirmBooking = async () => {
    if (selectedSeatIds.length === 0) return;

    const bookingRef = `CINE-${theatre.cityId?.slice(0, 3).toUpperCase() || 'IND'}-${Math.floor(100000 + Math.random() * 900000)}`;
    const totalAmount = calculateTotal();

    const qrData = await generateTicketQRCodeDataURL(JSON.stringify({
      bookingRef,
      itemTitle: `${activeMovie.title} (${theatre.name})`,
      category: 'theatre',
      customerName: 'Guest Movie Buff',
      date: 'Today',
      time: activeShow.time,
      seats: selectedSeatIds,
      totalAmount,
      currency: '₹',
    }));

    setBookingConfirmation({
      ref: bookingRef,
      qr: qrData,
      seats: selectedSeatIds,
      amount: totalAmount,
    });
    setIsBookingSuccess(true);

    onBookingConfirmed({
      movieTitle: activeMovie.title,
      theatreName: theatre.name,
      showtime: activeShow.time,
      seats: selectedSeatIds,
      totalAmount,
      bookingRef,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-hidden animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[92vh] max-h-[820px] bg-[#141416] text-white rounded-3xl border border-stone-800 shadow-2xl flex flex-col overflow-hidden">
        
        {/* Top Header Bar */}
        <div className="px-5 py-3.5 bg-[#1a1a1e] border-b border-stone-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif font-bold text-base sm:text-lg text-white">
                  {theatre.name}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  3D Auditorium
                </span>
              </div>
              <p className="text-xs text-stone-400">
                {activeMovie.title} · {activeShow.time} ({activeShow.screenType})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* 2D / 3D Switch */}
            <div className="flex items-center bg-stone-900 border border-stone-700 rounded-xl p-1 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('3d')}
                className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                  viewMode === '3d' ? 'bg-amber-500 text-stone-950 shadow-xs' : 'text-stone-400 hover:text-white'
                }`}
              >
                3D View
              </button>
              <button
                type="button"
                onClick={() => setViewMode('2d')}
                className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                  viewMode === '2d' ? 'bg-amber-500 text-stone-950 shadow-xs' : 'text-stone-400 hover:text-white'
                }`}
              >
                2D Plan
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Success Modal Overlay */}
        {isBookingSuccess && bookingConfirmation && (
          <div className="absolute inset-0 z-50 bg-[#141416]/95 backdrop-blur-md flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-stone-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-xl text-white">Seats Confirmed!</h4>
                <p className="text-xs text-stone-400 mt-1">
                  Your ticket has been booked and synced to your Digital Wallet.
                </p>
              </div>

              <div className="p-4 bg-stone-950 rounded-2xl border border-stone-800 text-left space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-stone-400">Movie:</span>
                  <span className="font-bold text-white">{activeMovie.title}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-stone-400">Theatre:</span>
                  <span className="font-bold text-white">{theatre.name}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-stone-400">Showtime:</span>
                  <span className="font-bold text-amber-300">{activeShow.time} Today</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-stone-400">Seats:</span>
                  <span className="font-bold text-emerald-400">{bookingConfirmation.seats.join(', ')}</span>
                </div>
                <div className="flex justify-between text-xs border-t border-stone-800 pt-2">
                  <span className="text-stone-400">Total Paid:</span>
                  <span className="font-bold text-white">₹{bookingConfirmation.amount}</span>
                </div>
                <div className="flex justify-between text-[11px] text-stone-500">
                  <span>Booking Ref:</span>
                  <span className="font-mono">{bookingConfirmation.ref}</span>
                </div>
              </div>

              {bookingConfirmation.qr && (
                <div className="p-3 bg-white rounded-2xl w-36 h-36 mx-auto flex items-center justify-center shadow-md">
                  <img src={bookingConfirmation.qr} alt="Ticket QR" className="w-32 h-32 object-contain" />
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    downloadTicketPDF({
                      id: bookingConfirmation.ref,
                      bookingRef: bookingConfirmation.ref,
                      bookingDate: new Date().toISOString(),
                      serviceDate: 'Today',
                      serviceTime: activeShow.time,
                      category: 'theatre',
                      itemId: theatre.id,
                      itemTitle: `${activeMovie.title} · ${theatre.name}`,
                      itemSubtitle: theatre.name,
                      itemAddress: theatre.address,
                      itemImage: theatre.image,
                      cityName: 'Karnataka',
                      customerName: 'Guest Movie Buff',
                      customerEmail: 'guest@touristguide.com',
                      customerPhone: '+91 99000 00000',
                      details: {
                        selectedSeats: bookingConfirmation.seats,
                        movieFormat: activeMovie.format,
                        screenName: theatre.name,
                      },
                      totalAmount: bookingConfirmation.amount,
                      currency: '₹',
                      paymentMethod: 'UPI',
                      paymentStatus: 'Paid & Confirmed',
                      bookingStatus: 'Confirmed',
                      qrCodeValue: bookingConfirmation.ref,
                      createdAt: new Date().toISOString(),
                    });
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download E-Ticket PDF</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-white font-bold text-xs transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <div className="relative flex-1 w-full h-full overflow-hidden">
          
          {/* 3D WebGL Canvas Viewport */}
          {viewMode === '3d' && (
            <div className="relative w-full h-full">
              <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing touch-none select-none" />

              {/* Floating Camera Control Pill */}
              <div className="absolute top-3 left-4 z-10 flex items-center gap-2">
                {isViewFromSeat ? (
                  <button
                    type="button"
                    onClick={handleResetCamera}
                    className="px-3.5 py-1.5 rounded-xl bg-stone-900/90 hover:bg-stone-800 border border-stone-700 text-white text-xs font-bold flex items-center gap-2 shadow-lg backdrop-blur-md transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                    <span>Return to Full Auditorium View</span>
                  </button>
                ) : (
                  <div className="px-3 py-1.5 rounded-xl bg-stone-900/80 border border-stone-800 text-stone-300 text-xs flex items-center gap-2 backdrop-blur-md">
                    <Eye className="w-3.5 h-3.5 text-amber-400" />
                    <span>Swipe / Drag to rotate in 360° · Tap to select seat</span>
                  </div>
                )}
              </div>

              {/* Hover Tooltip Overlay */}
              {hoveredSeat && (
                <div className="absolute top-3 right-4 z-10 px-3.5 py-2 rounded-2xl bg-stone-900/95 border border-stone-700 text-xs shadow-xl backdrop-blur-md pointer-events-none animate-in fade-in duration-100">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">Seat {hoveredSeat.id}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      hoveredSeat.tier === 'Recliner' ? 'bg-rose-500/20 text-rose-300' :
                      hoveredSeat.tier === 'Gold' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-500/20 text-slate-300'
                    }`}>
                      {hoveredSeat.tier}
                    </span>
                  </div>
                  <div className="text-stone-400 text-[11px] mt-0.5">
                    Price: <strong className="text-white">₹{hoveredSeat.price}</strong> · {hoveredSeat.status}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 2D Plan View (Fallback or preference) */}
          {viewMode === '2d' && (
            <div className="w-full h-full p-4 sm:p-6 overflow-y-auto space-y-6 flex flex-col items-center justify-center">
              {/* Screen Graphic */}
              <div className="w-full max-w-xl text-center space-y-1">
                <div className="h-2 w-full bg-gradient-to-r from-transparent via-amber-400 to-transparent rounded-full shadow-[0_0_15px_rgba(245,158,11,0.6)]" />
                <span className="text-[11px] tracking-widest text-stone-400 uppercase font-mono">
                  ALL EYES THIS WAY · CURVED SILVER SCREEN
                </span>
              </div>

              {/* 2D Grid */}
              <div className="space-y-2 w-full max-w-2xl">
                {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map((row) => (
                  <div key={row} className="flex items-center justify-center gap-1.5 sm:gap-2">
                    <span className="w-5 text-right font-mono text-xs text-stone-500 font-bold">{row}</span>
                    <div className="flex gap-1 sm:gap-1.5">
                      {Array.from({ length: 12 }, (_, i) => i + 1).map((col) => {
                        const seatId = `${row}${col}`;
                        const isSelected = selectedSeatIds.includes(seatId);
                        const isRecliner = row === 'A' || row === 'B';
                        const isGold = row === 'C' || row === 'D' || row === 'E';
                        const isBooked = (row === 'C' && (col === 5 || col === 6)) || 
                                         (row === 'E' && (col === 3 || col === 4)) || 
                                         (row === 'A' && (col === 8 || col === 9));

                        return (
                          <button
                            key={seatId}
                            type="button"
                            disabled={isBooked}
                            onClick={() => toggleSeatSelection(seatId)}
                            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg text-[10px] font-bold flex items-center justify-center transition-all cursor-pointer ${
                              isBooked
                                ? 'bg-stone-800 text-stone-600 cursor-not-allowed'
                                : isSelected
                                ? 'bg-emerald-500 text-stone-950 font-extrabold ring-2 ring-emerald-300 shadow-md scale-105'
                                : isRecliner
                                ? 'bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-rose-300'
                                : isGold
                                ? 'bg-amber-950/60 hover:bg-amber-900 border border-amber-800 text-amber-300'
                                : 'bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700'
                            }`}
                          >
                            {col}
                          </button>
                        );
                      })}
                    </div>
                    <span className="w-5 text-left font-mono text-xs text-stone-500 font-bold">{row}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Unified Collapsible Ergonomic Bottom Dock (Three.js skill directive: zero viewport occlusion) */}
          <div className="absolute bottom-3 left-4 right-4 z-20 pointer-events-none">
            <div className="max-w-3xl mx-auto bg-stone-900/95 backdrop-blur-md border border-stone-800 rounded-3xl p-3 sm:p-4 shadow-2xl pointer-events-auto transition-all">
              
              {/* Collapse / Expand Toggle */}
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-800 text-xs">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1.5 font-bold text-white">
                    <Ticket className="w-4 h-4 text-amber-400" />
                    <span>Selected Seats:</span>
                    <strong className="text-emerald-400">
                      {selectedSeatIds.length > 0 ? selectedSeatIds.join(', ') : 'None selected'}
                    </strong>
                  </span>
                  <span className="text-stone-400 text-[11px]">
                    ({selectedSeatIds.length} ticket{selectedSeatIds.length === 1 ? '' : 's'})
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {selectedSeatIds.length > 0 && viewMode === '3d' && (
                    <button
                      type="button"
                      onClick={() => handlePreviewViewFromSeat(selectedSeatIds[0])}
                      className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                      title="Preview how screen looks from your first selected seat"
                    >
                      <Eye className="w-3 h-3" />
                      <span>Preview View from Seat</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setIsBottomDockCollapsed(!isBottomDockCollapsed)}
                    className="p-1 rounded-lg hover:bg-stone-800 text-stone-400 hover:text-white transition-colors cursor-pointer"
                  >
                    {isBottomDockCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {!isBottomDockCollapsed && (
                <div className="space-y-3 pt-1">
                  {/* Legend */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-stone-400">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-sm bg-rose-900 border border-rose-700" /> Recliner (₹{activeShow.price + 180})
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-sm bg-amber-900 border border-amber-700" /> Gold (₹{activeShow.price + 60})
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-sm bg-slate-700 border border-slate-600" /> Silver (₹{activeShow.price})
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-sm bg-emerald-500" /> Selected
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-sm bg-stone-800" /> Booked
                      </span>
                    </div>

                    <div className="font-serif font-bold text-base text-white">
                      Total: <span className="text-amber-400">₹{calculateTotal()}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between gap-3 pt-1">
                    <div className="text-[11px] text-stone-400">
                      ⚡ Instant e-pass with QR code generated directly to your wallet
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={onClose}
                        className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-bold transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={selectedSeatIds.length === 0}
                        onClick={handleConfirmBooking}
                        className={`px-5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                          selectedSeatIds.length > 0
                            ? 'bg-amber-400 hover:bg-amber-300 text-stone-950 shadow-md'
                            : 'bg-stone-800 text-stone-600 cursor-not-allowed'
                        }`}
                      >
                        <Ticket className="w-4 h-4" />
                        <span>Confirm & Book {selectedSeatIds.length} Seats (₹{calculateTotal()})</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
