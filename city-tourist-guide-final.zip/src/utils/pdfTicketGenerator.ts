import jsPDF from 'jspdf';
import QRCode from 'qrcode';
import { Booking } from '../types';

export async function generateTicketQRCodeDataURL(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      errorCorrectionLevel: 'H',
      margin: 1,
      width: 256,
      color: {
        dark: '#1C1917',
        light: '#FFFFFF',
      },
    });
  } catch (err) {
    console.error('Error generating QR code:', err);
    return '';
  }
}

/**
 * Generates and downloads a real, beautifully formatted PDF ticket for any booking.
 * Fully compatible with desktop browsers and mobile devices (via direct Blob download & Web Share API).
 */
export async function downloadTicketPDF(
  booking: Booking,
  cityName: string = 'City',
  preferMobileShare: boolean = true
): Promise<{ success: boolean; method: 'shared' | 'downloaded' | 'error'; error?: string }> {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 16;
    const contentWidth = pageWidth - margin * 2;

    // 1. High-Res Scannable QR Code Payload
    const qrPayload = JSON.stringify({
      id: booking.id,
      pnr: booking.bookingRef,
      item: booking.itemTitle,
      city: booking.cityName || cityName,
      category: booking.category,
      date: booking.serviceDate,
      time: booking.serviceTime,
      guest: booking.customerName,
      phone: booking.customerPhone,
      status: booking.bookingStatus,
      paid: `${booking.currency}${booking.totalAmount}`,
      qrVerification: booking.qrCodeValue,
    });

    let qrDataUrl = '';
    try {
      qrDataUrl = await QRCode.toDataURL(qrPayload, {
        errorCorrectionLevel: 'H',
        margin: 1,
        width: 320,
        color: {
          dark: '#1C1917',
          light: '#FFFFFF',
        },
      });
    } catch (err) {
      console.error('Error generating QR code for PDF:', err);
    }

    // 2. Dynamic Palette based on category
    let headerBg = [30, 41, 59]; // Slate 800
    let headerAccent = [210, 142, 93]; // Brand orange
    let categoryBadgeText = 'OFFICIAL E-TICKET & DIGITAL GATE PASS';
    let themeCategory = booking.category || 'event';

    if (themeCategory === 'theatre') {
      headerBg = [15, 23, 42]; // Slate 900
      headerAccent = [245, 158, 11]; // Amber 500
      categoryBadgeText = 'CINEMA MOVIE PASS & SEAT RESERVATION';
    } else if (themeCategory === 'temple') {
      headerBg = [120, 53, 15]; // Amber 900
      headerAccent = [217, 119, 6]; // Amber 600
      categoryBadgeText = 'SACRED VIP DARSHAN & SEVA PASS';
    } else if (themeCategory === 'restaurant') {
      headerBg = [6, 78, 59]; // Emerald 900
      headerAccent = [16, 185, 129]; // Emerald 500
      categoryBadgeText = 'RESTAURANT TABLE RESERVATION VOUCHER';
    } else if (themeCategory === 'attraction') {
      headerBg = [76, 29, 149]; // Purple 900
      headerAccent = [168, 85, 247]; // Purple 500
      categoryBadgeText = 'HERITAGE ATTRACTION ENTRY PERMIT';
    } else {
      headerBg = [159, 18, 57]; // Rose 900
      headerAccent = [244, 63, 94]; // Rose 500
      categoryBadgeText = 'OFFICIAL CITY EVENT ADMISSION PASS';
    }

    // Background Canvas
    doc.setFillColor(250, 250, 248);
    doc.rect(0, 0, pageWidth, pageHeight, 'F');

    // Decorative Top Accent Stripe
    doc.setFillColor(headerAccent[0], headerAccent[1], headerAccent[2]);
    doc.rect(0, 0, pageWidth, 5, 'F');

    // Outer Ticket Container (Clean Card with Border)
    const cardY = 12;
    const cardHeight = 270;
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(margin, cardY, contentWidth, cardHeight, 4, 4, 'F');
    doc.setDrawColor(220, 215, 205);
    doc.setLineWidth(0.6);
    doc.roundedRect(margin, cardY, contentWidth, cardHeight, 4, 4, 'S');

    // --- HEADER SECTION ---
    doc.setFillColor(headerBg[0], headerBg[1], headerBg[2]);
    doc.roundedRect(margin, cardY, contentWidth, 38, 4, 4, 'F');
    // Square bottom seam
    doc.rect(margin, cardY + 28, contentWidth, 10, 'F');

    // Top Category Tag
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(headerAccent[0], headerAccent[1], headerAccent[2]);
    doc.text(categoryBadgeText.toUpperCase(), margin + 8, cardY + 11);

    // City Travel Desk Brand
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(200, 200, 200);
    const brandName = `${(booking.cityName || cityName).toUpperCase()} SMART COMPASS PASS`;
    doc.text(brandName, pageWidth - margin - 8, cardY + 11, { align: 'right' });

    // Main Item Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(15);
    doc.setTextColor(255, 255, 255);
    const truncatedTitle = booking.itemTitle.length > 36 ? booking.itemTitle.substring(0, 34) + '...' : booking.itemTitle;
    doc.text(truncatedTitle, margin + 8, cardY + 22.5);

    // Subtitle / Location
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(215, 215, 215);
    const subText = booking.itemSubtitle || booking.itemAddress || cityName;
    const truncatedSub = subText.length > 46 ? subText.substring(0, 44) + '...' : subText;
    doc.text(truncatedSub, margin + 8, cardY + 30.5);

    // Status Badge (Confirmed)
    doc.setFillColor(220, 252, 231); // Green pill
    doc.roundedRect(pageWidth - margin - 38, cardY + 18, 30, 8, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(22, 101, 52);
    doc.text('CONFIRMED', pageWidth - margin - 23, cardY + 23.5, { align: 'center' });

    // --- BOOKING REFERENCE STRIP ---
    let currY = cardY + 46;
    doc.setFillColor(246, 246, 242);
    doc.roundedRect(margin + 6, currY, contentWidth - 12, 16, 2, 2, 'F');
    doc.setDrawColor(228, 224, 214);
    doc.setLineWidth(0.4);
    doc.roundedRect(margin + 6, currY, contentWidth - 12, 16, 2, 2, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(120, 115, 105);
    doc.text('BOOKING REFERENCE (PNR)', margin + 12, currY + 5.5);
    doc.text('PAYMENT STATUS', pageWidth / 2 + 10, currY + 5.5);

    doc.setFont('courier', 'bold');
    doc.setFontSize(11.5);
    doc.setTextColor(30, 30, 30);
    doc.text(booking.bookingRef, margin + 12, currY + 12);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(22, 101, 52);
    const paymentLabel = booking.paymentStatus === 'Confirmed (Pay at Venue)'
      ? `PAY AT VENUE (${booking.currency}${booking.totalAmount})`
      : `PAID IN FULL (${booking.currency}${booking.totalAmount})`;
    doc.text(paymentLabel, pageWidth / 2 + 10, currY + 12);

    // --- PRIMARY SCHEDULE & VISITOR DETAILS ---
    currY += 23;
    const col1X = margin + 8;
    const col2X = margin + (contentWidth / 2) + 2;

    // Service Date
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(140, 130, 115);
    doc.text('DATE OF VISIT / SERVICE', col1X, currY);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(30, 30, 30);
    doc.text(booking.serviceDate, col1X, currY + 5.5);

    // Service Time
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(140, 130, 115);
    doc.text('TIME SLOT / SHOWTIME', col2X, currY);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(30, 30, 30);
    doc.text(booking.serviceTime || 'Standard Operating Hours', col2X, currY + 5.5);

    currY += 15;

    // Primary Guest
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(140, 130, 115);
    doc.text('PRIMARY VISITOR / GUEST', col1X, currY);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 30, 30);
    doc.text(booking.customerName || 'Valued Guest', col1X, currY + 5.5);

    // Contact Details
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(140, 130, 115);
    doc.text('CONTACT DETAILS', col2X, currY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(50, 50, 50);
    const contactLine = `${booking.customerPhone || ''} | ${booking.customerEmail || ''}`.trim();
    doc.text(contactLine || 'Provided at booking', col2X, currY + 5.5);

    // --- CATEGORY SPECIFIC ALLOCATION BOX ---
    currY += 15;
    const boxHeight = 44;
    doc.setFillColor(252, 250, 246);
    doc.roundedRect(margin + 6, currY, contentWidth - 12, boxHeight, 2, 2, 'F');
    doc.setDrawColor(225, 220, 210);
    doc.roundedRect(margin + 6, currY, contentWidth - 12, boxHeight, 2, 2, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(headerBg[0], headerBg[1], headerBg[2]);
    doc.text('RESERVATION & SPECIFIC ALLOCATION DETAILS', margin + 12, currY + 6.5);

    const bd = booking.details || {};
    let detailY = currY + 14;

    if (booking.category === 'theatre') {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(60, 60, 60);

      doc.text(`Screen Format: ${bd.movieFormat || 'Digital 4K Atmos'}`, margin + 12, detailY);
      doc.text(`Cinema Hall: ${bd.screenName || booking.itemTitle}`, col2X, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(180, 83, 9);
      doc.text(`Allocated Seats: ${(bd.selectedSeats || []).join(', ') || 'Selected in hall'}`, margin + 12, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80, 80, 80);
      const snacks = bd.selectedSnacks && bd.selectedSnacks.length > 0 
        ? bd.selectedSnacks.map((s: any) => `${s.name} x${s.quantity}`).join(', ') 
        : 'None';
      doc.text(`Snacks & Concessions: ${snacks}`, margin + 12, detailY);
    } else if (booking.category === 'temple') {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(60, 60, 60);

      doc.text(`Darshan / Seva: ${bd.darshanType || 'VIP Fast-Track Pass'}`, margin + 12, detailY);
      doc.text(`Devotees: ${bd.devoteeCount || 1} Person(s)`, col2X, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(180, 83, 9);
      doc.text(`ID Proof: ${bd.idProofType || 'Govt ID'} (${bd.idProofNumber || 'VERIFIED'})`, margin + 12, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80, 80, 80);
      doc.text(`Sacred Prasaadam Packs: ${bd.prasaadamQuantity || 0} Special Box(es)`, margin + 12, detailY);
    } else if (booking.category === 'restaurant') {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(60, 60, 60);

      doc.text(`Party Size: ${bd.partySize || 2} Guests`, margin + 12, detailY);
      doc.text(`Seating Zone: ${bd.seatingArea || 'Indoor AC'}`, col2X, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(16, 185, 129);
      doc.text(`Meal Time: ${bd.mealSlot || bd.tableTime || booking.serviceTime}`, margin + 12, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80, 80, 80);
      const dishes = bd.preOrderedDishes && bd.preOrderedDishes.length > 0 
        ? bd.preOrderedDishes.map((d: any) => `${d.name} x${d.quantity}`).join(', ') 
        : 'A-la-carte menu on arrival';
      doc.text(`Pre-orders / Dietary: ${dishes}`, margin + 12, detailY);
    } else if (booking.category === 'attraction') {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(60, 60, 60);

      const v = bd.ticketBreakdown || { adults: 1, children: 0, seniors: 0, foreignTourists: 0, audioGuides: 0 };
      doc.text(`Visitors: ${v.adults || 1} Adult(s), ${v.children || 0} Child(ren), ${v.seniors || 0} Senior(s)`, margin + 12, detailY);
      doc.text(`Timed Entry Slot: ${bd.entrySlot || booking.serviceTime}`, col2X, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(126, 34, 206);
      doc.text(`Audio Guides: ${v.audioGuides || 0} device(s) booked`, margin + 12, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80, 80, 80);
      doc.text(`Foreign Visitors: ${v.foreignTourists || 0} | Ticket Type: Official Gate Entry`, margin + 12, detailY);
    } else {
      // Event
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(60, 60, 60);

      doc.text(`Pass Tier: ${bd.eventTier || 'General Admission'}`, margin + 12, detailY);
      doc.text(`Total Passes: ${bd.ticketCount || 1} Ticket(s)`, col2X, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(159, 18, 57);
      doc.text(`Venue Access: Direct turnstile QR check-in`, margin + 12, detailY);

      detailY += 6.5;
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(80, 80, 80);
      doc.text(`Event Date & Timing: ${bd.eventDate || booking.serviceDate} | ${bd.eventTime || booking.serviceTime}`, margin + 12, detailY);
    }

    // --- PERFORATION CUT-LINE ---
    currY += boxHeight + 8;
    doc.setDrawColor(180, 175, 165);
    doc.setLineDashPattern([2, 2], 0);
    doc.line(margin + 6, currY, pageWidth - margin - 6, currY);
    doc.setLineDashPattern([], 0); // reset line dash

    // Perforation Notch cutouts
    doc.setFillColor(250, 250, 248);
    doc.circle(margin, currY, 4, 'F');
    doc.circle(pageWidth - margin, currY, 4, 'F');
    doc.setDrawColor(220, 215, 205);
    doc.circle(margin, currY, 4, 'S');
    doc.circle(pageWidth - margin, currY, 4, 'S');

    // --- QR CODE & GATE ENTRY SCANNER SECTION ---
    currY += 6;
    const qrSize = 42;

    if (qrDataUrl) {
      doc.addImage(qrDataUrl, 'PNG', margin + 8, currY, qrSize, qrSize);
    }

    const qrTextX = margin + 8 + qrSize + 8;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(20, 20, 20);
    doc.text('DIGITAL GATE ACCESS QR PASS', qrTextX, currY + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 100, 100);
    doc.text('Show this QR code at the automated turnstile or venue counter.', qrTextX, currY + 13);
    doc.text(`Verification ID: ${booking.bookingRef}`, qrTextX, currY + 18);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(140, 130, 115);
    doc.text('TOTAL AMOUNT', qrTextX, currY + 26);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(headerAccent[0], headerAccent[1], headerAccent[2]);
    doc.text(`${booking.currency}${booking.totalAmount.toLocaleString()}`, qrTextX, currY + 33);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(120, 120, 120);
    doc.text(`Booked on ${new Date(booking.createdAt || booking.bookingDate).toLocaleDateString()} at ${new Date(booking.createdAt || booking.bookingDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`, qrTextX, currY + 39);

    // --- IMPORTANT ENTRY GUIDELINES FOOTER ---
    currY += qrSize + 4;
    doc.setFillColor(248, 248, 246);
    doc.roundedRect(margin + 6, currY, contentWidth - 12, 23, 2, 2, 'F');
    doc.setDrawColor(230, 226, 216);
    doc.roundedRect(margin + 6, currY, contentWidth - 12, 23, 2, 2, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(80, 80, 80);
    doc.text('IMPORTANT GUIDELINES & MOBILE ENTRY INSTRUCTIONS:', margin + 10, currY + 5.5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 100, 100);
    doc.text('1. Please arrive 15 minutes prior with a valid government photo ID matching guest name.', margin + 10, currY + 10.5);
    doc.text('2. Keep this PDF downloaded on your mobile device (Files / Apple Books / Google Drive / Downloads).', margin + 10, currY + 15);
    doc.text('3. You can present this PDF on your smartphone screen directly without printing any paper ticket.', margin + 10, currY + 19.5);

    // Bottom Branding Footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(160, 160, 160);
    doc.text(`Smart City Travel Companion · Pass Ref: ${booking.bookingRef} · Booking ID: ${booking.id}`, pageWidth / 2, pageHeight - 6, { align: 'center' });

    // 3. Save / Download to Mobile Device & Desktop
    const safeTitle = (booking.itemTitle || 'Ticket').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 24);
    const safeFilename = `Ticket_${booking.bookingRef}_${safeTitle}.pdf`;

    const pdfBlob = doc.output('blob');

    // If mobile share is requested & supported (Web Share API with file attachments)
    if (preferMobileShare && typeof navigator !== 'undefined' && navigator.share && navigator.canShare) {
      try {
        const file = new File([pdfBlob], safeFilename, { type: 'application/pdf' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: `Ticket: ${booking.itemTitle}`,
            text: `Confirmed booking pass for ${booking.itemTitle} (Ref: ${booking.bookingRef}). Save or view on your device.`,
          });
          return { success: true, method: 'shared' };
        }
      } catch (e: any) {
        // If user cancelled sharing, don't force duplicate download if they explicitly dismissed
        if (e.name === 'AbortError') {
          return { success: true, method: 'shared' };
        }
        console.warn('Web Share API fallback to direct blob download:', e);
      }
    }

    // Direct Browser / Mobile File Download
    const url = URL.createObjectURL(pdfBlob);
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = safeFilename;
    downloadLink.target = '_blank';
    downloadLink.rel = 'noopener noreferrer';
    document.body.appendChild(downloadLink);
    downloadLink.click();

    setTimeout(() => {
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);
    }, 1500);

    return { success: true, method: 'downloaded' };
  } catch (error: any) {
    console.error('Failed to generate or save PDF ticket:', error);
    return { success: false, method: 'error', error: error?.message || 'Download failed' };
  }
}
