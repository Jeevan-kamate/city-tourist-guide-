import React, { useState, useMemo, useEffect } from 'react';
import { 
  City, 
  Place, 
  PlaceCategory, 
  Review, 
  CityEvent, 
  ItineraryPlan, 
  ItineraryScheduleItem,
  Booking,
  BookingTarget,
  BookingCategory
} from './types';
import { CITIES, PLACES } from './data/citiesData';
import { EVENTS } from './data/eventsData';
import { createDefaultPlanForCity } from './data/itineraryDefaults';
import { Navbar, AppViewMode } from './components/Navbar';
import { CityHero } from './components/CityHero';
import { PlaceCard } from './components/PlaceCard';
import { InteractiveMap } from './components/InteractiveMap';
import { TheatresView } from './components/TheatresView';
import { TemplesView } from './components/TemplesView';
import { RestaurantsView } from './components/RestaurantsView';
import { AttractionsView } from './components/AttractionsView';
import { EventsView } from './components/EventsView';
import { ItineraryPlannerView } from './components/ItineraryPlannerView';
import { PlaceDetailModal } from './components/PlaceDetailModal';
import { EventDetailModal } from './components/EventDetailModal';
import { AddToItineraryModal } from './components/AddToItineraryModal';
import { TicketCalculatorModal } from './components/TicketCalculatorModal';
import { AIConciergeModal } from './components/AIConciergeModal';
import { ExploreNewCityModal } from './components/ExploreNewCityModal';
import { DirectBookingModal } from './components/DirectBookingModal';
import { MyBookingsModal } from './components/MyBookingsModal';
import { AppSplashThumbnail } from './components/AppSplashThumbnail';
import { UserAuthModal } from './components/UserAuthModal';
import { AdminPortalModal } from './components/AdminPortalModal';
import { LoginGateScreen } from './components/LoginGateScreen';
import { IndiaJoyExplorerModal } from './components/IndiaJoyExplorerModal';
import { CityTimeSpenderSelector } from './components/CityTimeSpenderSelector';
import { ThreeDTheatreBookingModal } from './components/ThreeDTheatreBookingModal';
import { SmartTouristDecisionHub } from './components/SmartTouristDecisionHub';
import { DistrictSelectorGateway } from './components/DistrictSelectorGateway';
import { ALL_INDIAN_STATES_AND_UTS, convertDistrictToCity, generatePlacesForDistrict } from './data/indiaStatesAndDistricts';
import { UserAccount } from './types';
import { 
  Compass, 
  Film, 
  Sparkles, 
  UtensilsCrossed, 
  Landmark, 
  Map as MapIcon, 
  Ticket, 
  SlidersHorizontal,
  Info,
  Calendar,
  PartyPopper,
  AlertCircle,
  ArrowRight,
  MapPin,
  CheckCircle2,
  Check
} from 'lucide-react';

// Davanagere Default Initialization from Indian Districts
const karnatakaState = ALL_INDIAN_STATES_AND_UTS.find((s) => s.id === 'karnataka');
const davanagereDistrict = karnatakaState?.districts.find((d) => d.id === 'davanagere');
const defaultInitialCity = davanagereDistrict ? convertDistrictToCity(davanagereDistrict) : CITIES[0];
const defaultInitialPlaces = davanagereDistrict ? generatePlacesForDistrict(davanagereDistrict) : PLACES;

export function App() {
  // Opening Splash / Thumbnail State
  const [isSplashOpen, setIsSplashOpen] = useState(false);

  // Cities & Places State (Davanagere default, no Varanasi clutter)
  const [citiesList, setCitiesList] = useState<City[]>(() => {
    if (davanagereDistrict) {
      return [defaultInitialCity, ...CITIES.filter((c) => c.id !== 'varanasi'), CITIES.find((c) => c.id === 'varanasi')!];
    }
    return CITIES;
  });
  const [activeCityId, setActiveCityId] = useState<string>(defaultInitialCity.id);
  const [allPlaces, setAllPlaces] = useState<Place[]>(() => {
    if (davanagereDistrict) {
      return [...defaultInitialPlaces, ...PLACES];
    }
    return PLACES;
  });
  const [allEvents, setAllEvents] = useState<CityEvent[]>(EVENTS);

  // Active View & Filters
  const [activeView, setActiveView] = useState<AppViewMode>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [quickFilter, setQuickFilter] = useState<string>('all');
  const [mapCategoryFilter, setMapCategoryFilter] = useState<PlaceCategory | 'all'>('all');
  const [isDistrictBrowserOpen, setIsDistrictBrowserOpen] = useState(false);

  // 3D Theatre Booking Modal States
  const [is3DTheatreModalOpen, setIs3DTheatreModalOpen] = useState(false);
  const [theatreFor3D, setTheatreFor3D] = useState<Place | null>(null);
  const [movieFor3D, setMovieFor3D] = useState<any>(undefined);
  const [showtimeFor3D, setShowtimeFor3D] = useState<any>(undefined);

  // Modals & Selected items
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<CityEvent | null>(null);
  const [mapActivePlace, setMapActivePlace] = useState<Place | null>(null);
  const [mapActiveEvent, setMapActiveEvent] = useState<CityEvent | null>(null);
  const [mapItineraryRoute, setMapItineraryRoute] = useState<ItineraryScheduleItem[] | undefined>(undefined);

  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isAddToItineraryOpen, setIsAddToItineraryOpen] = useState(false);
  const [addToItineraryTarget, setAddToItineraryTarget] = useState<{
    type: 'place' | 'event';
    item: Place | CityEvent;
  } | null>(null);

  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isExploreModalOpen, setIsExploreModalOpen] = useState(false);

  // User Authentication & Admin Database States (Auto-login restored from localStorage)
  const [isLoggedInOrUnlocked, setIsLoggedInOrUnlocked] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('tourist_guide_saved_user');
      const remember = localStorage.getItem('tourist_guide_remember_me');
      return !!saved && remember === 'true';
    } catch (e) {
      return false;
    }
  });
  const [isIndiaJoyModalOpen, setIsIndiaJoyModalOpen] = useState<boolean>(false);
  const [isUserAuthOpen, setIsUserAuthOpen] = useState(false);
  const [isAdminPortalOpen, setIsAdminPortalOpen] = useState(false);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(false);

  // Google Maps Platform Quota Exceeded listener
  const [gmpQuotaReached, setGmpQuotaReached] = useState(false);
  useEffect(() => {
    const handleQuotaExceeded = () => {
      setGmpQuotaReached(true);
    };
    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
  }, []);

  // Registered Users Database (LocalStorage persisted)
  const [allUsers, setAllUsers] = useState<UserAccount[]>(() => {
    try {
      const stored = localStorage.getItem('tourist_guide_users_db_v1');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to parse users from localStorage', e);
    }
    return [
      {
        id: 'usr-1',
        name: 'Aarav Sharma',
        email: 'aarav.sharma@example.com',
        phone: '+91 98765 43210',
        password: 'user123',
        joinedAt: '2026-08-15T09:30:00.000Z',
        lastLoginAt: '2026-08-20T10:00:00.000Z',
        bookingsCount: 1,
        totalSpent: 900,
        activityLogs: [
          {
            id: 'log-1',
            action: 'Account registered & signed in',
            timestamp: '2026-08-15T09:30:00.000Z',
          },
          {
            id: 'log-2',
            action: 'Booked cinema tickets for Kalki 2898 AD (PVR IMAX)',
            category: 'theatre',
            itemTitle: 'Kalki 2898 AD · PVR IMAX',
            bookingRef: 'CINE-BLR-892410',
            amount: 900,
            timestamp: '2026-08-20T10:00:00.000Z',
          },
        ],
      },
      {
        id: 'usr-2',
        name: 'Priya Patel',
        email: 'priya.patel@example.com',
        phone: '+91 98220 11223',
        password: 'user123',
        joinedAt: '2026-08-18T14:30:00.000Z',
        lastLoginAt: '2026-08-21T08:15:00.000Z',
        bookingsCount: 0,
        totalSpent: 0,
        activityLogs: [
          {
            id: 'log-3',
            action: 'Account registered & signed in',
            timestamp: '2026-08-18T14:30:00.000Z',
          },
          {
            id: 'log-4',
            action: 'Explored heritage sights and temples in Varanasi',
            timestamp: '2026-08-21T08:15:00.000Z',
          },
        ],
      },
      {
        id: 'usr-3',
        name: 'Jeevan M K',
        email: 'jeevankamate10@gmail.com',
        phone: '+91 99001 23456',
        password: 'user123',
        joinedAt: '2026-08-10T08:00:00.000Z',
        lastLoginAt: '2026-08-21T11:00:00.000Z',
        bookingsCount: 0,
        totalSpent: 0,
        activityLogs: [
          {
            id: 'log-5',
            action: 'Account created and verified',
            timestamp: '2026-08-10T08:00:00.000Z',
          },
        ],
      },
      {
        id: 'usr-4',
        name: 'Jeevan K',
        email: 'jeevankamate3@gmail.com',
        phone: '+91 99001 78901',
        password: 'user123',
        joinedAt: '2026-08-12T08:00:00.000Z',
        lastLoginAt: '2026-08-21T10:00:00.000Z',
        bookingsCount: 0,
        totalSpent: 0,
        activityLogs: [
          {
            id: 'log-6',
            action: 'Account registered',
            timestamp: '2026-08-12T08:00:00.000Z',
          },
        ],
      },
    ];
  });

  // Current Logged-in User State (Auto-logged in from localStorage)
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    try {
      const saved = localStorage.getItem('tourist_guide_saved_user');
      const remember = localStorage.getItem('tourist_guide_remember_me');
      if (saved && remember === 'true') {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Auto-login read error:', e);
    }
    return null;
  });

  // Persist registered users database to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tourist_guide_users_db_v1', JSON.stringify(allUsers));
    } catch (e) {
      console.warn('Failed to save users to localStorage', e);
    }
  }, [allUsers]);

  // User Auth Handlers
  const handleRegisterUser = (newUserData: Omit<UserAccount, 'id' | 'joinedAt' | 'lastLoginAt' | 'bookingsCount' | 'totalSpent' | 'activityLogs'>) => {
    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      name: newUserData.name,
      email: newUserData.email,
      phone: newUserData.phone,
      password: newUserData.password,
      joinedAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      bookingsCount: 0,
      totalSpent: 0,
      activityLogs: [
        {
          id: `log-${Date.now()}`,
          action: 'Account registered and signed in',
          category: 'auth',
          timestamp: new Date().toISOString(),
        },
      ],
    };

    try {
      localStorage.setItem('tourist_guide_saved_user', JSON.stringify(newUser));
      localStorage.setItem('tourist_guide_remember_me', 'true');
    } catch (err) {
      console.warn('Session save error:', err);
    }

    setAllUsers((prev) => [newUser, ...prev]);
    setCurrentUser(newUser);
    setIsLoggedInOrUnlocked(true);
    setIsUserAuthOpen(false);
    return newUser;
  };

  const handleLoginUser = (user: UserAccount) => {
    const updatedUser: UserAccount = {
      ...user,
      lastLoginAt: new Date().toISOString(),
      activityLogs: [
        {
          id: `log-${Date.now()}`,
          action: 'User signed into account',
          category: 'auth',
          timestamp: new Date().toISOString(),
        },
        ...(user.activityLogs || []),
      ],
    };

    try {
      localStorage.setItem('tourist_guide_saved_user', JSON.stringify(updatedUser));
      localStorage.setItem('tourist_guide_remember_me', 'true');
    } catch (err) {
      console.warn('Session save error:', err);
    }

    setCurrentUser(updatedUser);
    setAllUsers((prev) =>
      prev.map((u) => (u.id === user.id ? updatedUser : u))
    );
    setIsLoggedInOrUnlocked(true);
    setIsUserAuthOpen(false);
  };

  const handleLogoutUser = () => {
    try {
      localStorage.removeItem('tourist_guide_saved_user');
      localStorage.removeItem('tourist_guide_remember_me');
    } catch (err) {
      console.warn('Session clear error:', err);
    }
    setCurrentUser(null);
    setIsLoggedInOrUnlocked(false);
    setIsAdminUnlocked(false);
    setIsUserAuthOpen(false);
  };

  const handleSelectIndiaDistrict = (city: City, places: Place[]) => {
    setCitiesList((prev) => {
      if (!prev.some((c) => c.id === city.id)) {
        return [city, ...prev];
      }
      return prev;
    });
    setAllPlaces((prev) => {
      const filtered = prev.filter((p) => p.cityId !== city.id);
      return [...places, ...filtered];
    });
    setActiveCityId(city.id);
    setActiveView('all');
    setSearchQuery('');
    setQuickFilter('all');
    setIsDistrictBrowserOpen(false);
  };

  // Direct Booking & E-Tickets State
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingTarget, setBookingTarget] = useState<BookingTarget | null>(null);
  const [isMyBookingsOpen, setIsMyBookingsOpen] = useState(false);
  const [bookingToast, setBookingToast] = useState<{ title: string; subtitle: string; ref: string } | null>(null);

  // User confirmed bookings persisted in localStorage
  const [bookings, setBookings] = useState<Booking[]>(() => {
    try {
      const stored = localStorage.getItem('city_compass_user_bookings_v2');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to parse user bookings from localStorage', e);
    }
    return [
      {
        id: 'bk-demo-1',
        bookingRef: 'CINE-BLR-892410',
        category: 'theatre' as BookingCategory,
        itemId: 'th-1',
        itemTitle: 'Kalki 2898 AD · PVR IMAX Screen',
        itemAddress: 'Vega City Mall, Bannerghatta Rd, Bengaluru',
        serviceDate: 'Today, 20 Aug 2026',
        serviceTime: '06:45 PM',
        customerName: 'Aarav Sharma',
        customerEmail: 'aarav.sharma@example.com',
        customerPhone: '+91 98765 43210',
        totalAmount: 900,
        currency: '₹',
        paymentStatus: 'PAID · Online UPI Confirmed',
        bookingStatus: 'Confirmed',
        qrCodeValue: 'PVR-IMAX-KALKI-SEAT-E12-E13-CONFIRMED',
        createdAt: '2026-08-20T10:00:00.000Z',
        details: {
          movieTitle: 'Kalki 2898 AD',
          screenType: 'IMAX 3D Laser',
          selectedSeats: ['E12', 'E13'],
          selectedSnacks: ['Large Caramel Popcorn combo (₹350)'],
        },
      },
    ];
  });

  // Persist bookings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('city_compass_user_bookings_v2', JSON.stringify(bookings));
    } catch (e) {
      console.warn('Failed to save bookings to localStorage', e);
    }
  }, [bookings]);

  // Saved Plans per City (LocalStorage persisted)
  const [savedPlans, setSavedPlans] = useState<{ [cityId: string]: ItineraryPlan }>(() => {
    try {
      const stored = localStorage.getItem('city_tourist_saved_plans_v1');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to parse saved plans from localStorage', e);
    }
    return {};
  });

  // Save to localStorage when plans update
  useEffect(() => {
    try {
      localStorage.setItem('city_tourist_saved_plans_v1', JSON.stringify(savedPlans));
    } catch (e) {
      console.warn('Failed to save plans to localStorage', e);
    }
  }, [savedPlans]);

  // Get active city object
  const activeCity = useMemo(() => {
    return citiesList.find((c) => c.id === activeCityId) || citiesList[0];
  }, [citiesList, activeCityId]);

  // Filter places & events for active city
  const cityPlaces = useMemo(() => {
    return allPlaces.filter((p) => p.cityId === activeCity.id);
  }, [allPlaces, activeCity.id]);

  const cityEvents = useMemo(() => {
    return allEvents.filter((e) => e.cityId === activeCity.id);
  }, [allEvents, activeCity.id]);

  // Current Itinerary Plan for Active City
  const activePlan = useMemo(() => {
    if (savedPlans[activeCity.id]) {
      return savedPlans[activeCity.id];
    }
    return createDefaultPlanForCity(activeCity, cityPlaces, cityEvents);
  }, [savedPlans, activeCity, cityPlaces, cityEvents]);

  // Total count of scheduled items in active plan
  const totalItineraryItemsCount = useMemo(() => {
    return activePlan.days.reduce((acc, d) => acc + d.items.length, 0);
  }, [activePlan]);

  // Saved IDs set for easy lookup
  const itineraryScheduledPlaceIds = useMemo(() => {
    const ids: string[] = [];
    activePlan.days.forEach((d) => {
      d.items.forEach((it) => {
        if (it.placeId) ids.push(it.placeId);
      });
    });
    return ids;
  }, [activePlan]);

  const itineraryScheduledEventIds = useMemo(() => {
    const ids: string[] = [];
    activePlan.days.forEach((d) => {
      d.items.forEach((it) => {
        if (it.eventId) ids.push(it.eventId);
      });
    });
    return ids;
  }, [activePlan]);

  // Current hour for crowd logic
  const currentHour = new Date().getHours();

  // Filtered places according to search & quick filters
  const filteredPlaces = useMemo(() => {
    return cityPlaces.filter((place) => {
      if (activeView !== 'all' && activeView !== 'map' && place.category !== activeView) {
        return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = place.name.toLowerCase().includes(q);
        const matchesTagline = place.tagline.toLowerCase().includes(q);
        const matchesAddress = place.address.toLowerCase().includes(q);
        const matchesDeity = place.templeDeity?.toLowerCase().includes(q);
        const matchesMovie = place.movies?.some((m) =>
          m.title.toLowerCase().includes(q) || m.genre.some((g) => g.toLowerCase().includes(q))
        );
        const matchesFood = place.topDishes?.some((d) =>
          d.name.toLowerCase().includes(q) || d.description.toLowerCase().includes(q)
        );

        if (!matchesName && !matchesTagline && !matchesAddress && !matchesDeity && !matchesMovie && !matchesFood) {
          return false;
        }
      }

      if (quickFilter === 'open_now') {
        return place.timings.currentStatus?.toLowerCase().includes('open');
      }
      if (quickFilter === 'free_entry') {
        return place.ticket.isFree;
      }
      if (quickFilter === 'low_crowd') {
        if (!place.crowd) return false;
        const currentDensity = place.crowd.hourlyCrowdIndex[currentHour] || 50;
        return currentDensity < 50;
      }
      if (quickFilter === 'has_movies') {
        return place.category === 'theatre' && (place.movies?.length || 0) > 0;
      }
      if (quickFilter === 'top_food') {
        return place.category === 'restaurant' && (place.topDishes?.length || 0) > 0;
      }

      return true;
    });
  }, [cityPlaces, activeView, searchQuery, quickFilter, currentHour]);

  // Handlers
  const handleSelectCity = (cityOrId: City | string) => {
    let targetCity: City | undefined;
    if (typeof cityOrId === 'string') {
      targetCity = citiesList.find((c) => c.id === cityOrId);
      if (!targetCity) {
        // Search in all Indian States and Districts
        for (const st of ALL_INDIAN_STATES_AND_UTS) {
          const d = st.districts.find((item) => item.id === cityOrId);
          if (d) {
            targetCity = convertDistrictToCity(d);
            const districtPlaces = generatePlacesForDistrict(d);
            handleSelectIndiaDistrict(targetCity, districtPlaces);
            return;
          }
        }
      }
    } else {
      targetCity = cityOrId;
    }

    if (targetCity) {
      setActiveCityId(targetCity.id);
      setSearchQuery('');
      setQuickFilter('all');
      setMapActivePlace(null);
      setMapActiveEvent(null);
      setMapItineraryRoute(undefined);
      setIsDistrictBrowserOpen(false);
    }
  };

  const handleOpenPlaceDetail = (place: Place) => {
    setSelectedPlace(place);
    setIsDetailModalOpen(true);
  };

  const handleOpenEventDetail = (event: CityEvent) => {
    setSelectedEvent(event);
    setIsEventModalOpen(true);
  };

  const handleShowPlaceOnMap = (place: Place) => {
    setMapActivePlace(place);
    setMapActiveEvent(null);
    setMapItineraryRoute(undefined);
    setActiveView('map');
    const mapEl = document.getElementById('interactive-map-section');
    mapEl?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleShowEventOnMap = (event: CityEvent) => {
    setMapActiveEvent(event);
    setMapActivePlace(null);
    setMapItineraryRoute(undefined);
    setActiveView('map');
    const mapEl = document.getElementById('interactive-map-section');
    mapEl?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleOpenAddToItinerary = (target: { type: 'place' | 'event'; item: Place | CityEvent }) => {
    setAddToItineraryTarget(target);
    setIsAddToItineraryOpen(true);
  };

  const handleSaveItineraryItem = (dayNumber: number, newItem: ItineraryScheduleItem) => {
    const existingDays = [...activePlan.days];
    let targetDayIndex = existingDays.findIndex((d) => d.dayNumber === dayNumber);

    if (targetDayIndex === -1) {
      // Create day if doesn't exist
      const newDay = {
        id: `day-${dayNumber}-${Date.now()}`,
        dayNumber: dayNumber,
        date: '',
        title: `Day ${dayNumber} in ${activeCity.name}`,
        items: [newItem],
      };
      existingDays.push(newDay);
    } else {
      const day = existingDays[targetDayIndex];
      const updatedItems = [...day.items, newItem].sort((a, b) => a.startTime.localeCompare(b.startTime));
      existingDays[targetDayIndex] = {
        ...day,
        items: updatedItems,
      };
    }

    const updatedPlan: ItineraryPlan = {
      ...activePlan,
      days: existingDays,
      updatedAt: new Date().toISOString(),
    };

    setSavedPlans((prev) => ({
      ...prev,
      [activeCity.id]: updatedPlan,
    }));
  };

  const handleUpdatePlan = (newPlan: ItineraryPlan) => {
    setSavedPlans((prev) => ({
      ...prev,
      [activeCity.id]: newPlan,
    }));
  };

  const handleOpenMapWithRoute = (dayItems: ItineraryScheduleItem[]) => {
    setMapItineraryRoute(dayItems);
    setMapActivePlace(null);
    setMapActiveEvent(null);
    setActiveView('map');
    const mapEl = document.getElementById('interactive-map-section');
    mapEl?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleAddReview = (placeId: string, newReview: Review) => {
    setAllPlaces((prev) =>
      prev.map((p) => {
        if (p.id === placeId) {
          const updatedReviews = [newReview, ...p.reviews];
          const newRating = Number(
            (
              (p.rating * p.reviewCount + newReview.rating) /
              (p.reviewCount + 1)
            ).toFixed(1)
          );
          return {
            ...p,
            reviews: updatedReviews,
            reviewCount: p.reviewCount + 1,
            rating: newRating,
          };
        }
        return p;
      })
    );

    if (selectedPlace?.id === placeId) {
      setSelectedPlace((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          reviews: [newReview, ...prev.reviews],
          reviewCount: prev.reviewCount + 1,
        };
      });
    }
  };

  const handleCityGenerated = (newCity: City, newPlaces: Place[]) => {
    setCitiesList((prev) => [newCity, ...prev]);
    setAllPlaces((prev) => [...newPlaces, ...prev]);
    setActiveCityId(newCity.id);
    setActiveView('all');
  };

  // Direct Booking Handlers
  const handleOpenDirectBooking = (target: BookingTarget) => {
    setBookingTarget(target);
    setIsBookingModalOpen(true);
  };

  const handleBookingSuccess = (newBooking: Booking) => {
    setBookings((prev) => [newBooking, ...prev]);
    
    // Update user database and current user's activity log & stats
    const activityItem = {
      id: `log-${Date.now()}`,
      action: `Booked ${newBooking.category} pass for ${newBooking.itemTitle}`,
      category: newBooking.category,
      itemTitle: newBooking.itemTitle,
      bookingRef: newBooking.bookingRef,
      amount: newBooking.totalAmount,
      timestamp: new Date().toISOString(),
    };

    setAllUsers((prevUsers) => {
      // Find matching user by email or name or current user
      const targetUser = prevUsers.find(
        (u) =>
          (currentUser && u.id === currentUser.id) ||
          (newBooking.customerEmail && u.email.toLowerCase() === newBooking.customerEmail.toLowerCase()) ||
          u.name.toLowerCase() === newBooking.customerName.toLowerCase()
      );

      if (targetUser) {
        return prevUsers.map((u) =>
          u.id === targetUser.id
            ? {
                ...u,
                bookingsCount: (u.bookingsCount || 0) + 1,
                totalSpent: (u.totalSpent || 0) + (newBooking.totalAmount || 0),
                activityLogs: [activityItem, ...(u.activityLogs || [])],
              }
            : u
        );
      } else {
        // Auto register booking customer as a user if not found
        const newCustomerUser: UserAccount = {
          id: `usr-${Date.now()}`,
          name: newBooking.customerName || 'Guest Tourist',
          email: newBooking.customerEmail || `tourist_${Date.now()}@example.com`,
          phone: newBooking.customerPhone || '',
          joinedAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
          bookingsCount: 1,
          totalSpent: newBooking.totalAmount || 0,
          activityLogs: [activityItem],
        };
        return [newCustomerUser, ...prevUsers];
      }
    });

    if (currentUser) {
      setCurrentUser((prev) =>
        prev
          ? {
              ...prev,
              bookingsCount: (prev.bookingsCount || 0) + 1,
              totalSpent: (prev.totalSpent || 0) + (newBooking.totalAmount || 0),
              activityLogs: [activityItem, ...(prev.activityLogs || [])],
            }
          : null
      );
    }

    setBookingToast({
      title: 'Booking Confirmed!',
      subtitle: `${newBooking.itemTitle} · Ref: ${newBooking.bookingRef}`,
      ref: newBooking.bookingRef,
    });
    setTimeout(() => {
      setBookingToast(null);
    }, 6000);
  };

  const handleCancelBooking = (bookingId: string) => {
    setBookings((prev) => prev.filter((b) => b.id !== bookingId));
  };

  const handleViewBookingOnMap = (booking: Booking) => {
    // Check if place exists
    const matchingPlace = allPlaces.find((p) => p.id === booking.itemId);
    if (matchingPlace) {
      handleShowPlaceOnMap(matchingPlace);
      return;
    }
    const matchingEvent = allEvents.find((e) => e.id === booking.itemId);
    if (matchingEvent) {
      handleShowEventOnMap(matchingEvent);
      return;
    }
    setActiveView('map');
  };

  const handleAddBookingToItinerary = (booking: Booking) => {
    const matchingPlace = allPlaces.find((p) => p.id === booking.itemId);
    if (matchingPlace) {
      handleOpenAddToItinerary({ type: 'place', item: matchingPlace });
      return;
    }
    const matchingEvent = allEvents.find((e) => e.id === booking.itemId);
    if (matchingEvent) {
      handleOpenAddToItinerary({ type: 'event', item: matchingEvent });
      return;
    }
  };

  const theatres = cityPlaces.filter((p) => p.category === 'theatre');
  const temples = cityPlaces.filter((p) => p.category === 'temple');
  const restaurants = cityPlaces.filter((p) => p.category === 'restaurant');
  const attractions = cityPlaces.filter((p) => p.category === 'attraction');

  // Dynamic curated highlights for the active city/district suggestion box
  const topFoodItem = useMemo(() => {
    const rest = restaurants[0];
    const dish = rest?.topDishes?.[0];
    return {
      title: dish?.name || (rest?.name ? `Signature ${rest.name.replace(/Heritage|Restaurant|Kitchen/gi, '').trim()}` : `Famous Cuisine in ${activeCity.name}`),
      description: dish?.description || rest?.tagline || `Authentic regional delicacies and traditional culinary delights of ${activeCity.name}.`,
    };
  }, [restaurants, activeCity]);

  const topTempleItem = useMemo(() => {
    const tmp1 = temples[0];
    const tmp2 = temples[1];
    return {
      title: tmp1?.name ? (tmp2 ? `${tmp1.name.split(' ')[0]} & ${tmp2.name.split(' ')[0]}` : tmp1.name) : `Sacred Shrines of ${activeCity.name}`,
      description: tmp1?.tagline || tmp1?.description || `Historic sanctums, peaceful morning aarti, and spiritual darshan in ${activeCity.name}.`,
    };
  }, [temples, activeCity]);

  const topTheatreItem = useMemo(() => {
    const th1 = theatres[0];
    const th2 = theatres[1];
    const movie = th1?.movies?.[0];
    return {
      title: th1 ? `${th1.name}${th2 ? ` & ${th2.name}` : ''}` : `Cinemas in ${activeCity.name}`,
      description: movie 
        ? `Now playing ${movie.title} with real 3D theatre seat booking!` 
        : `4K Laser Cinema & Dolby Atmos screens with 3D seat booking!`,
    };
  }, [theatres, activeCity]);

  const topAttraction1 = useMemo(() => {
    const attr = attractions[0];
    return {
      title: attr?.name || (activeCity.highlights?.[0] || `Top Landmark in ${activeCity.name}`),
      description: attr?.tagline || attr?.description || `Must-visit scenic spot and heritage destination in ${activeCity.name}.`,
    };
  }, [attractions, activeCity]);

  const topAttraction2 = useMemo(() => {
    const attr = attractions[1] || attractions[0];
    return {
      title: attr && attr !== attractions[0] ? attr.name : (activeCity.highlights?.[1] || `Scenic Viewpoints in ${activeCity.name}`),
      description: attr && attr !== attractions[0] ? (attr.tagline || attr.description) : `Scenic promenade, photography spots, and peaceful evening breeze in ${activeCity.name}.`,
    };
  }, [attractions, activeCity]);

  // FIRST SCREEN GATE: When user opens the app, display the login page first before entering inside app
  if (!isLoggedInOrUnlocked && !currentUser) {
    return (
      <>
        <LoginGateScreen
          allUsers={allUsers}
          onLogin={handleLoginUser}
          onRegister={handleRegisterUser}
          onOpenAdminPortal={() => {
            setIsAdminUnlocked(true);
            setIsLoggedInOrUnlocked(true);
            setIsAdminPortalOpen(true);
          }}
        />

        {/* Admin Portal Modal (if opened directly from admin tab) */}
        <AdminPortalModal
          isOpen={isAdminPortalOpen}
          onClose={() => setIsAdminPortalOpen(false)}
          users={allUsers}
          bookings={bookings}
          cities={citiesList}
          places={allPlaces}
          initialAuthenticated={isAdminUnlocked}
          onSelectDistrict={handleSelectIndiaDistrict}
          onSelectCity={(cityId) => handleSelectCity(cityId)}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#FDFCF8] text-[#3D3D3D] flex flex-col selection:bg-[#EAE7DC] selection:text-[#5A5A40] font-sans antialiased relative">
      {/* Real-time Booking Confirmation Toast */}
      {bookingToast && (
        <div className="fixed top-20 right-4 sm:right-6 z-50 bg-[#2D2D2A] text-white p-4 rounded-2xl shadow-2xl border border-amber-400/30 flex items-start gap-3 max-w-sm animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl shrink-0 mt-0.5">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
              <span>{bookingToast.title}</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-mono">
                E-TICKET READY
              </span>
            </h4>
            <p className="text-xs text-[#C5C2B8] mt-0.5 line-clamp-1">{bookingToast.subtitle}</p>
            <button
              onClick={() => {
                setBookingToast(null);
                setIsMyBookingsOpen(true);
              }}
              className="mt-2 text-xs font-bold text-amber-300 hover:text-amber-200 underline flex items-center gap-1"
            >
              <span>View E-Pass in My Bookings Wallet →</span>
            </button>
          </div>
          <button
            onClick={() => setBookingToast(null)}
            className="text-stone-400 hover:text-white p-1"
          >
            ×
          </button>
        </div>
      )}

      {/* GMP Quota Banner */}
      {gmpQuotaReached && (
        <div className="sticky top-0 z-50 bg-amber-500 text-stone-950 px-4 py-2 text-xs font-bold flex items-center justify-between shadow-md">
          <span>Google Maps request limit reached. Displaying offline interactive fallback mode.</span>
          <button
            type="button"
            onClick={() => setGmpQuotaReached(false)}
            className="text-stone-950 hover:text-stone-800 text-sm font-black px-2 cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        cities={citiesList}
        activeCity={activeCity}
        onSelectCity={handleSelectCity}
        activeView={activeView}
        onSelectView={setActiveView}
        itineraryItemCount={totalItineraryItemsCount}
        eventsCount={cityEvents.length}
        bookingsCount={bookings.length}
        onOpenAIModal={() => setIsAIModalOpen(true)}
        onOpenExploreModal={() => setIsExploreModalOpen(true)}
        onOpenMyBookings={() => setIsMyBookingsOpen(true)}
        onOpenSplashThumbnail={() => setIsSplashOpen(true)}
        currentUser={currentUser}
        onOpenUserAuth={() => setIsUserAuthOpen(true)}
        onOpenAdminPortal={() => setIsAdminPortalOpen(true)}
        onOpenIndiaJoyModal={() => setIsIndiaJoyModalOpen(true)}
        onLogout={handleLogoutUser}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 flex-1 w-full">
        {/* District Browser Gateway (Toggleable or active when choosing district) */}
        {isDistrictBrowserOpen ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#5A5A40] flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-amber-600" />
                <span>Select a District to Explore</span>
              </span>
              <button
                type="button"
                onClick={() => setIsDistrictBrowserOpen(false)}
                className="px-3 py-1.5 rounded-xl bg-white border border-[#DEDACF] text-xs font-bold text-[#2D2D2A] hover:bg-[#F4F1EA] cursor-pointer"
              >
                ← Back to {activeCity.name}
              </button>
            </div>
            <DistrictSelectorGateway
              onSelectDistrict={handleSelectIndiaDistrict}
              activeCityId={activeCityId}
            />
          </div>
        ) : (
          <>
            {/* Clean District Header Bar with Switch Action */}
            <div className="p-4 sm:p-5 rounded-3xl bg-white border border-[#E5E2D9] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-[#5A5A40] text-white flex items-center justify-center font-bold text-lg shadow-sm">
                  📍
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-extrabold uppercase text-[#8B8B6B] tracking-wider">
                      Active District
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-amber-400 text-stone-950">
                      {activeCity.state || 'Karnataka'}
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-serif font-extrabold text-[#2D2D2A]">
                    {activeCity.name}
                  </h2>
                  <p className="text-xs text-[#5A5A40] mt-0.5 line-clamp-1">
                    {activeCity.tagline || activeCity.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setIsDistrictBrowserOpen(true)}
                  className="px-4 py-2.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs font-extrabold flex items-center gap-2 transition-all shadow-sm cursor-pointer"
                >
                  <Compass className="w-4 h-4 text-stone-950" />
                  <span>Explore Other 31 Districts</span>
                </button>
              </div>
            </div>

            {/* Curated Suggestions: "What to Do in [City / District]" */}
            <div className="p-5 rounded-3xl bg-gradient-to-br from-[#FDFCF8] to-[#F4F1EA] border border-[#E5E2D9] space-y-3.5 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#EAE7DC]">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                  <h3 className="font-serif font-bold text-base sm:text-lg text-[#2D2D2A]">
                    What to Do in {activeCity.name} — Curated Suggestions
                  </h3>
                </div>
                <span className="text-[11px] text-[#8B8B6B] font-medium">
                  {theatres.length} Theatres · {temples.length} Temples · {restaurants.length} Food Spots · {attractions.length} Sightseeing
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
                {/* 1. Food */}
                <div
                  onClick={() => setActiveView('restaurant')}
                  className="p-3.5 rounded-2xl bg-white border border-[#E5E2D9] hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🍛</span>
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">Top Taste</span>
                  </div>
                  <strong className="block text-[#2D2D2A] text-xs line-clamp-1">1. {topFoodItem.title}</strong>
                  <p className="text-[11px] text-[#8B8B6B] line-clamp-2">
                    {topFoodItem.description}
                  </p>
                </div>

                {/* 2. Temples */}
                <div
                  onClick={() => setActiveView('temple')}
                  className="p-3.5 rounded-2xl bg-white border border-[#E5E2D9] hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🛕</span>
                    <span className="text-[10px] font-bold text-orange-700 bg-orange-50 px-2 py-0.5 rounded-full">Spiritual</span>
                  </div>
                  <strong className="block text-[#2D2D2A] text-xs line-clamp-1">2. {topTempleItem.title}</strong>
                  <p className="text-[11px] text-[#8B8B6B] line-clamp-2">
                    {topTempleItem.description}
                  </p>
                </div>

                {/* 3. Theatres & 3D */}
                <div
                  onClick={() => setActiveView('theatre')}
                  className="p-3.5 rounded-2xl bg-white border border-[#E5E2D9] hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🎬</span>
                    <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full">3D Cinema</span>
                  </div>
                  <strong className="block text-[#2D2D2A] text-xs line-clamp-1">3. {topTheatreItem.title}</strong>
                  <p className="text-[11px] text-[#8B8B6B] line-clamp-2">
                    {topTheatreItem.description}
                  </p>
                </div>

                {/* 4. Scenic Attractions */}
                <div
                  onClick={() => setActiveView('attraction')}
                  className="p-3.5 rounded-2xl bg-white border border-[#E5E2D9] hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🌅</span>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">Scenic Walk</span>
                  </div>
                  <strong className="block text-[#2D2D2A] text-xs line-clamp-1">4. {topAttraction1.title}</strong>
                  <p className="text-[11px] text-[#8B8B6B] line-clamp-2">
                    {topAttraction1.description}
                  </p>
                </div>

                {/* 5. Vistas & Heritage */}
                <div
                  onClick={() => setActiveView('attraction')}
                  className="p-3.5 rounded-2xl bg-white border border-[#E5E2D9] hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🏞️</span>
                    <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">Vistas</span>
                  </div>
                  <strong className="block text-[#2D2D2A] text-xs line-clamp-1">5. {topAttraction2.title}</strong>
                  <p className="text-[11px] text-[#8B8B6B] line-clamp-2">
                    {topAttraction2.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Smart Tourist Decision Hub (Answers the 6 Hackathon Questions) */}
            <SmartTouristDecisionHub
              city={activeCity}
              places={cityPlaces}
              onSelectPlace={handleOpenPlaceDetail}
              onNavigateToPlace={handleShowPlaceOnMap}
              onOpenBookings={() => setIsMyBookingsOpen(true)}
            />

            {/* 4 Options Time Spender Selector: Theatres, Temples, Restaurants, Tourist Spots */}
            <CityTimeSpenderSelector
              cityName={activeCity.name}
              theatreCount={theatres.length}
              templeCount={temples.length}
              restaurantCount={restaurants.length}
              attractionCount={attractions.length}
              activeView={activeView}
              onSelectOption={(opt) => setActiveView(opt)}
            />
          </>
        )}

        {/* Dynamic Views Rendering based on active tab */}
        {activeView === 'events' && (
          <EventsView
            city={activeCity}
            events={cityEvents}
            onSelectEvent={handleOpenEventDetail}
            onShowOnMap={handleShowEventOnMap}
            onAddToItinerary={(ev) => handleOpenAddToItinerary({ type: 'event', item: ev })}
            onBookEvent={(ev) => handleOpenDirectBooking({ event: ev, category: 'event' })}
            itineraryEventIds={itineraryScheduledEventIds}
          />
        )}

        {activeView === 'itinerary' && (
          <ItineraryPlannerView
            city={activeCity}
            places={cityPlaces}
            events={cityEvents}
            activePlan={activePlan}
            onUpdatePlan={handleUpdatePlan}
            onShowOnMap={(item) => {
              if ('title' in item) {
                handleShowEventOnMap(item as CityEvent);
              } else {
                handleShowPlaceOnMap(item as Place);
              }
            }}
            onSelectPlace={handleOpenPlaceDetail}
            onSelectEvent={handleOpenEventDetail}
            onOpenMapWithRoute={handleOpenMapWithRoute}
          />
        )}

        {activeView === 'theatre' && (
          <TheatresView
            theatres={theatres}
            onSelectPlace={handleOpenPlaceDetail}
            onShowOnMap={handleShowPlaceOnMap}
            onBookMovie={(movie, theatre, showtime) =>
              handleOpenDirectBooking({
                place: theatre,
                category: 'theatre',
                movie,
                showtime,
              })
            }
            onOpen3DTheatreBooking={(theatre, movie, showtime) => {
              setTheatreFor3D(theatre);
              setMovieFor3D(movie);
              setShowtimeFor3D(showtime);
              setIs3DTheatreModalOpen(true);
            }}
          />
        )}

        {activeView === 'temple' && (
          <TemplesView
            temples={temples}
            onSelectPlace={handleOpenPlaceDetail}
            onShowOnMap={handleShowPlaceOnMap}
            onAddToItinerary={(pl) => handleOpenAddToItinerary({ type: 'place', item: pl })}
            onBookDirectly={({ place }) => handleOpenDirectBooking({ place, category: 'temple' })}
          />
        )}

        {activeView === 'restaurant' && (
          <RestaurantsView
            restaurants={restaurants}
            onSelectPlace={handleOpenPlaceDetail}
            onShowOnMap={handleShowPlaceOnMap}
          />
        )}

        {activeView === 'attraction' && (
          <AttractionsView
            attractions={attractions}
            onSelectPlace={handleOpenPlaceDetail}
            onShowOnMap={handleShowPlaceOnMap}
          />
        )}

        {activeView === 'map' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FDFCF8] border border-[#E5E2D9] p-5 rounded-3xl shadow-xs">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#2D2D2A] text-white">
                    Dedicated Map Slot
                  </span>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#2D2D2A]">
                    {activeCity.name} Geographic Map & Waypoints
                  </h2>
                </div>
                <p className="text-xs text-[#8B8B6B] mt-1">
                  Interactive live coordinates across sacred temples, cinemas, food spots, heritage tickets & events.
                </p>
              </div>

              {mapItineraryRoute && (
                <button
                  onClick={() => setMapItineraryRoute(undefined)}
                  className="px-3.5 py-2 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#5A5A40] text-xs font-bold rounded-xl border border-[#DEDACF] transition-colors"
                >
                  Clear Itinerary Route ({mapItineraryRoute.length} stops)
                </button>
              )}
            </div>

            <InteractiveMap
              city={activeCity}
              places={cityPlaces}
              events={cityEvents}
              selectedCategory={mapCategoryFilter}
              onCategoryChange={setMapCategoryFilter}
              onSelectPlace={handleOpenPlaceDetail}
              onSelectEvent={handleOpenEventDetail}
              onAddToItinerary={handleOpenAddToItinerary}
              activePlace={mapActivePlace}
              activeEvent={mapActiveEvent}
              itineraryRouteItems={mapItineraryRoute}
            />
          </div>
        )}

        {activeView === 'all' && (
          <div className="space-y-10">
            {/* Slot Quick Switcher / Navigator */}
            <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-serif font-bold text-sm text-[#2D2D2A] flex items-center gap-2">
                  <Compass className="w-4 h-4 text-[#5A5A40]" />
                  <span>City Directory Slots — Jump to Section or Open Dedicated View</span>
                </span>
                <span className="text-[11px] text-[#8B8B6B] hidden sm:inline">
                  {filteredPlaces.length} Places · {cityEvents.length} Events
                </span>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                <button
                  onClick={() => setActiveView('temple')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] font-bold border border-[#DEDACF] whitespace-nowrap transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>Sacred Temples ({temples.length})</span>
                </button>

                <button
                  onClick={() => setActiveView('map')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] font-bold border border-[#DEDACF] whitespace-nowrap transition-colors"
                >
                  <MapIcon className="w-3.5 h-3.5 text-[#5A5A40]" />
                  <span>Interactive Map Slot</span>
                </button>

                <button
                  onClick={() => setActiveView('theatre')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] font-bold border border-[#DEDACF] whitespace-nowrap transition-colors"
                >
                  <Film className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Theatres ({theatres.length})</span>
                </button>

                <button
                  onClick={() => setActiveView('restaurant')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] font-bold border border-[#DEDACF] whitespace-nowrap transition-colors"
                >
                  <UtensilsCrossed className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Restaurants ({restaurants.length})</span>
                </button>

                <button
                  onClick={() => setActiveView('attraction')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] font-bold border border-[#DEDACF] whitespace-nowrap transition-colors"
                >
                  <Landmark className="w-3.5 h-3.5 text-rose-600" />
                  <span>Heritage Sights ({attractions.length})</span>
                </button>

                <button
                  onClick={() => setActiveView('events')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#FFF9F0] hover:bg-[#FBE8D6] text-[#C2410C] font-bold border border-[#F3E5D8] whitespace-nowrap transition-colors"
                >
                  <PartyPopper className="w-3.5 h-3.5 text-[#C2410C]" />
                  <span>Events Near Me ({cityEvents.length})</span>
                </button>
              </div>
            </div>

            {/* If filtering returned 0 places */}
            {filteredPlaces.length === 0 && (
              <div className="p-12 text-center bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl space-y-3">
                <Compass className="w-10 h-10 text-[#8B8B6B] mx-auto animate-spin" />
                <h3 className="font-serif font-bold text-base text-[#2D2D2A]">No places matched your filter</h3>
                <p className="text-xs text-[#8B8B6B] max-w-sm mx-auto">
                  Try clearing your search query or switching to "All Places" filter to see the complete guide.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setQuickFilter('all');
                  }}
                  className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-xs font-bold hover:bg-[#484832]"
                >
                  Reset All Filters
                </button>
              </div>
            )}

            {/* SLOT 1: Sacred Temples & Live Crowd Radar */}
            {filteredPlaces.some((p) => p.category === 'temple') && (
              <section id="slot-temples" className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-[#8B8B6B] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                      <Sparkles className="w-4 h-4" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#F4F1EA] text-[#5A5A40] px-2 py-0.5 rounded-md border border-[#DEDACF]">
                          Slot 1 · Temples
                        </span>
                        <h3 className="font-serif font-bold text-xl text-[#2D2D2A]">
                          Sacred Temples & Live Crowd Radar ({filteredPlaces.filter((p) => p.category === 'temple').length})
                        </h3>
                      </div>
                      <p className="text-xs text-[#8B8B6B] mt-0.5">
                        Crowd density radar, Aarti peak hours, VIP darshan passes & dress codes
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveView('temple')}
                    className="self-start sm:self-auto text-xs font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1 transition-colors px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] border border-[#DEDACF]"
                  >
                    <span>Open Full Temple Radar Slot</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredPlaces
                    .filter((p) => p.category === 'temple')
                    .map((place) => (
                      <PlaceCard
                        key={place.id}
                        place={place}
                        onSelect={handleOpenPlaceDetail}
                        onShowOnMap={handleShowPlaceOnMap}
                        onAddToItinerary={(pl) => handleOpenAddToItinerary({ type: 'place', item: pl })}
                        onBookDirectly={(pl) => handleOpenDirectBooking({ place: pl, category: 'temple' })}
                        isSavedInItinerary={itineraryScheduledPlaceIds.includes(place.id)}
                      />
                    ))}
                </div>
              </section>
            )}

            {/* SLOT 2: Dedicated Geographic Map Slot */}
            <section id="slot-map" className="space-y-4 pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-8 h-8 rounded-xl bg-[#2D2D2A] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                    <MapIcon className="w-4 h-4 text-amber-300" />
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-[#F4F1EA] text-[#5A5A40] px-2 py-0.5 rounded-md border border-[#DEDACF]">
                        Slot 2 · Geographic Map
                      </span>
                      <h3 className="font-serif font-bold text-xl text-[#2D2D2A]">
                        Interactive City Map & Live Waypoints
                      </h3>
                    </div>
                    <p className="text-xs text-[#8B8B6B] mt-0.5">
                      Explore geo-pinned locations, filter categories, and inspect distance coordinates
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setActiveView('map')}
                  className="self-start sm:self-auto text-xs font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1 transition-colors px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] border border-[#DEDACF]"
                >
                  <span>Launch Dedicated Full Map Canvas</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="rounded-3xl overflow-hidden border border-[#E5E2D9] shadow-xs">
                <InteractiveMap
                  city={activeCity}
                  places={cityPlaces}
                  events={cityEvents}
                  selectedCategory="all"
                  onCategoryChange={() => {}}
                  onSelectPlace={handleOpenPlaceDetail}
                  onSelectEvent={handleOpenEventDetail}
                  onAddToItinerary={handleOpenAddToItinerary}
                  activePlace={mapActivePlace}
                />
              </div>
            </section>

            {/* SLOT 3: Theatres & Movie Screenings */}
            {filteredPlaces.some((p) => p.category === 'theatre') && (
              <section id="slot-theatres" className="space-y-4 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-[#5A5A40] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                      <Film className="w-4 h-4" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#F4F1EA] text-[#5A5A40] px-2 py-0.5 rounded-md border border-[#DEDACF]">
                          Slot 3 · Theatres
                        </span>
                        <h3 className="font-serif font-bold text-xl text-[#2D2D2A]">
                          Nearby Theatres & Currently Playing Movies ({filteredPlaces.filter((p) => p.category === 'theatre').length})
                        </h3>
                      </div>
                      <p className="text-xs text-[#8B8B6B] mt-0.5">
                        Cinema halls, IMAX laser screens, showtimes & ticket tiers
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveView('theatre')}
                    className="self-start sm:self-auto text-xs font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1 transition-colors px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] border border-[#DEDACF]"
                  >
                    <span>Open Full Theatres Slot</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredPlaces
                    .filter((p) => p.category === 'theatre')
                    .map((place) => (
                      <PlaceCard
                        key={place.id}
                        place={place}
                        onSelect={handleOpenPlaceDetail}
                        onShowOnMap={handleShowPlaceOnMap}
                        onAddToItinerary={(pl) => handleOpenAddToItinerary({ type: 'place', item: pl })}
                        onBookDirectly={(pl) => handleOpenDirectBooking({ place: pl, category: 'theatre' })}
                        isSavedInItinerary={itineraryScheduledPlaceIds.includes(place.id)}
                      />
                    ))}
                </div>
              </section>
            )}

            {/* SLOT 4: Restaurants & Top-Rated Dishes */}
            {filteredPlaces.some((p) => p.category === 'restaurant') && (
              <section id="slot-restaurants" className="space-y-4 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-[#4A6741] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                      <UtensilsCrossed className="w-4 h-4" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#F4F1EA] text-[#4A6741] px-2 py-0.5 rounded-md border border-[#DEDACF]">
                          Slot 4 · Dining
                        </span>
                        <h3 className="font-serif font-bold text-xl text-[#2D2D2A]">
                          Top Rated Restaurants & Must-Try Dishes ({filteredPlaces.filter((p) => p.category === 'restaurant').length})
                        </h3>
                      </div>
                      <p className="text-xs text-[#8B8B6B] mt-0.5">
                        Iconic culinary spots, rated signature dishes & authentic local eateries
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveView('restaurant')}
                    className="self-start sm:self-auto text-xs font-bold text-[#4A6741] hover:text-[#2D2D2A] flex items-center gap-1 transition-colors px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] border border-[#DEDACF]"
                  >
                    <span>Open Full Food Slot</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredPlaces
                    .filter((p) => p.category === 'restaurant')
                    .map((place) => (
                      <PlaceCard
                        key={place.id}
                        place={place}
                        onSelect={handleOpenPlaceDetail}
                        onShowOnMap={handleShowPlaceOnMap}
                        onAddToItinerary={(pl) => handleOpenAddToItinerary({ type: 'place', item: pl })}
                        onBookDirectly={(pl) => handleOpenDirectBooking({ place: pl, category: 'restaurant' })}
                        isSavedInItinerary={itineraryScheduledPlaceIds.includes(place.id)}
                      />
                    ))}
                </div>
              </section>
            )}

            {/* SLOT 5: Heritage Tourist Sights & Entry Tickets */}
            {filteredPlaces.some((p) => p.category === 'attraction') && (
              <section id="slot-attractions" className="space-y-4 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-[#C2410C] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                      <Landmark className="w-4 h-4" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#FFF9F0] text-[#C2410C] px-2 py-0.5 rounded-md border border-[#F3E5D8]">
                          Slot 5 · Sights
                        </span>
                        <h3 className="font-serif font-bold text-xl text-[#2D2D2A]">
                          Tourist Places, Heritage Sights & Entry Tickets ({filteredPlaces.filter((p) => p.category === 'attraction').length})
                        </h3>
                      </div>
                      <p className="text-xs text-[#8B8B6B] mt-0.5">
                        Verified admission rates, audio guides, opening hours & visitor tips
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveView('attraction')}
                    className="self-start sm:self-auto text-xs font-bold text-[#C2410C] hover:text-[#2D2D2A] flex items-center gap-1 transition-colors px-3 py-1.5 rounded-xl bg-[#FFF9F0] hover:bg-[#FBE8D6] border border-[#F3E5D8]"
                  >
                    <span>Open Full Sights Slot</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredPlaces
                    .filter((p) => p.category === 'attraction')
                    .map((place) => (
                      <PlaceCard
                        key={place.id}
                        place={place}
                        onSelect={handleOpenPlaceDetail}
                        onShowOnMap={handleShowPlaceOnMap}
                        onAddToItinerary={(pl) => handleOpenAddToItinerary({ type: 'place', item: pl })}
                        onBookDirectly={(pl) => handleOpenDirectBooking({ place: pl, category: 'attraction' })}
                        isSavedInItinerary={itineraryScheduledPlaceIds.includes(place.id)}
                      />
                    ))}
                </div>
              </section>
            )}

            {/* SLOT 6: Events Near Me */}
            {cityEvents.length > 0 && (
              <section id="slot-events" className="space-y-4 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-[#C2410C] text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                      <PartyPopper className="w-4 h-4" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#FFF9F0] text-[#C2410C] px-2 py-0.5 rounded-md border border-[#F3E5D8]">
                          Slot 6 · Live Events
                        </span>
                        <h3 className="font-serif font-bold text-xl text-[#2D2D2A]">
                          Upcoming Events & Cultural Festivals ({cityEvents.length})
                        </h3>
                      </div>
                      <p className="text-xs text-[#8B8B6B] mt-0.5">
                        Live concerts, art exhibitions, religious celebrations & night markets
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveView('events')}
                    className="self-start sm:self-auto text-xs font-bold text-[#C2410C] hover:text-[#2D2D2A] flex items-center gap-1 transition-colors px-3 py-1.5 rounded-xl bg-[#FFF9F0] hover:bg-[#FBE8D6] border border-[#F3E5D8]"
                  >
                    <span>Open Full Events Slot</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {cityEvents.slice(0, 3).map((event) => (
                    <div
                      key={event.id}
                      className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="relative h-44 w-full bg-[#F4F1EA] overflow-hidden">
                          <img
                            src={event.image}
                            alt={event.title}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute top-3 left-3 bg-[#2D2D2A]/90 backdrop-blur-xs text-white px-2.5 py-1 rounded-xl text-xs font-bold">
                            {event.category}
                          </div>
                          <div className="absolute top-3 right-3 bg-[#FDFCF8] text-[#2D2D2A] px-2.5 py-1 rounded-xl text-xs font-bold shadow-xs">
                            {event.isFree ? 'FREE' : `${event.currency}${event.ticketPrice}`}
                          </div>
                        </div>

                        <div className="p-4 space-y-2">
                          <h4 className="font-serif font-bold text-base text-[#2D2D2A] leading-snug">
                            {event.title}
                          </h4>
                          <p className="text-xs text-[#5A5A40] line-clamp-2">
                            {event.description}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-[#8B8B6B] pt-1">
                            <Calendar className="w-3.5 h-3.5 text-[#D28E5D]" />
                            <span>{event.date} · {event.timing}</span>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 pt-0 flex flex-wrap items-center gap-2">
                        <button
                          onClick={() => handleOpenDirectBooking({ event, category: 'event' })}
                          className="flex-1 py-2 bg-[#C2410C] hover:bg-[#9A3412] text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1 shadow-2xs"
                        >
                          <Ticket className="w-3.5 h-3.5" />
                          <span>Book Pass</span>
                        </button>
                        <button
                          onClick={() => handleOpenEventDetail(event)}
                          className="px-3 py-2 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#5A5A40] text-xs font-bold rounded-xl transition-colors border border-[#DEDACF]"
                        >
                          Details
                        </button>
                        <button
                          onClick={() => handleShowEventOnMap(event)}
                          className="p-2 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] rounded-xl border border-[#DEDACF] transition-colors"
                          title="View on Map"
                        >
                          <MapPin className="w-4 h-4 text-[#D28E5D]" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      {/* Footer in Natural Tones */}
      <footer className="bg-[#F4F1EA] border-t border-[#E5E2D9] py-8 px-4 sm:px-6 text-[#5A5A40] text-xs mt-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <span className="font-serif font-bold text-[#2D2D2A] block text-sm">
                City Tourist Guide
              </span>
              <span className="text-[10px] text-[#8B8B6B] font-semibold px-2 py-0.5 rounded-full bg-[#EAE7DC] border border-[#DEDACF]">
                created by jeevan m k
              </span>
            </div>
            <p className="text-[#8B8B6B] text-[11px] mt-0.5 font-sans">
              Personalized multi-day itinerary planner, peak crowd radar, cinema showtimes, rated dishes & live events.
            </p>
          </div>

          <div className="text-center sm:text-right text-[11px] text-[#8B8B6B]">
            <p>© {new Date().getFullYear()} City Tourist Guide. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Opening Splash / Intro Thumbnail Screen */}
      <AppSplashThumbnail
        isOpen={isSplashOpen}
        onClose={() => setIsSplashOpen(false)}
        activeCityName={activeCity.name}
      />

      {/* User Login & Registration Modal (Separate for general users) */}
      <UserAuthModal
        isOpen={isUserAuthOpen}
        onClose={() => setIsUserAuthOpen(false)}
        currentUser={currentUser}
        onLogin={handleLoginUser}
        onRegister={handleRegisterUser}
        onLogout={handleLogoutUser}
        allUsers={allUsers}
        registeredUsers={allUsers}
        onOpenMyBookings={() => {
          setIsUserAuthOpen(false);
          setIsMyBookingsOpen(true);
        }}
        onOpenAdminPortal={() => {
          setIsUserAuthOpen(false);
          setIsAdminPortalOpen(true);
        }}
      />

      {/* Admin Portal Modal (Restricted for administrator jeevan m k) */}
      <AdminPortalModal
        isOpen={isAdminPortalOpen}
        onClose={() => setIsAdminPortalOpen(false)}
        users={allUsers}
        bookings={bookings}
        cities={citiesList}
        places={allPlaces}
        initialAuthenticated={isAdminUnlocked}
        onSelectDistrict={handleSelectIndiaDistrict}
        onSelectCity={(cityId) => handleSelectCity(cityId)}
      />

      {/* Place Detail & Review Modal */}
      <PlaceDetailModal
        place={selectedPlace}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onShowOnMap={handleShowPlaceOnMap}
        onAddToItinerary={(pl) => handleOpenAddToItinerary({ type: 'place', item: pl })}
        onBookDirectly={(target) => handleOpenDirectBooking(target)}
        isSavedInItinerary={selectedPlace ? itineraryScheduledPlaceIds.includes(selectedPlace.id) : false}
        onAddReview={handleAddReview}
      />

      {/* Event Detail Modal */}
      <EventDetailModal
        event={selectedEvent}
        isOpen={isEventModalOpen}
        onClose={() => setIsEventModalOpen(false)}
        onShowOnMap={handleShowEventOnMap}
        onAddToItinerary={(ev) => handleOpenAddToItinerary({ type: 'event', item: ev })}
        onBookEvent={(ev) => handleOpenDirectBooking({ event: ev, category: 'event' })}
        isSavedInItinerary={selectedEvent ? itineraryScheduledEventIds.includes(selectedEvent.id) : false}
      />

      {/* Add To Itinerary Schedule Modal */}
      <AddToItineraryModal
        isOpen={isAddToItineraryOpen}
        onClose={() => setIsAddToItineraryOpen(false)}
        targetItem={addToItineraryTarget}
        activePlan={activePlan}
        onSaveItem={handleSaveItineraryItem}
        onAddNewDay={() => {
          const nextDayNum = activePlan.days.length + 1;
          const newDay = {
            id: `day-${nextDayNum}-${Date.now()}`,
            dayNumber: nextDayNum,
            date: '',
            title: `Day ${nextDayNum} in ${activeCity.name}`,
            items: [],
          };
          handleUpdatePlan({
            ...activePlan,
            days: [...activePlan.days, newDay],
          });
        }}
      />

      {/* Ticket Calculator Modal */}
      <TicketCalculatorModal
        city={activeCity}
        savedPlaces={cityPlaces.filter((p) => itineraryScheduledPlaceIds.includes(p.id))}
        allCityPlaces={cityPlaces}
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
        onRemovePlace={(id) => {}}
        onAddPlace={(p) => handleOpenAddToItinerary({ type: 'place', item: p })}
      />

      {/* AI Concierge Modal */}
      <AIConciergeModal
        city={activeCity}
        places={cityPlaces}
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        onSelectPlace={handleOpenPlaceDetail}
      />

      {/* Explore Any City Generator Modal */}
      <ExploreNewCityModal
        isOpen={isExploreModalOpen}
        onClose={() => setIsExploreModalOpen(false)}
        onCityGenerated={handleCityGenerated}
      />

      {/* Direct Booking Modal */}
      <DirectBookingModal
        target={bookingTarget}
        isOpen={isBookingModalOpen}
        cityName={activeCity.name}
        currentUser={currentUser}
        onClose={() => setIsBookingModalOpen(false)}
        onBookingSuccess={handleBookingSuccess}
      />

      {/* My Bookings & QR Passes Wallet Modal */}
      <MyBookingsModal
        isOpen={isMyBookingsOpen}
        onClose={() => setIsMyBookingsOpen(false)}
        bookings={bookings}
        onCancelBooking={handleCancelBooking}
        onViewOnMap={handleViewBookingOnMap}
        onAddToItinerary={handleAddBookingToItinerary}
      />

      {/* India States & Districts Joy Explorer Modal */}
      <IndiaJoyExplorerModal
        isOpen={isIndiaJoyModalOpen}
        onClose={() => setIsIndiaJoyModalOpen(false)}
        onSelectDistrict={handleSelectIndiaDistrict}
        currentCityName={activeCity.name}
      />

      {/* 3D Theatre Booking Modal */}
      {theatreFor3D && (
        <ThreeDTheatreBookingModal
          isOpen={is3DTheatreModalOpen}
          onClose={() => setIs3DTheatreModalOpen(false)}
          theatre={theatreFor3D}
          movie={movieFor3D}
          showtime={showtimeFor3D}
          onBookingConfirmed={(bookingData) => {
            const newBooking: Booking = {
              id: `bkg-${Date.now()}`,
              bookingRef: bookingData.bookingRef,
              bookingDate: new Date().toISOString(),
              serviceDate: 'Today',
              serviceTime: bookingData.showtime,
              category: 'theatre',
              itemId: theatreFor3D.id,
              itemTitle: `${bookingData.movieTitle} · ${theatreFor3D.name}`,
              itemSubtitle: theatreFor3D.name,
              itemAddress: theatreFor3D.address,
              itemImage: theatreFor3D.image,
              cityName: activeCity.name,
              customerName: currentUser?.name || 'Guest Movie Buff',
              customerEmail: currentUser?.email || 'guest@example.com',
              customerPhone: currentUser?.phone || '+91 99000 00000',
              details: {
                selectedSeats: bookingData.seats,
                screenName: theatreFor3D.name,
              },
              totalAmount: bookingData.totalAmount,
              currency: '₹',
              paymentMethod: 'UPI',
              paymentStatus: 'Paid & Confirmed',
              bookingStatus: 'Confirmed',
              qrCodeValue: bookingData.bookingRef,
              createdAt: new Date().toISOString(),
            };
            handleBookingSuccess(newBooking);
          }}
        />
      )}
    </div>
  );
}

export default App;
