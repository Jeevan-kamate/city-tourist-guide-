export type PlaceCategory = 'theatre' | 'temple' | 'restaurant' | 'attraction' | 'event';

export interface TicketInfo {
  isFree: boolean;
  generalPrice: number | string;
  vipPrice?: number | string;
  childPrice?: number | string;
  foreignTouristPrice?: number | string;
  seniorPrice?: number | string;
  currency: string;
  ticketNotes?: string;
  bookingAvailable?: boolean;
}

export interface RitualTiming {
  name: string;
  time: string;
  crowdImpact: 'High' | 'Medium' | 'Low' | string;
  description?: string;
}

export interface CrowdInfo {
  peakHours: string[];
  leastCrowdHours: string;
  bestTimeToVisit?: string;
  peakDays?: string[];
  liveCrowdLevel?: string;
  hourlyCrowdIndex: number[]; // 24 values (00:00 to 23:00) representing crowd density 0 - 100
  tipsToAvoidCrowd?: string[];
  specialRituals?: RitualTiming[];
  avgWaitTimeMinutes?: {
    peak: number;
    normal: number;
    vip?: number;
  };
}

export interface MovieShow {
  id: string;
  title: string;
  poster: string;
  language: string;
  format: string; // e.g., "IMAX 3D", "4DX", "Dolby Atmos 2D"
  duration: string;
  genre: string[];
  rating: number; // 0-10
  certification: string; // 'U', 'UA', 'PG-13', 'A'
  synopsis: string;
  showtimes: {
    time: string;
    price: number;
    currency: string;
    seatAvailability: 'Available' | 'Filling Fast' | 'Almost Full' | 'Sold Out' | string;
    screenType: string;
  }[];
}

export interface MenuItem {
  name: string;
  isVeg: boolean;
  price: string;
  rating: number;
  reviewCount: number;
  description: string;
  badge?: 'Most Rated' | 'Signature Dish' | 'Chef Special' | 'Must Try' | 'Local Favorite' | string;
  category?: string;
  image?: string;
}

export interface Review {
  id: string;
  author?: string;
  userName?: string;
  userLocation?: string;
  authorType?: string;
  userType?: string;
  rating: number;
  date: string;
  comment: string;
  visitedTime?: string;
  crowdExperience?: string;
  recommendedItem?: string;
  helpfulCount?: number;
  userLiked?: boolean;
  verifiedVisit?: boolean;
}

export interface Place {
  id: string;
  cityId: string;
  name: string;
  category: PlaceCategory;
  tagline: string;
  description: string;
  image: string;
  gallery?: string[];
  rating: number;
  reviewCount: number;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  timings: {
    open: string;
    close: string;
    days: string;
    afternoonBreak?: string;
    breakTime?: string;
    currentStatus?: string;
    specialNote?: string;
  };
  ticket: TicketInfo;
  crowd?: CrowdInfo;
  movies?: MovieShow[];
  topDishes?: MenuItem[];
  cuisine?: string[];
  priceCategory?: '$' | '$$' | '$$$' | '$$$$' | string;
  templeDeity?: string;
  dressCode?: string;
  facilities?: string[];
  reviews: Review[];
  phone?: string;
  website?: string;
  bestTimeToVisit?: string;
}

export type EventCategory = 
  | 'festival' 
  | 'concert' 
  | 'exhibition' 
  | 'food_fair' 
  | 'theatre_drama' 
  | 'cultural_ritual' 
  | 'night_market';

export interface CityEvent {
  id: string;
  cityId: string;
  title: string;
  category: EventCategory;
  date: string; // Display date string e.g. "Aug 22 - Aug 25, 2026" or "Tonight"
  startDate: string; // ISO format or YYYY-MM-DD
  endDate?: string;
  timing: string; // e.g. "18:00 - 22:30"
  locationName: string;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  description: string;
  image: string;
  isFree: boolean;
  ticketPrice?: number | string;
  currency: string;
  organizer?: string;
  expectedCrowd?: 'Light' | 'Moderate' | 'High' | 'Very High' | string;
  highlights?: string[];
  bookingUrl?: string;
  status: 'Happening Today' | 'This Weekend' | 'Upcoming' | 'Annual Festival';
  tags?: string[];
}

export interface City {
  id: string;
  name: string;
  state: string;
  country: string;
  tagline: string;
  description: string;
  coverImage: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  bestSeason: string;
  localCurrency: string;
  currencySymbol: string;
  language: string;
  timezone: string;
  emergencyContact: string;
  highlights: string[];
}

export interface ItineraryScheduleItem {
  id: string;
  type: 'place' | 'event' | 'custom';
  placeId?: string;
  place?: Place;
  eventId?: string;
  event?: CityEvent;
  customTitle?: string;
  customLocation?: string;
  startTime: string; // "09:00"
  endTime: string;   // "11:00"
  notes?: string;
  estimatedCost?: number;
  currency?: string;
  transportMode?: 'walk' | 'taxi' | 'metro' | 'auto';
  isCompleted?: boolean;
}

export interface ItineraryDay {
  id: string;
  dayNumber: number;
  date: string; // YYYY-MM-DD
  title?: string;
  notes?: string;
  items: ItineraryScheduleItem[];
}

export interface ItineraryPlan {
  id: string;
  cityId: string;
  cityName?: string;
  title: string;
  description?: string;
  isCustom?: boolean;
  startDate: string;
  endDate: string;
  days: ItineraryDay[];
  totalBudget?: number;
  currency?: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface BookingDetails {
  // Movie specific
  movieTitle?: string;
  movieFormat?: string;
  movieLanguage?: string;
  screenName?: string;
  showtime?: string;
  selectedSeats?: string[];
  selectedSnacks?: { name: string; quantity: number; price: number }[];

  // Temple specific
  darshanType?: string;
  poojaSlot?: string;
  prasaadamQuantity?: number;
  idProofType?: string;
  idProofNumber?: string;
  devoteeCount?: number;

  // Restaurant specific
  partySize?: number;
  mealSlot?: string;
  tableTime?: string;
  seatingArea?: string;
  preOrderedDishes?: { name: string; quantity: number; price: string }[];
  specialInstructions?: string;

  // Attraction / Sight specific
  ticketBreakdown?: {
    adults: number;
    children: number;
    seniors: number;
    foreignTourists: number;
    audioGuides: number;
  };
  entrySlot?: string;

  // Event specific
  eventTier?: string;
  eventDate?: string;
  eventTime?: string;
  ticketCount?: number;
}

export type BookingCategory = 'theatre' | 'temple' | 'restaurant' | 'attraction' | 'event';

export interface Booking {
  id: string;
  bookingRef: string;
  bookingDate: string;
  serviceDate: string;
  serviceTime?: string;
  category: BookingCategory;
  itemId: string;
  itemTitle: string;
  itemSubtitle?: string;
  itemAddress: string;
  itemImage: string;
  cityName: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  details: BookingDetails;
  totalAmount: number;
  currency: string;
  paymentMethod: 'UPI' | 'Card' | 'ApplePay' | 'NetBanking' | 'PayAtCounter';
  paymentStatus: 'Paid & Confirmed' | 'Confirmed (Pay at Venue)';
  bookingStatus: 'Confirmed' | 'Completed' | 'Cancelled';
  qrCodeValue: string;
  createdAt: string;
}

export interface BookingTarget {
  type?: 'movie' | 'theatre' | 'temple' | 'restaurant' | 'attraction' | 'event';
  category?: BookingCategory;
  place?: Place;
  event?: CityEvent;
  movie?: MovieShow;
  initialMovie?: MovieShow;
  showtime?: {
    time: string;
    price: number;
    currency: string;
    screenType: string;
  };
  initialShowtime?: {
    time: string;
    price: number;
    currency: string;
    screenType: string;
  };
  initialDarshanType?: string;
}

export interface UserActivityLog {
  id: string;
  action: string;
  category?: BookingCategory | 'auth' | 'navigation';
  itemTitle?: string;
  bookingRef?: string;
  amount?: number;
  timestamp: string;
  details?: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
  password?: string;
  avatar?: string;
  joinedAt: string;
  lastLoginAt: string;
  bookingsCount: number;
  totalSpent: number;
  activityLogs: UserActivityLog[];
}

