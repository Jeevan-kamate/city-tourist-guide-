import { City, Place } from '../types';

export const CITIES: City[] = [
  {
    id: 'varanasi',
    name: 'Varanasi (Kashi)',
    state: 'Uttar Pradesh',
    country: 'India',
    tagline: 'The Spiritual Capital of India & World\'s Oldest Living City',
    description: 'Perched along the holy Ganges, Varanasi is an ethereal tapestry of sacred ghats, ancient temples with centuries-old aarti rituals, lively silk bazaars, iconic street chaat, and modern entertainment hubs.',
    coverImage: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=1200&q=80',
    coordinates: { lat: 25.3176, lng: 82.9739 },
    bestSeason: 'October to March',
    localCurrency: 'INR (₹)',
    currencySymbol: '₹',
    language: 'Hindi, Bhojpuri, English',
    timezone: 'IST (UTC+5:30)',
    emergencyContact: 'Tourist Police: 112 / +91-542-2503233',
    highlights: ['Kashi Vishwanath Corridor', 'Ganga Evening Aarti', 'Subah-e-Banaras Assi Ghat', 'Banarasi Silk & Chaat Street', 'Sarnath Buddhist Stupa']
  },
  {
    id: 'kyoto',
    name: 'Kyoto',
    state: 'Kansai',
    country: 'Japan',
    tagline: 'Cultural Heart of Japan with 1,000+ Golden Temples & Zen Gardens',
    description: 'Ancient imperial capital preserving thousands of classical Buddhist temples, Shinto shrines with vermilion torii gates, sublime kaiseki gastronomy, historic geisha districts, and premier cinemas.',
    coverImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80',
    coordinates: { lat: 35.0116, lng: 135.7681 },
    bestSeason: 'March to May (Sakura) & Oct to Nov (Autumn Foliage)',
    localCurrency: 'JPY (¥)',
    currencySymbol: '¥',
    language: 'Japanese, English',
    timezone: 'JST (UTC+9:00)',
    emergencyContact: 'Tourist Hotline: #9110 / +81-75-343-0548',
    highlights: ['Fushimi Inari 10,000 Torii Gates', 'Kinkaku-ji Golden Pavilion', 'Arashiyama Bamboo Forest', 'Gion Historic Streets', 'Gion Karyo Kaiseki']
  },
  {
    id: 'rome',
    name: 'Rome',
    state: 'Lazio',
    country: 'Italy',
    tagline: 'The Eternal City of Ancient Wonders, Renaissance Art & Trastevere Dining',
    description: 'An open-air museum filled with monumental landmarks like the Colosseum and Pantheon, majestic basilicas, bustling piazzas, world-renowned handmade pasta trattorias, and charming art-house theaters.',
    coverImage: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1200&q=80',
    coordinates: { lat: 41.9028, lng: 12.4964 },
    bestSeason: 'April to June & September to October',
    localCurrency: 'EUR (€)',
    currencySymbol: '€',
    language: 'Italian, English',
    timezone: 'CET (UTC+1:00)',
    emergencyContact: 'Universal Emergency: 112 / Tourist Info: +39-060608',
    highlights: ['Colosseum & Roman Forum', 'St. Peter\'s Basilica & Vatican', 'Pantheon Oculus', 'Trastevere Culinary Alley', 'Trevi Fountain']
  },
  {
    id: 'bangkok',
    name: 'Bangkok',
    state: 'Central Thailand',
    country: 'Thailand',
    tagline: 'Vibrant City of Angels with Golden Spires & World-Class Street Food',
    description: 'A dazzling juxtaposition of ornate riverside temples, buzzing street food stalls with Michelin honors, mega lifestyle cineplexes, and lively floating markets.',
    coverImage: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=1200&q=80',
    coordinates: { lat: 13.7563, lng: 100.5018 },
    bestSeason: 'November to February',
    localCurrency: 'THB (฿)',
    currencySymbol: '฿',
    language: 'Thai, English',
    timezone: 'ICT (UTC+7:00)',
    emergencyContact: 'Tourist Police: 1155',
    highlights: ['Wat Phra Kaew & Grand Palace', 'Wat Arun Temple of Dawn', 'Jay Fai Crab Omelette', 'Siam Paragon Cineplex', 'Chao Phraya River Cruise']
  },
  {
    id: 'mumbai',
    name: 'Mumbai',
    state: 'Maharashtra',
    country: 'India',
    tagline: 'The Maximum City of Bollywood, Seaside Promenades & Historic Shrines',
    description: 'India\'s glamorous metropolis boasting historic Art Deco cinema halls, revered pilgrimage shrines, iconic Irani cafes, coastal street delicacies, and Victorian colonial heritage.',
    coverImage: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=1200&q=80',
    coordinates: { lat: 18.9220, lng: 72.8347 },
    bestSeason: 'November to February',
    localCurrency: 'INR (₹)',
    currencySymbol: '₹',
    language: 'Marathi, Hindi, English',
    timezone: 'IST (UTC+5:30)',
    emergencyContact: 'Tourist Police: 100 / 112',
    highlights: ['Gateway of India', 'Siddhivinayak Ganpati Temple', 'Marine Drive Queens Necklace', 'PVR INOX Palladium IMAX', 'Colaba Causeway Irani Cafes']
  }
];

export const PLACES: Place[] = [
  // ================= VARANASI =================
  // 1. THEATRES
  {
    id: 'varanasi-theatre-1',
    cityId: 'varanasi',
    name: 'PVR IP Sigra Multiplex',
    category: 'theatre',
    tagline: 'Premier multiplex with 4K Laser projection & Dolby Atmos 7.1 sound',
    description: 'Located in IP Mall Sigra, this modern multiplex is the top cinema destination in Varanasi for tourists and locals alike, featuring plush recliner seating, gourmet popcorn bar, and latest Bollywood & Hollywood blockbusters.',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1595769816263-9b910be24d5f?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.6,
    reviewCount: 3420,
    address: '3rd Floor, IP Mall, Vidyapeeth Road, Sigra, Varanasi, UP 221002',
    coordinates: { lat: 25.3172, lng: 82.9868 },
    timings: {
      open: '09:00 AM',
      close: '11:45 PM',
      days: 'Open All 7 Days',
      currentStatus: 'Open Now',
      specialNote: 'Late night shows end after midnight; mall parking available.'
    },
    ticket: {
      isFree: false,
      generalPrice: 180,
      vipPrice: 420,
      currency: '₹',
      ticketNotes: 'Standard Silver: ₹180, Gold Prime: ₹260, VIP Recliner: ₹420. Online booking discount available.',
      bookingAvailable: true
    },
    facilities: ['Dolby Atmos Audio', 'Plush Recliner Seats', 'Wheelchair Ramp', 'Gourmet Food Court', 'Covered Basement Parking'],
    movies: [
      {
        id: 'mov-1',
        title: 'Avatar: Fire and Ash',
        poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
        language: 'English (with Subtitles) / Hindi Dub',
        format: '3D 4K Laser',
        duration: '3h 12m',
        genre: ['Sci-Fi', 'Adventure', 'Action'],
        rating: 8.9,
        certification: 'UA',
        synopsis: 'Jake Sully and Neytiri journey across Pandora encountering the volcanic Ash People clan in a breathtaking cinematic saga.',
        showtimes: [
          { time: '10:15 AM', price: 220, currency: '₹', seatAvailability: 'Available', screenType: 'Screen 1 (4K 3D)' },
          { time: '02:00 PM', price: 260, currency: '₹', seatAvailability: 'Filling Fast', screenType: 'Screen 1 (4K 3D)' },
          { time: '06:30 PM', price: 320, currency: '₹', seatAvailability: 'Almost Full', screenType: 'Screen 1 (4K 3D)' },
          { time: '10:15 PM', price: 280, currency: '₹', seatAvailability: 'Available', screenType: 'Screen 1 (4K 3D)' }
        ]
      },
      {
        id: 'mov-2',
        title: 'Kalki 2898 AD (Part 2)',
        poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80',
        language: 'Hindi / Telugu',
        format: 'Dolby Atmos 2D',
        duration: '2h 55m',
        genre: ['Mythology', 'Sci-Fi', 'Action'],
        rating: 8.7,
        certification: 'UA',
        synopsis: 'A futuristic epic blending ancient Indian lore with post-apocalyptic cyberpunk landscapes.',
        showtimes: [
          { time: '11:00 AM', price: 190, currency: '₹', seatAvailability: 'Available', screenType: 'Screen 2' },
          { time: '03:45 PM', price: 240, currency: '₹', seatAvailability: 'Filling Fast', screenType: 'Screen 2' },
          { time: '08:00 PM', price: 300, currency: '₹', seatAvailability: 'Almost Full', screenType: 'Screen 2' }
        ]
      },
      {
        id: 'mov-3',
        title: 'The Varanasi Murders (Mystery)',
        poster: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80',
        language: 'Hindi (with English Subtitles)',
        format: 'Digital 2D',
        duration: '2h 10m',
        genre: ['Thriller', 'Crime', 'Drama'],
        rating: 8.3,
        certification: 'A',
        synopsis: 'A gripping detective mystery unfolding through the winding, atmospheric alleys and ghats of Kashi.',
        showtimes: [
          { time: '01:30 PM', price: 180, currency: '₹', seatAvailability: 'Available', screenType: 'Screen 3' },
          { time: '07:15 PM', price: 220, currency: '₹', seatAvailability: 'Filling Fast', screenType: 'Screen 3' }
        ]
      }
    ],
    reviews: [
      {
        id: 'rev-th-1',
        author: 'Aarav Sharma',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '3 days ago',
        comment: 'Super clean multiplex right near Sigra crossing. Audio quality in Screen 1 was crisp and recliner seats are very comfy after a long morning exploring ghats!',
        helpfulCount: 28,
        crowdExperience: 'Moderate Queue'
      },
      {
        id: 'rev-th-2',
        author: 'Elena Rostova',
        authorType: 'Foreign Tourist',
        rating: 4,
        date: '1 week ago',
        comment: 'Great air-conditioned oasis from the Varanasi heat. We watched Avatar in English with subtitles; popcorn combo was delicious.',
        helpfulCount: 19,
        crowdExperience: 'Comfortable'
      }
    ]
  },
  {
    id: 'varanasi-theatre-2',
    cityId: 'varanasi',
    name: 'JHV Cinemas Cantt',
    category: 'theatre',
    tagline: 'Spacious upscale cinema complex in Varanasi Cantonment',
    description: 'Located in the green, relaxed Cantonment area, JHV Cinemas offers high-tier visual projection, quiet environment away from old town rush, and wide variety of regional and international titles.',
    image: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80'],
    rating: 4.4,
    reviewCount: 2180,
    address: 'The Mall, Cantonment, Varanasi, Uttar Pradesh 221002',
    coordinates: { lat: 25.3351, lng: 82.9812 },
    timings: {
      open: '09:30 AM',
      close: '11:30 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 160,
      vipPrice: 350,
      currency: '₹',
      ticketNotes: 'Executive: ₹160, Club: ₹220, VIP Gold: ₹350',
      bookingAvailable: true
    },
    facilities: ['AC Cinema', 'Valet Parking', 'Barista Coffee Counter', 'Clean Restrooms'],
    movies: [
      {
        id: 'mov-jhv-1',
        title: 'Oppenheimer (Special 70mm Encores)',
        poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80',
        language: 'English',
        format: 'Dolby Surround 2D',
        duration: '3h 00m',
        genre: ['Biography', 'History', 'Drama'],
        rating: 9.1,
        certification: 'A',
        synopsis: 'The story of J. Robert Oppenheimer and the Manhattan Project.',
        showtimes: [
          { time: '12:30 PM', price: 200, currency: '₹', seatAvailability: 'Available', screenType: 'Auditorium 1' },
          { time: '06:00 PM', price: 250, currency: '₹', seatAvailability: 'Filling Fast', screenType: 'Auditorium 1' }
        ]
      }
    ],
    reviews: [
      {
        id: 'rev-jhv-1',
        author: 'Rohan Mehra',
        authorType: 'Local Guide',
        rating: 5,
        date: '2 weeks ago',
        comment: 'Much calmer than Sigra if you have a cab or auto. Good snack options and sound tuning is pleasant.',
        helpfulCount: 14
      }
    ]
  },

  // 2. TEMPLES
  {
    id: 'varanasi-temple-1',
    cityId: 'varanasi',
    name: 'Shree Kashi Vishwanath Jyotirlinga Temple',
    category: 'temple',
    tagline: 'One of the 12 sacred Jyotirlingas & Spiritual Core of Kashi Corridor',
    description: 'Revered for millennia as the eternal abode of Lord Shiva (Vishveshvara). The newly expanded grand Kashi Vishwanath Corridor directly connects the temple to the holy Ganges at Manikarnika and Lalita Ghats.',
    image: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewCount: 48900,
    address: 'Vishwanath Gali, Godowlia, Varanasi, Uttar Pradesh 221001',
    coordinates: { lat: 25.3109, lng: 83.0107 },
    templeDeity: 'Lord Shiva (Kashi Vishwanath / Vishveshvara Jyotirlinga)',
    dressCode: 'Traditional Indian attire recommended (Dhoti/Kurta for men during Sparsh Darshan; Saree/Salwar for women). Leather items, belts, and mobile phones strictly deposited at locker counters before entry.',
    timings: {
      open: '03:00 AM',
      close: '11:00 PM',
      days: 'Open Daily (365 Days)',
      afternoonBreak: 'Bhog Aarti (11:15 AM - 12:20 PM: Darshan resumes immediately after)',
      currentStatus: 'Open Now',
      specialNote: 'Mangla Aarti starts at 3:00 AM. Temple remains open throughout the day with 5 daily Aarti breaks.'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE (General Queue)',
      vipPrice: 300,
      currency: '₹',
      ticketNotes: 'General Entry: FREE. Sugam Darshan (VIP Fast-Track Pass): ₹300 per person. Mangla Aarti Morning Pass: ₹500 (Must book online in advance). Saptarishi Aarti Pass: ₹300.',
      bookingAvailable: true
    },
    crowd: {
      peakHours: [
        '03:00 AM - 05:00 AM (Mangla Aarti - Extreme Rush)',
        '08:30 AM - 11:30 AM (Morning Devotee Peak)',
        '06:30 PM - 08:30 PM (Evening Sandhya & Shringar Aarti)'
      ],
      leastCrowdHours: '12:30 PM - 03:30 PM (Post-lunch midday window) & 09:30 PM - 10:30 PM (Night Darshan before Shayan Aarti)',
      peakDays: ['Mondays (Somwar - Extreme Rush up to 200,000 devotees)', 'Maha Shivratri', 'Dev Deepawali', 'Shravan Month (July-August)'],
      liveCrowdLevel: 'High',
      hourlyCrowdIndex: [
        10, 15, 40, 95, 80, 60, 50, 70, 85, 90, 85, 60, 35, 25, 30, 45, 65, 80, 90, 85, 70, 40, 20, 10
      ],
      avgWaitTimeMinutes: {
        peak: 120,
        normal: 45,
        vip: 15
      },
      tipsToAvoidCrowd: [
        'Visit between 1:00 PM and 3:30 PM on Tuesday, Wednesday, or Thursday for minimal queues (under 25 mins).',
        'Book "Sugam Darshan" ticket online via the official Temple Trust portal if traveling with elderly or kids.',
        'Deposit mobile phones, cameras, and leather belts at the official free/paid lockers near Gate 4 (Ghat Entrance) or Godowlia gate.',
        'Avoid visiting on Mondays if you want a relaxed darshan without long serpentine queues.'
      ],
      specialRituals: [
        { name: 'Mangla Aarti (Pre-dawn awakening)', time: '03:00 AM - 04:00 AM', crowdImpact: 'High', description: 'Most sacred morning ritual. Advance booking required.' },
        { name: 'Bhog / Midday Aarti', time: '11:15 AM - 12:20 PM', crowdImpact: 'Medium', description: 'Prasad offering to Lord Shiva.' },
        { name: 'Sandhya Aarti (Twilight evening ritual)', time: '07:00 PM - 08:15 PM', crowdImpact: 'High', description: 'Vibrant Vedic chants, dholak, and damru beats.' },
        { name: 'Shayan Aarti (Night resting ritual)', time: '10:30 PM - 11:00 PM', crowdImpact: 'Low', description: 'Peaceful closing ritual of the day.' }
      ]
    },
    facilities: ['Free/Paid Lockers', 'Wheelchair Assist via Corridor', 'Prasad Counters', 'Drinking Water RO', 'Security Scanning Gate 1-4'],
    reviews: [
      {
        id: 'rev-kv-1',
        author: 'Dr. Ramesh Kulkarni',
        authorType: 'Family Traveler',
        rating: 5,
        date: 'Yesterday',
        comment: 'The new Corridor has completely transformed Kashi Vishwanath. We took the Sugam Darshan ticket (₹300) for my elderly parents and completed darshan in just 18 minutes. The spiritual energy is incomparable.',
        visitedTime: '01:30 PM (Afternoon)',
        crowdExperience: 'Comfortable',
        helpfulCount: 74
      },
      {
        id: 'rev-kv-2',
        author: 'Priya Narayanan',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '5 days ago',
        comment: 'PRO-TIP: Do NOT go on Monday mornings unless you are prepared for a 3-hour wait. I went on Wednesday at 2:00 PM and walked straight into the sanctum in 25 mins without any VIP pass!',
        visitedTime: '02:00 PM (Mid-day)',
        crowdExperience: 'Quiet & Peaceful',
        helpfulCount: 112
      }
    ]
  },
  {
    id: 'varanasi-temple-2',
    cityId: 'varanasi',
    name: 'Sankat Mochan Hanuman Temple',
    category: 'temple',
    tagline: 'Historic temple founded by Saint Goswami Tulsidas',
    description: 'One of the most revered Hanuman temples in India, believed to be the spot where Tulsidas had a vision of Lord Hanuman while writing the Ramcharitmanas. Known for its sacred besan laddoos and peaceful courtyard.',
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 22100,
    address: 'Sankat Mochan Rd, Saket Nagar Colony, Durgakund, Varanasi, UP 221005',
    coordinates: { lat: 25.2818, lng: 82.9997 },
    templeDeity: 'Lord Hanuman (Sankat Mochan - Remover of Troubles)',
    dressCode: 'Decent modest clothing. Footwear to be kept at shoe counter near entrance gate.',
    timings: {
      open: '05:00 AM',
      close: '10:00 PM',
      days: 'Open All Days',
      afternoonBreak: '12:00 PM - 03:00 PM (Sanctum curtains closed)',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE',
      currency: '₹',
      ticketNotes: 'Entry is completely free for all devotees. Pure ghee Besan Laddoos available at ₹400/kg or ₹50/box.',
      bookingAvailable: false
    },
    crowd: {
      peakHours: [
        '06:00 AM - 09:00 AM (Tuesday & Saturday Morning)',
        '06:30 PM - 09:30 PM (Tuesday & Saturday Evening Aarti & Sindoor Darshan)'
      ],
      leastCrowdHours: '07:00 AM - 11:30 AM on Wednesdays, Thursdays, and Fridays',
      peakDays: ['Tuesdays (Mangalwar)', 'Saturdays (Shanivar)', 'Hanuman Jayanti'],
      liveCrowdLevel: 'Moderate',
      hourlyCrowdIndex: [
        0, 0, 0, 0, 10, 40, 75, 80, 70, 50, 40, 20, 0, 0, 0, 30, 50, 70, 85, 90, 75, 40, 10, 0
      ],
      avgWaitTimeMinutes: {
        peak: 60,
        normal: 15
      },
      tipsToAvoidCrowd: [
        'Tuesdays and Saturdays draw 5x higher crowds due to auspicious day for Hanuman devotees. Visit on Wednesday or Thursday morning for peaceful darshan.',
        'Beware of playful monkeys around the outer garden — keep prasad bags inside your pockets or carry a cloth bag.'
      ],
      specialRituals: [
        { name: 'Morning Aarti', time: '05:00 AM', crowdImpact: 'Medium' },
        { name: 'Evening Sandhya Aarti & Ramayana Chanting', time: '07:30 PM', crowdImpact: 'High' }
      ]
    },
    facilities: ['Free Shoe Counter', 'Pure Ghee Prasad Counter', 'Garden Courtyard', 'Drinking Water'],
    reviews: [
      {
        id: 'rev-sm-1',
        author: 'Vikas Pandey',
        authorType: 'Local Guide',
        rating: 5,
        date: '4 days ago',
        comment: 'The spiritual vibe here is pure bliss. Make sure to buy the authentic Lal Peda / Besan Laddoo prasad from the temple trust counter inside.',
        helpfulCount: 38
      }
    ]
  },
  {
    id: 'varanasi-temple-3',
    cityId: 'varanasi',
    name: 'Kaal Bhairav Temple (Kotwal of Kashi)',
    category: 'temple',
    tagline: 'Guardian deity of Varanasi whose permission is sought by pilgrims',
    description: 'Dedicated to Kaal Bhairav, the fierce guardian manifestation of Shiva appointed as the celestial "Kotwal" (Chief of Police) of Kashi. It is traditional for every tourist and pilgrim to seek his protection.',
    image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1627894483216-2138af692e32?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 14500,
    address: 'Near Town Hall, Maidagin, Golghar, Varanasi, Uttar Pradesh 221001',
    coordinates: { lat: 25.3198, lng: 83.0135 },
    templeDeity: 'Lord Kaal Bhairav (Shiva)',
    dressCode: 'Modest casual or traditional attire.',
    timings: {
      open: '05:00 AM',
      close: '01:30 PM and 04:30 PM - 10:00 PM',
      days: 'Open Daily',
      afternoonBreak: '01:30 PM - 04:30 PM',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE',
      currency: '₹',
      ticketNotes: 'Entry is free. Black sacred thread (Ganda) tied by priests for blessings: ₹10 - ₹20 voluntary.',
      bookingAvailable: false
    },
    crowd: {
      peakHours: ['06:30 AM - 09:00 AM (Sunday & Tuesday)', '07:00 PM - 09:00 PM'],
      leastCrowdHours: '10:30 AM - 01:00 PM on weekdays',
      peakDays: ['Sundays', 'Tuesdays', 'Bhairav Ashtami'],
      liveCrowdLevel: 'Moderate',
      hourlyCrowdIndex: [
        0, 0, 0, 0, 10, 45, 70, 75, 60, 40, 30, 25, 20, 0, 0, 0, 25, 55, 75, 80, 60, 30, 10, 0
      ],
      tipsToAvoidCrowd: [
        'Visit around 11:00 AM on a weekday for almost zero wait time.',
        'Park your vehicle near Town Hall Maidagin and take a short 4-minute walk through the heritage lane.'
      ]
    },
    facilities: ['Shoe Counter', 'Sacred Thread Counter', 'Prasad Stalls'],
    reviews: [
      {
        id: 'rev-kb-1',
        author: 'Sunil Rao',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '1 week ago',
        comment: 'Fascinating temple with incredible ancient vibes. The priest tied the black protective thread. Don\'t miss visiting after Kashi Vishwanath.',
        helpfulCount: 22
      }
    ]
  },

  // 3. RESTAURANTS
  {
    id: 'varanasi-rest-1',
    cityId: 'varanasi',
    name: 'Kashi Chaat Bhandar',
    category: 'restaurant',
    tagline: 'Legendary 60-year-old culinary institution famous for Tamatar Chaat',
    description: 'Ranked amongst India\'s most celebrated street food landmarks. Located at Godowlia Chowk, it is universally acclaimed for its piping hot, butter-infused Tamatar (Tomato) Chaat served in earthen kulhad cups.',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.8,
    reviewCount: 19800,
    address: 'D.37/49, Godowlia Chowk, Luxa Rd, Varanasi, Uttar Pradesh 221001',
    coordinates: { lat: 25.3089, lng: 83.0068 },
    cuisine: ['Banarasi Street Food', 'North Indian Chaat', 'Pure Vegetarian'],
    priceCategory: '$',
    timings: {
      open: '02:00 PM',
      close: '11:00 PM',
      days: 'Open All Days',
      currentStatus: 'Open Now',
      specialNote: 'Best enjoyed fresh in the evening between 4 PM and 9 PM.'
    },
    ticket: {
      isFree: true,
      generalPrice: 'Average Cost: ₹100 - ₹200 for two',
      currency: '₹',
      ticketNotes: 'No entry fee; pay per item ordered at the counter.',
      bookingAvailable: false
    },
    topDishes: [
      {
        name: 'Special Banarasi Tamatar Chaat (Kulhad)',
        isVeg: true,
        price: '₹60',
        rating: 4.9,
        reviewCount: 8400,
        badge: 'Most Rated',
        description: 'Mashed spicy tomatoes cooked in desi ghee with cashews, hing, ginger, cumin, and sweetened sugar syrup topped with crispy namkeen.'
      },
      {
        name: 'Palak Patta (Spinach Leaf) Chaat',
        isVeg: true,
        price: '₹60',
        rating: 4.8,
        reviewCount: 4200,
        badge: 'Signature Dish',
        description: 'Super-crispy fried spinach leaves smothered in chilled spiced yogurt, sweet tamarind chutney, mint salsa, and pomegranate jewels.'
      },
      {
        name: 'Dahi Gujiya / Bhalla Chaat',
        isVeg: true,
        price: '₹50',
        rating: 4.7,
        reviewCount: 3100,
        badge: 'Must Try',
        description: 'Melt-in-mouth soft lentil dumplings stuffed with dry fruits, soaked in thick churned curd and roasted spices.'
      },
      {
        name: 'Gulab Jamun (Hot in Desi Ghee)',
        isVeg: true,
        price: '₹40 (2 pcs)',
        rating: 4.8,
        reviewCount: 2900,
        badge: 'Local Favorite',
        description: 'Freshly fried piping-hot khoya gulab jamuns dripping with saffron cardamom syrup.'
      }
    ],
    facilities: ['Standing & Quick Seating', 'UPI & Cash Accepted', 'Takeaway Packing', 'Pure Ghee Preparation'],
    reviews: [
      {
        id: 'rev-kc-1',
        author: 'Ananya Deshmukh',
        authorType: 'Foodie Explorer',
        rating: 5,
        date: '2 days ago',
        comment: 'The Tamatar Chaat here is life-changing! The balance of tangy tomato, rich desi ghee, and crunchy namkeen in an earthen pot is unbelievable. Expect a 10-minute wait in the evening, but totally worth it!',
        recommendedItem: 'Special Banarasi Tamatar Chaat',
        helpfulCount: 52
      },
      {
        id: 'rev-kc-2',
        author: 'David Miller',
        authorType: 'Foreign Tourist',
        rating: 5,
        date: '1 week ago',
        comment: 'Safe, clean, and bursting with flavors. The Palak Patta Chaat with sweet yogurt was our favorite food in India!',
        recommendedItem: 'Palak Patta Chaat',
        helpfulCount: 39
      }
    ]
  },
  {
    id: 'varanasi-rest-2',
    cityId: 'varanasi',
    name: 'Blue Lassi Shop',
    category: 'restaurant',
    tagline: 'Iconic heritage lassi bar with 80+ fruit & rabri toppings since 1925',
    description: 'Tucked inside the narrow heritage lanes near Manikarnika Ghat, this world-famous tiny shop serves hand-churned thick curd lassi topped with fresh seasonal fruits, pistachio, malai, and thick rabri in hand-thrown terracotta cups.',
    image: 'https://images.unsplash.com/photo-1571006687898-09e8697193b2?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 8900,
    address: 'CK 12/1, Kunj Gali, Near Manikarnika Ghat, Bangali Tola, Varanasi, UP 221001',
    coordinates: { lat: 25.3115, lng: 83.0139 },
    cuisine: ['Artisanal Lassi', 'Desserts', 'Beverages', 'Pure Veg'],
    priceCategory: '$',
    timings: {
      open: '08:00 AM',
      close: '10:00 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: '₹80 - ₹160 per Lassi',
      currency: '₹',
      ticketNotes: 'No entry fee; order directly from the wooden window.',
      bookingAvailable: false
    },
    topDishes: [
      {
        name: 'Special Malai Rabri Pomegranate & Pistachio Lassi',
        isVeg: true,
        price: '₹120',
        rating: 4.9,
        reviewCount: 3900,
        badge: 'Most Rated',
        description: 'Thick hand-beaten yogurt crowned with clotted cream (malai), homemade rabri, fresh ruby pomegranate arils, and sliced Iranian pistachios.'
      },
      {
        name: 'Banana Coconut Mango Fusion Lassi',
        isVeg: true,
        price: '₹140',
        rating: 4.8,
        reviewCount: 2100,
        badge: 'Signature Dish',
        description: 'Exotic tropical mix of fresh alphanso pulp, banana chunks, and freshly grated tender coconut.'
      }
    ],
    facilities: ['Cozy Alley Bench Seating', 'Passports & Wall Photo Memories', 'Hand-churned Daily'],
    reviews: [
      {
        id: 'rev-bl-1',
        author: 'Marc & Sophie',
        authorType: 'Foreign Tourist',
        rating: 5,
        date: '3 days ago',
        comment: 'So thick you eat it with a wooden spoon! The rabri and fresh pomegranate combo is sublime. The walls covered in traveler passport photos from 50+ countries make it iconic.',
        recommendedItem: 'Special Malai Rabri Lassi',
        helpfulCount: 44
      }
    ]
  },
  {
    id: 'varanasi-rest-3',
    cityId: 'varanasi',
    name: 'Baati Chokha Restaurant',
    category: 'restaurant',
    tagline: 'Authentic rustic Bhojpuri dining in a village-themed mud haveli',
    description: 'Experience genuine Purvanchal & Bihari heritage cuisine with charcoal-roasted sattu baatis, smoky brinjal chokha cooked over cow-dung cake embers, desi ghee, and kheer served on sal leaf plates.',
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewCount: 7800,
    address: 'Near Anand Mandir Cinema, Teliyabag, Varanasi, Uttar Pradesh 221002',
    coordinates: { lat: 25.3284, lng: 82.9961 },
    cuisine: ['Traditional Bhojpuri', 'North Indian', 'Sattu Cuisine', 'Pure Veg'],
    priceCategory: '$$',
    timings: {
      open: '11:30 AM',
      close: '11:00 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: '₹400 for two',
      currency: '₹',
      ticketNotes: 'Thali system & a-la-carte available.',
      bookingAvailable: true
    },
    topDishes: [
      {
        name: 'Special Royal Baati Chokha Thali (Desi Ghee)',
        isVeg: true,
        price: '₹220',
        rating: 4.8,
        reviewCount: 3200,
        badge: 'Most Rated',
        description: '2 Ghee-dipped charcoal roasted Sattu Baatis, Baingan Chokha, Aloo Chokha, Yellow Dal Tadka, Kheer, Tomato Chutney, and Onion Salad.'
      },
      {
        name: 'Paneer Stuffed Charcoal Baati',
        isVeg: true,
        price: '₹140',
        rating: 4.7,
        reviewCount: 1500,
        badge: 'Chef Special',
        description: 'Smoky wheat crust loaded with spiced paneer, roasted over slow charcoal embers.'
      }
    ],
    facilities: ['AC Traditional Seating', 'Charcoal Live Counter', 'Handwash Area', 'Family Friendly'],
    reviews: [
      {
        id: 'rev-bc-1',
        author: 'Amitabh Verma',
        authorType: 'Local Guide',
        rating: 5,
        date: '2 weeks ago',
        comment: 'Real authentic rustic taste! The aroma of charcoal-roasted baati dipped in hot ghee is unbeatable. Highly recommended for tourists wanting authentic local cuisine.',
        recommendedItem: 'Royal Baati Chokha Thali',
        helpfulCount: 31
      }
    ]
  },

  // 4. TOURIST PLACES / ATTRACTIONS
  {
    id: 'varanasi-attraction-1',
    cityId: 'varanasi',
    name: 'Dashashwamedh Ghat & Grand Ganga Aarti',
    category: 'attraction',
    tagline: 'The most spectacular riverfront amphitheater & twilight Aarti spectacle',
    description: 'The main and oldest ghat on the Ganges in Varanasi, Dashashwamedh Ghat hosts the world-famous Grand Maha Aarti every evening at sunset, conducted by saffron-robed priests wielding tiered multi-wick brass lamps accompanied by conch shells and incense.',
    image: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1627894483216-2138af692e32?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewCount: 52000,
    address: 'Dashashwamedh Ghat Rd, Bangali Tola, Varanasi, Uttar Pradesh 221001',
    coordinates: { lat: 25.3075, lng: 83.0104 },
    timings: {
      open: '24 Hours Open',
      close: '24 Hours Open',
      days: 'Open Daily',
      currentStatus: 'Open Now',
      specialNote: 'Ganga Aarti Ceremony starts precisely at 6:45 PM (Summer) / 6:00 PM (Winter) and lasts 45 minutes.'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE (Watching from Ghat Steps)',
      vipPrice: 200,
      currency: '₹',
      ticketNotes: 'Ghat step seating is 100% FREE. Shared boat seating facing the Aarti: ₹150 - ₹300 per seat. Private wooden boat: ₹1,500 - ₹3,000 for 4-8 persons (negotiable at ghat).',
      bookingAvailable: true
    },
    crowd: {
      peakHours: ['05:30 PM - 07:45 PM (Evening Aarti peak crowd)'],
      leastCrowdHours: '06:00 AM - 08:30 AM (Peaceful sunrise boat rides)',
      peakDays: ['Dev Deepawali (Millions gather)', 'Maha Shivratri', 'Kartik Purnima', 'Saturday & Sunday evenings'],
      liveCrowdLevel: 'Extremely Busy',
      hourlyCrowdIndex: [
        10, 5, 5, 20, 45, 60, 50, 40, 30, 25, 20, 20, 20, 25, 30, 40, 60, 90, 100, 95, 60, 35, 20, 15
      ],
      tipsToAvoidCrowd: [
        'Arrive by 5:30 PM to grab front-row concrete steps, or hire a wooden rowing boat 45 mins before sunset for an unobstructed river view.',
        'Beware of touts claiming private fees for free ghat stairs.'
      ]
    },
    facilities: ['Boat Hire Jetty', 'Photography Points', 'Flower Diya Floating Stalls', 'Tourist Police Booth'],
    reviews: [
      {
        id: 'rev-dg-1',
        author: 'Liam & Olivia',
        authorType: 'Foreign Tourist',
        rating: 5,
        date: 'Yesterday',
        comment: 'Witnessing the Ganga Aarti from a boat while floating marigold diyas on the water is one of the most hypnotic experiences on earth. Chills when the conch shells blew in unison!',
        helpfulCount: 92
      }
    ]
  },
  {
    id: 'varanasi-attraction-2',
    cityId: 'varanasi',
    name: 'Sarnath Archaeological Site & Dhamek Stupa',
    category: 'attraction',
    tagline: 'Cradle of Buddhism where Buddha delivered his First Sermon',
    description: 'Located 10 km from Varanasi, Sarnath is one of the four key Buddhist pilgrimage circuits where Lord Buddha set in motion the Wheel of Law (Dharmachakra). Features the towering 43-meter Dhamek Stupa, Ashoka Pillar ruins, and Archaeological Museum housing the original Lion Capital of India.',
    image: 'https://images.unsplash.com/photo-1599831104321-c4238e8ec436?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 16700,
    address: 'Rishpattan Road, Sarnath, Varanasi, Uttar Pradesh 221007',
    coordinates: { lat: 25.3811, lng: 83.0232 },
    timings: {
      open: '08:00 AM',
      close: '06:00 PM (Sunset)',
      days: 'Open Daily (Museum closed on Fridays)',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 25,
      foreignTouristPrice: 300,
      childPrice: 0,
      currency: '₹',
      ticketNotes: 'Indian Citizens: ₹25 (Cashless/UPI: ₹20). Foreign Nationals: ₹300. Children below 15 years: FREE. Sarnath Archaeological Museum ticket: ₹5 extra (Closed on Fridays).',
      bookingAvailable: true
    },
    facilities: ['Wheelchair Pathways', 'Licensed Audio Guide / QR Tour', 'Manicured Lawns', 'Archaeological Museum', 'Cafeteria'],
    reviews: [
      {
        id: 'rev-sn-1',
        author: 'Kenji Takahashi',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '1 week ago',
        comment: 'So serene and peaceful compared to the bustling city center. The Ashokan Lion Capital in the museum is jaw-dropping.',
        helpfulCount: 45
      }
    ]
  },

  // ================= KYOTO =================
  // 1. THEATRES
  {
    id: 'kyoto-theatre-1',
    cityId: 'kyoto',
    name: 'MOVIX Kyoto (Shin-Kyogoku)',
    category: 'theatre',
    tagline: 'Kyoto’s premier multiplex in the historic downtown covered arcade',
    description: 'State-of-the-art cinema complex boasting 12 screens with Dolby Atmos and Laser projection, showing Japanese anime blockbusters, foreign films with original English audio, and international releases.',
    image: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewCount: 3120,
    address: 'Higashigawa-cho, Rokkaku-sagaru, Shin-Kyogoku-dori, Nakagyo-ku, Kyoto 604-8035',
    coordinates: { lat: 35.0069, lng: 135.7678 },
    timings: {
      open: '08:30 AM',
      close: '11:45 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 2000,
      childPrice: 1000,
      seniorPrice: 1300,
      currency: '¥',
      ticketNotes: 'Adults: ¥2,000. University Students: ¥1,500. High School/Kids: ¥1,000. Seniors (60+): ¥1,300. Wednesday Cinema Day: ¥1,300 for all.',
      bookingAvailable: true
    },
    facilities: ['Dolby Atmos', 'Automated Multi-language Kiosks', 'Matcha Popcorn & Sapporo Beer', 'Luxury Seating'],
    movies: [
      {
        id: 'mov-kyo-1',
        title: 'Studio Ghibli: The Boy and the Heron (Special Cut)',
        poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80',
        language: 'Japanese (with English Subtitles)',
        format: '4K Laser Digital',
        duration: '2h 04m',
        genre: ['Animation', 'Fantasy', 'Adventure'],
        rating: 9.2,
        certification: 'PG',
        synopsis: 'Hayao Miyazaki\'s Oscar-winning masterpiece exploring grief, mystical worlds, and family bonding.',
        showtimes: [
          { time: '10:30 AM', price: 2000, currency: '¥', seatAvailability: 'Available', screenType: 'Screen 2' },
          { time: '02:15 PM', price: 2000, currency: '¥', seatAvailability: 'Filling Fast', screenType: 'Screen 2' },
          { time: '06:45 PM', price: 2000, currency: '¥', seatAvailability: 'Almost Full', screenType: 'Screen 2' }
        ]
      },
      {
        id: 'mov-kyo-2',
        title: 'Dune: Part Two (IMAX Experience)',
        poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
        language: 'English with Japanese Subtitles',
        format: 'IMAX Laser 2D',
        duration: '2h 46m',
        genre: ['Sci-Fi', 'Adventure'],
        rating: 9.0,
        certification: 'PG-13',
        synopsis: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators.',
        showtimes: [
          { time: '11:45 AM', price: 2500, currency: '¥', seatAvailability: 'Available', screenType: 'IMAX Theatre' },
          { time: '04:00 PM', price: 2500, currency: '¥', seatAvailability: 'Filling Fast', screenType: 'IMAX Theatre' },
          { time: '08:15 PM', price: 2500, currency: '¥', seatAvailability: 'Almost Full', screenType: 'IMAX Theatre' }
        ]
      }
    ],
    reviews: [
      {
        id: 'rev-mv-1',
        author: 'Chloe Bennett',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '4 days ago',
        comment: 'Easy touchscreens in English, super comfy clean seats, and getting warm caramel matcha popcorn made for a wonderful rainy evening.',
        helpfulCount: 26
      }
    ]
  },

  // 2. TEMPLES & SHRINES
  {
    id: 'kyoto-temple-1',
    cityId: 'kyoto',
    name: 'Fushimi Inari-Taisha (10,000 Torii Gates)',
    category: 'temple',
    tagline: 'Iconic Shinto mountain shrine with thousand vermilion torii tunnels',
    description: 'The head shrine of the kami Inari (deity of agriculture, business, and foxes). Renowned worldwide for its mesmerizing path of over 10,000 vermilion torii gates winding up the sacred Mount Inari forest.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1528164344705-475426879c0d?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewCount: 68500,
    address: '68 Fukakusa Yabunouchicho, Fushimi-ku, Kyoto 612-0882, Japan',
    coordinates: { lat: 34.9671, lng: 135.7727 },
    templeDeity: 'Inari Okami (Shinto Kami of Prosperity, Agriculture & Foxes)',
    dressCode: 'Respectful casual wear. Comfortable walking/hiking shoes required for the 4 km mountain trail.',
    timings: {
      open: '24 Hours (Open Day & Night)',
      close: '24 Hours (Always Accessible)',
      days: 'Open 365 Days',
      currentStatus: 'Open Now',
      specialNote: 'Torii paths are illuminated with lanterns until nightfall. Amulet and omikuji counters open 08:30 AM - 04:30 PM.'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE (No Admission Fee)',
      currency: '¥',
      ticketNotes: 'Entrance to the shrine grounds and entire mountain torii trail is 100% FREE.',
      bookingAvailable: false
    },
    crowd: {
      peakHours: [
        '09:30 AM - 04:30 PM (Mass tourist coaches & crowded selfie spots)'
      ],
      leastCrowdHours: '06:00 AM - 08:00 AM (Serene sunrise, almost empty torii tunnels) & 07:30 PM - 09:30 PM (Atmospheric lantern night hike)',
      peakDays: ['Weekends', 'New Year Hatsumode (Jan 1-3)', 'Cherry Blossom Season (April)', 'Autumn Foliage (Nov)'],
      liveCrowdLevel: 'High',
      hourlyCrowdIndex: [
        5, 5, 5, 10, 15, 30, 45, 60, 80, 95, 100, 95, 90, 85, 85, 75, 60, 45, 30, 20, 15, 10, 5, 5
      ],
      avgWaitTimeMinutes: {
        peak: 0,
        normal: 0
      },
      tipsToAvoidCrowd: [
        'Arrive before 07:30 AM to take world-class photos of the Senbon Torii without any other tourists in your frame.',
        'Hike past the halfway point (Yotsutsuji intersection); 85% of tourists turn back, leaving the upper mountain paths quiet and mystical.',
        'Take the JR Nara line from Kyoto Station (2 stops, 5 mins directly to JR Inari Station).'
      ],
      specialRituals: [
        { name: 'Morning Shinto Chanting & Purification', time: '08:30 AM', crowdImpact: 'Medium' },
        { name: 'Kitsune Mask Dedication', time: 'All Day', crowdImpact: 'Low' }
      ]
    },
    facilities: ['JR Train Station 1 min away', 'Rest Areas with Mountain Vistas', 'Fox Ema Charm Counters', 'Vending Machines on Trail'],
    reviews: [
      {
        id: 'rev-fi-1',
        author: 'Marcus Vance',
        authorType: 'Solo Traveler',
        rating: 5,
        date: 'Yesterday',
        comment: 'Woke up at 6:00 AM and had the red gates all to myself. By 10 AM it was shoulder-to-shoulder. Early morning is an unforgettable spiritual experience.',
        visitedTime: '06:30 AM (Sunrise)',
        crowdExperience: 'Quiet & Peaceful',
        helpfulCount: 88
      }
    ]
  },
  {
    id: 'kyoto-temple-2',
    cityId: 'kyoto',
    name: 'Kinkaku-ji (The Golden Pavilion)',
    category: 'temple',
    tagline: 'Zen Buddhist temple covered in shimmering gold leaf over Mirror Pond',
    description: 'A designated UNESCO World Heritage landmark, Kinkaku-ji is a Zen Buddhist temple whose top two floors are completely covered in pure gold leaf, creating a breathtaking golden reflection on Kyoko-chi (Mirror Pond).',
    image: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 41200,
    address: '1 Kinkakujicho, Kita-ku, Kyoto 603-8361, Japan',
    coordinates: { lat: 35.0394, lng: 135.7292 },
    templeDeity: 'Rinzai Zen Buddhism (Shaka Buddha relics)',
    timings: {
      open: '09:00 AM',
      close: '05:00 PM',
      days: 'Open Daily (365 Days)',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 500,
      childPrice: 300,
      currency: '¥',
      ticketNotes: 'Adults (High school & above): ¥500. Elementary & Junior High: ¥300. The ticket itself is a calligraphy paper blessing talisman (Ofuda).',
      bookingAvailable: false
    },
    crowd: {
      peakHours: ['10:30 AM - 03:00 PM (Tour bus rush around the pond)'],
      leastCrowdHours: '09:00 AM sharp at opening & 04:15 PM before final entry',
      peakDays: ['Weekends', 'Autumn peak (mid-November)', 'Sunny days after fresh snowfall'],
      liveCrowdLevel: 'Moderate',
      hourlyCrowdIndex: [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 85, 95, 80, 90, 85, 70, 30, 0, 0, 0, 0, 0, 0, 0
      ],
      tipsToAvoidCrowd: [
        'Queue up at 8:45 AM before gates open at 9:00 AM to photograph the still Mirror Pond before ripples form.',
        'Combine with nearby Ryoan-ji rock garden via the Kinukake-no-Michi road.'
      ]
    },
    facilities: ['Talisman Ticket Souvenir', 'Green Tea & Gold Leaf Sweets Stall', 'Accessible Paved Loop', 'Gift Shop'],
    reviews: [
      {
        id: 'rev-kj-1',
        author: 'Eriko Sato',
        authorType: 'Family Traveler',
        rating: 5,
        date: '5 days ago',
        comment: 'Even more dazzling in person than in pictures! The paper entry ticket with protective calligraphy is a wonderful keepsake.',
        helpfulCount: 42
      }
    ]
  },

  // 3. RESTAURANTS
  {
    id: 'kyoto-rest-1',
    cityId: 'kyoto',
    name: 'Honke Owariya (550-Year-Old Soba House)',
    category: 'restaurant',
    tagline: 'Kyoto’s oldest soba restaurant serving the Imperial Household since 1465',
    description: 'Operating continuously for over five and a half centuries in a traditional wooden machiya, Honke Owariya is legendary for its handmade buckwheat soba made with pure Kyoto subterranean spring water.',
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 4920,
    address: '322 Niomontsukinukecho, Nakagyo-ku, Kyoto 604-0841',
    coordinates: { lat: 35.0132, lng: 135.7594 },
    cuisine: ['Authentic Handmade Soba', 'Japanese Imperial Tradition', 'Tempura', 'Vegetarian Options'],
    priceCategory: '$$',
    timings: {
      open: '11:00 AM',
      close: '03:30 PM (Lunch only)',
      days: 'Open Daily (Closed Jan 1-2)',
      currentStatus: 'Open Now',
      specialNote: 'Closes early when daily handmade soba batch runs out.'
    },
    ticket: {
      isFree: true,
      generalPrice: '¥1,400 - ¥2,800 per person',
      currency: '¥',
      ticketNotes: 'Order at the table. Cash, IC cards, and credit cards accepted.',
      bookingAvailable: false
    },
    topDishes: [
      {
        name: 'Hourai Soba (5-Tier Imperial Dish with 8 Condiments)',
        isVeg: false,
        price: '¥2,420',
        rating: 4.9,
        reviewCount: 2200,
        badge: 'Most Rated',
        description: 'Five layered lacquer bowls of cold buckwheat soba served with 8 custom toppings: shiitake mushrooms, grated daikon, wasabi, nori, shrimp tempura, sesame, thinly sliced omelette, and sweet soba broth.'
      },
      {
        name: 'Nishin Soba (Sweet Braised Herring with Warm Broth)',
        isVeg: false,
        price: '¥1,650',
        rating: 4.7,
        reviewCount: 1100,
        badge: 'Signature Dish',
        description: 'Classic Kyoto specialty featuring slow-braised sweet Pacific herring over piping hot dashi buckwheat noodles.'
      }
    ],
    facilities: ['Historic Tatami Rooms', 'English Menu Available', 'Traditional Garden View', 'Takeaway Soba Sweets'],
    reviews: [
      {
        id: 'rev-ho-1',
        author: 'Kenji & Sarah',
        authorType: 'Foodie Explorer',
        rating: 5,
        date: '3 days ago',
        comment: 'Dining in a 550-year-old building is surreal. The 5-tiered Hourai soba allows you to customize each bowl with different toppings. The broth is fragrant and delicate.',
        recommendedItem: 'Hourai Soba',
        helpfulCount: 37
      }
    ]
  },

  // 4. ATTRACTIONS
  {
    id: 'kyoto-attraction-1',
    cityId: 'kyoto',
    name: 'Arashiyama Bamboo Grove & Tenryu-ji',
    category: 'attraction',
    tagline: 'Swaying emerald green bamboo forest and world-heritage Zen temple garden',
    description: 'A magical natural sanctuary in western Kyoto where towering bamboo stalks create an otherworldly canopy and soothing wind chimes. Directly borders Tenryu-ji Temple with its 14th-century Zen landscape pond.',
    image: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 51200,
    address: 'Ukyo-ku, Kyoto 616-8385, Japan',
    coordinates: { lat: 35.0169, lng: 135.6713 },
    timings: {
      open: '24 Hours (Bamboo Grove)',
      close: 'Tenryu-ji: 08:30 AM - 05:00 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE (Bamboo Grove)',
      childPrice: 0,
      currency: '¥',
      ticketNotes: 'Walking through the Bamboo Grove path is completely FREE. Tenryu-ji Zen Garden entry: ¥500 (Optional).',
      bookingAvailable: false
    },
    crowd: {
      peakHours: ['10:00 AM - 03:30 PM (Rickshaws and high tourist volume)'],
      leastCrowdHours: '06:30 AM - 08:00 AM (Tranquil morning breeze without crowds)',
      peakDays: ['Weekends', 'Spring Sakura', 'Fall Foliage'],
      liveCrowdLevel: 'Moderate',
      hourlyCrowdIndex: [
        5, 5, 5, 5, 10, 25, 40, 60, 80, 95, 95, 90, 85, 85, 80, 65, 45, 30, 20, 10, 5, 5, 5, 5
      ],
      tipsToAvoidCrowd: [
        'Visit at sunrise to hear the rustling bamboo stalks designated as one of the "100 Soundscapes of Japan".',
        'Cross the Togetsukyo Bridge for riverside matcha soft-serve.'
      ]
    },
    facilities: ['Rickshaw Tours', 'Matcha Tea Stalls', 'Restrooms', 'Scenic Togetsukyo Bridge View'],
    reviews: [
      {
        id: 'rev-ar-1',
        author: 'Claire Dufresne',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '2 weeks ago',
        comment: 'Walking through the bamboo grove at 7 AM felt like stepping into an anime fairy tale. Truly magical.',
        helpfulCount: 56
      }
    ]
  },

  // ================= ROME =================
  // 1. THEATRES
  {
    id: 'rome-theatre-1',
    cityId: 'rome',
    name: 'Cinema Barberini',
    category: 'theatre',
    tagline: 'Historic cinema in Piazza Barberini showing original English movies',
    description: 'Renovated in high-tech luxury with 4K laser projection, Dolby Atmos sound, and motorized leather recliner seating. One of Rome\'s best places to watch current global Hollywood and Italian award-winning cinema in original language (VOSE).',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 1890,
    address: 'Piazza Barberini 24/26, 00187 Roma RM, Italy',
    coordinates: { lat: 41.9037, lng: 12.4889 },
    timings: {
      open: '02:00 PM',
      close: '11:45 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 9.5,
      vipPrice: 14,
      currency: '€',
      ticketNotes: 'Standard Ticket: €9.50. Luxury Recliner Sala 1: €14.00. Tuesday discount: €6.50.',
      bookingAvailable: true
    },
    facilities: ['Dolby Atmos', 'Luxury Recliner Seats', 'Metro Barberini direct access', 'Cocktail & Snack Bar'],
    movies: [
      {
        id: 'mov-rom-1',
        title: 'Gladiator II (Original English Version)',
        poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
        language: 'English (Italian Subtitles)',
        format: '4K Dolby Atmos',
        duration: '2h 28m',
        genre: ['Action', 'Epic', 'Drama'],
        rating: 8.6,
        certification: 'PG-13',
        synopsis: 'Years after witnessing the death of Maximus, Lucius must enter the Colosseum to restore Rome\'s glory.',
        showtimes: [
          { time: '04:30 PM', price: 9.5, currency: '€', seatAvailability: 'Available', screenType: 'Sala 1 (Atmos)' },
          { time: '07:45 PM', price: 12, currency: '€', seatAvailability: 'Filling Fast', screenType: 'Sala 1 (Atmos)' },
          { time: '10:30 PM', price: 9.5, currency: '€', seatAvailability: 'Available', screenType: 'Sala 1 (Atmos)' }
        ]
      }
    ],
    reviews: [
      {
        id: 'rev-cb-1',
        author: 'Federico Rossi',
        authorType: 'Local Guide',
        rating: 5,
        date: '1 week ago',
        comment: 'Right in the center near Trevi. Watching movies in English with comfortable leather seats and good AC after a hot day in Rome is fantastic.',
        helpfulCount: 21
      }
    ]
  },

  // 2. TEMPLES & CHURCHES
  {
    id: 'rome-temple-1',
    cityId: 'rome',
    name: 'Pantheon (Basilica of St. Mary and the Martyrs)',
    category: 'temple',
    tagline: 'World’s greatest preserved ancient Roman temple with open sky oculus',
    description: 'Built by Emperor Hadrian around 126 AD, this ancient Roman temple dedicated to all gods boasts the world\'s largest unreinforced concrete dome with a 9-meter open central oculus that lets in rain and natural sunlight.',
    image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 79000,
    address: 'Piazza della Rotonda, 00186 Roma RM, Italy',
    coordinates: { lat: 41.8986, lng: 12.4769 },
    templeDeity: 'Originally all Roman Gods; consecrated as Catholic Basilica in 609 AD',
    dressCode: 'Shoulders and knees must be covered (Strict basilica dress code enforced at security check).',
    timings: {
      open: '09:00 AM',
      close: '07:00 PM (Last entry at 06:45 PM)',
      days: 'Open Daily (Closed Jan 1, Dec 25)',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 5,
      childPrice: 0,
      currency: '€',
      ticketNotes: 'Standard Adult Entry: €5. European Citizens (18-25 yrs): €3. Under 18: FREE. Official Audio Guide: €5 extra. Sunday bookings strongly advised online.',
      bookingAvailable: true
    },
    crowd: {
      peakHours: ['10:30 AM - 03:00 PM (Long square queue outside Piazza della Rotonda)'],
      leastCrowdHours: '09:00 AM sharp at opening & 05:45 PM before closing',
      peakDays: ['Saturdays', 'Sundays (Mass timings)', 'Easter', 'Pentecost (Rose petal drop)'],
      liveCrowdLevel: 'High',
      hourlyCrowdIndex: [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 85, 95, 90, 85, 80, 75, 55, 30, 0, 0, 0, 0, 0, 0
      ],
      avgWaitTimeMinutes: {
        peak: 40,
        normal: 15
      },
      tipsToAvoidCrowd: [
        'Pre-book official €5 tickets online on the Italian Ministry of Culture portal to bypass the 40-minute ticket booth line.',
        'Stand directly under the oculus at solar noon (around 1:15 PM) to see a dramatic cylindrical beam of light illuminate the marble floor.'
      ]
    },
    facilities: ['Audio Guides in 8 languages', 'Tomb of Raphael & King Vittorio Emanuele II', 'Surrounding Gelaterias'],
    reviews: [
      {
        id: 'rev-pt-1',
        author: 'Matteo Bellini',
        authorType: 'Local Guide',
        rating: 5,
        date: '3 days ago',
        comment: 'Engineering marvel from 2,000 years ago. Standing beneath the open dome looking up at the sky is breathtaking. Book the €5 ticket online to skip the line.',
        helpfulCount: 65
      }
    ]
  },

  // 3. RESTAURANTS
  {
    id: 'rome-rest-1',
    cityId: 'rome',
    name: 'Osteria da Fortunata (Pellegrino)',
    category: 'restaurant',
    tagline: 'Famous Roman pasta house where nonnas roll fresh tagliolini in the window',
    description: 'Renowned world over for handmade pasta rolled by Italian grandmothers right in front of your eyes. Serves the golden holy trinity of Roman cuisine: Carbonara, Cacio e Pepe, and Amatriciana made with organic guanciale and aged Pecorino Romano.',
    image: 'https://images.unsplash.com/photo-1621996346565-e3d5d628169e?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 15800,
    address: 'Via del Pellegrino 11/12, 00186 Roma RM (Campo de\' Fiori)',
    coordinates: { lat: 41.8966, lng: 12.4719 },
    cuisine: ['Authentic Roman Pasta', 'Italian Trattoria', 'Fresh Handmade Pasta'],
    priceCategory: '$$',
    timings: {
      open: '12:00 PM',
      close: '11:30 PM (Continuous service without afternoon break)',
      days: 'Open Daily 7 Days',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: '€18 - €28 per person',
      currency: '€',
      ticketNotes: 'No reservation required; first-come, first-served queue.',
      bookingAvailable: false
    },
    topDishes: [
      {
        name: 'Handmade Tagliolini alla Carbonara',
        isVeg: false,
        price: '€18',
        rating: 4.9,
        reviewCount: 6200,
        badge: 'Most Rated',
        description: 'Fresh thick hand-rolled pasta ribbons tossed in farm egg yolks, crispy cured pork cheek (guanciale), freshly cracked Tellicherry black pepper, and aged Pecorino Romano.'
      },
      {
        name: 'Sciavatelli Cacio e Pepe',
        isVeg: true,
        price: '€17',
        rating: 4.8,
        reviewCount: 3800,
        badge: 'Signature Dish',
        description: 'Creamy, silky emulsified sauce of aged Roman sheep cheese and toasted black pepper over al dente handmade pasta.'
      }
    ],
    facilities: ['Live Nonna Pasta Making Window', 'Outdoor Piazza Seating', 'House Chianti Wine', 'English Speaking Staff'],
    reviews: [
      {
        id: 'rev-od-1',
        author: 'Jessica Huang',
        authorType: 'Foodie Explorer',
        rating: 5,
        date: 'Yesterday',
        comment: 'Hands down the best Carbonara in Italy. The guanciale is intensely crunchy and the fresh pasta has a heavenly chew. Waited 20 mins at 1:30 PM.',
        recommendedItem: 'Tagliolini alla Carbonara',
        helpfulCount: 84
      }
    ]
  },

  // 4. ATTRACTIONS
  {
    id: 'rome-attraction-1',
    cityId: 'rome',
    name: 'Colosseum, Roman Forum & Palatine Hill',
    category: 'attraction',
    tagline: 'The iconic gladiatorial amphitheater & epicenter of the Roman Empire',
    description: 'The largest ancient amphitheater ever built, completed in 80 AD under Emperor Titus. Could seat over 50,000 spectators for gladiatorial combats, wild beast hunts, and mock sea battles.',
    image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 142000,
    address: 'Piazza del Colosseo 1, 00184 Roma RM, Italy',
    coordinates: { lat: 41.8902, lng: 12.4922 },
    timings: {
      open: '08:30 AM',
      close: '07:15 PM (Summer) / 04:30 PM (Winter)',
      days: 'Open Daily (Closed Dec 25, Jan 1)',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 18,
      childPrice: 0,
      currency: '€',
      ticketNotes: 'Standard 24h Ticket (Colosseum + Roman Forum + Palatine Hill): €18. Full Experience with Arena Floor / Underground: €24. Under 18 years: FREE (€2 booking fee). Timed online entry mandatory.',
      bookingAvailable: true
    },
    crowd: {
      peakHours: ['10:00 AM - 03:00 PM (Heavy tour groups and queue at security scanners)'],
      leastCrowdHours: '08:30 AM (First slot of the morning) & 05:30 PM (Golden hour)',
      peakDays: ['First Sunday of the month (Free entry day - Massive queues)', 'Easter week', 'Summer July-August'],
      liveCrowdLevel: 'High',
      hourlyCrowdIndex: [
        0, 0, 0, 0, 0, 0, 0, 0, 20, 65, 95, 100, 95, 90, 85, 80, 60, 35, 10, 0, 0, 0, 0, 0
      ],
      avgWaitTimeMinutes: {
        peak: 35,
        normal: 10
      },
      tipsToAvoidCrowd: [
        'Mandatory: Tickets sell out weeks in advance; book exactly 30 days ahead on the official ticketing portal (Parco Archeologico del Colosseo).',
        'Enter through the Roman Forum gate at Via dei Fori Imperiali where lines are 70% shorter.'
      ]
    },
    facilities: ['Metro Station Colosseo (Line B)', 'Audio & Video Guide Rentals', 'Wheelchair Lifts', 'Official Bookstore'],
    reviews: [
      {
        id: 'rev-cl-1',
        author: 'Alexander Wright',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '4 days ago',
        comment: 'Booked the 8:30 AM opening slot and it was quiet and crisp with golden morning light illuminating the arches. Absolutely unforgettable.',
        helpfulCount: 78
      }
    ]
  },

  // ================= BANGKOK =================
  // 1. THEATRES
  {
    id: 'bangkok-theatre-1',
    cityId: 'bangkok',
    name: 'Paragon Cineplex (Siam Paragon)',
    category: 'theatre',
    tagline: 'World-class flagship cineplex with IMAX Laser & Enigma VIP Club',
    description: 'Spread across the 5th & 6th floors of luxury mall Siam Paragon, featuring 16 screens, Thailand\'s largest IMAX with Laser screen, 4DX motion seats, and the ultra-luxurious Enigma Club with cocktail lounge and reclining duvet beds.',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 5400,
    address: '5th-6th Floor, Siam Paragon, 991 Rama I Rd, Pathum Wan, Bangkok 10330',
    coordinates: { lat: 13.7466, lng: 100.5350 },
    timings: {
      open: '10:00 AM',
      close: '12:00 AM (Midnight)',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 320,
      vipPrice: 1200,
      currency: '฿',
      ticketNotes: 'Standard Digital: ฿320. IMAX Laser: ฿450 - ฿600. VIP Enigma Recliner with Drinks & Gourmet Tapas: ฿1,200 - ฿2,000.',
      bookingAvailable: true
    },
    facilities: ['IMAX Laser Giant Screen', '4DX Motion', 'VIP Blanket & Massage Chair Lounge', 'BTS Siam Skywalk Direct Link'],
    movies: [
      {
        id: 'mov-bkk-1',
        title: 'How to Make Millions Before Grandma Dies',
        poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80',
        language: 'Thai (with English & Chinese Subtitles)',
        format: 'Digital 2D',
        duration: '2h 07m',
        genre: ['Drama', 'Family'],
        rating: 9.3,
        certification: 'PG',
        synopsis: 'A heartfelt, record-breaking Southeast Asian blockbuster examining family devotion and modern generational ties.',
        showtimes: [
          { time: '11:15 AM', price: 320, currency: '฿', seatAvailability: 'Available', screenType: 'Hall 4' },
          { time: '03:45 PM', price: 320, currency: '฿', seatAvailability: 'Filling Fast', screenType: 'Hall 4' },
          { time: '07:30 PM', price: 360, currency: '฿', seatAvailability: 'Almost Full', screenType: 'Hall 4' }
        ]
      }
    ],
    reviews: [
      {
        id: 'rev-pc-1',
        author: 'Natasha Tan',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '5 days ago',
        comment: 'Hands down the best cinema experience in Asia. Recliner seats with soft blankets, incredible sound, and subtitles were crisp and clear.',
        helpfulCount: 33
      }
    ]
  },

  // 2. TEMPLES
  {
    id: 'bangkok-temple-1',
    cityId: 'bangkok',
    name: 'Wat Arun (Temple of Dawn)',
    category: 'temple',
    tagline: 'Magnificent riverside pagoda encrusted with colorful porcelain mosaics',
    description: 'Situated on the west bank of the Chao Phraya River, Wat Arun\'s 70-meter central prang (Khmer-style spire) is encrusted with millions of pieces of colorful Chinese porcelain that shimmer at sunrise and sunset.',
    image: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1563492065599-3520f775eeed?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewCount: 46200,
    address: '158 Thanon Wang Doem, Wat Arun, Bangkok Yai, Bangkok 10600',
    coordinates: { lat: 13.7437, lng: 100.4889 },
    templeDeity: 'Phra Prang (Dedicated to Hindu god Aruna & Theravada Buddhist Relics)',
    dressCode: 'Strict Buddhist dress code: shoulders and knees covered. Traditional Thai costume rentals available outside for ฿200.',
    timings: {
      open: '08:00 AM',
      close: '06:00 PM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 100,
      currency: '฿',
      ticketNotes: 'Foreign Tourists: ฿100 (Includes a free complimentary bottle of chilled drinking water). Thai Citizens: FREE.',
      bookingAvailable: false
    },
    crowd: {
      peakHours: ['03:30 PM - 05:45 PM (Sunset photo rush and river cruises)'],
      leastCrowdHours: '08:00 AM sharp when morning gates open',
      peakDays: ['Weekends', 'Loy Krathong festival', 'Songkran'],
      liveCrowdLevel: 'Moderate',
      hourlyCrowdIndex: [
        0, 0, 0, 0, 0, 0, 0, 0, 30, 60, 75, 70, 65, 70, 85, 95, 100, 70, 20, 0, 0, 0, 0, 0
      ],
      avgWaitTimeMinutes: {
        peak: 15,
        normal: 5
      },
      tipsToAvoidCrowd: [
        'Take the ฿5 cross-river shuttle ferry from Tien Pier (near Wat Pho) directly to Wat Arun pier.',
        'Rent a traditional silk Thai costume (Chut Thai) at 8:15 AM for stunning photos on the steep porcelain steps before the heat and crowds arrive.'
      ]
    },
    facilities: ['River Ferry Pier', 'Thai Costume Rental Shops', 'Gift Shops', 'Free Cold Water Bottle with Ticket'],
    reviews: [
      {
        id: 'rev-wa-1',
        author: 'Somchai & Emily',
        authorType: 'Family Traveler',
        rating: 5,
        date: '2 days ago',
        comment: 'Only 100 baht ($3) and truly breathtaking architecture. The intricate porcelain flowers on every inch of the spire are extraordinary.',
        helpfulCount: 47
      }
    ]
  },

  // 3. RESTAURANTS
  {
    id: 'bangkok-rest-1',
    cityId: 'bangkok',
    name: 'Raan Jay Fai (Michelin Star Street Food)',
    category: 'restaurant',
    tagline: 'World-famous Michelin-starred wok maestro in goggles cooking over open fire',
    description: 'Iconic street food legend Supinya Junsuta (Jay Fai) wears her signature ski goggles while single-handedly cooking monstrous, golden charcoal-wok fried crab omelettes overflowing with sweet jumbo lump crab meat.',
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewCount: 9200,
    address: '327 Maha Chai Rd, Samran Rat, Phra Nakhon, Bangkok 10200',
    coordinates: { lat: 13.7526, lng: 100.5048 },
    cuisine: ['Michelin Star Thai Street Food', 'Seafood', 'Wok Specialties'],
    priceCategory: '$$$',
    timings: {
      open: '09:00 AM',
      close: '07:30 PM (Wednesdays to Saturdays)',
      days: 'Closed Sun, Mon, Tue',
      currentStatus: 'Open Now',
      specialNote: 'Walk-in queue list opens early in the morning.'
    },
    ticket: {
      isFree: true,
      generalPrice: '฿1,200 - ฿2,000 per person',
      currency: '฿',
      ticketNotes: 'Cash only or Thai QR payment.',
      bookingAvailable: false
    },
    topDishes: [
      {
        name: 'Kai-Jeaw Poo (Legendary Jumbo Lump Crab Omelette)',
        isVeg: false,
        price: '฿1,500',
        rating: 4.9,
        reviewCount: 5100,
        badge: 'Most Rated',
        description: 'A massive crispy golden burrito-shaped omelette packed to the brim with more than 500g of pure sweet steamed jumbo lump crab meat with fiery sriracha dip.'
      },
      {
        name: 'Drunken Seafood Noodles (Pad Kee Mao Talay)',
        isVeg: false,
        price: '฿800',
        rating: 4.8,
        reviewCount: 2400,
        badge: 'Signature Dish',
        description: 'Wide flat rice noodles wok-charred with intense smoky wok hei, colossal prawns, squid, holy basil, and fresh green peppercorns.'
      }
    ],
    facilities: ['Open Wok Kitchen Theater', 'Michelin Guide Award Plaque', 'Air-cooled indoor seating'],
    reviews: [
      {
        id: 'rev-jf-1',
        author: 'Gordon M.',
        authorType: 'Foodie Explorer',
        rating: 5,
        date: '4 days ago',
        comment: 'Worth every single baht. The crab omelette is packed with nothing but solid sweet crab lumps with zero filler. Watching Jay Fai command the flames with her goggles is pure culinary theater.',
        recommendedItem: 'Kai-Jeaw Poo Crab Omelette',
        helpfulCount: 71
      }
    ]
  },

  // 4. ATTRACTIONS
  {
    id: 'bangkok-attraction-1',
    cityId: 'bangkok',
    name: 'The Grand Palace & Temple of the Emerald Buddha',
    category: 'attraction',
    tagline: 'The glittering golden ceremonial residence of Siamese Kings',
    description: 'Established in 1782, this 218,000-square-meter complex is Bangkok\'s most revered complex housing Wat Phra Kaew (Temple of the Emerald Buddha, carved from a single piece of flawless green jade).',
    image: 'https://images.unsplash.com/photo-1563492065599-3520f775eeed?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 61000,
    address: 'Na Phra Lan Rd, Phra Borom Maha Ratchawang, Phra Nakhon, Bangkok 10200',
    coordinates: { lat: 13.7500, lng: 100.4913 },
    timings: {
      open: '08:30 AM',
      close: '03:30 PM (Ticket booth closes at 03:30 PM sharp)',
      days: 'Open Daily (365 Days)',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 500,
      currency: '฿',
      ticketNotes: 'Foreign Tourists: ฿500 (Includes entry to Wat Phra Kaew, Grand Palace grounds, Queen Sirikit Textile Museum, and a traditional Khon masked dance performance at Sala Chalermkrung Royal Theatre). Thai Citizens: FREE.',
      bookingAvailable: true
    },
    facilities: ['Free Audio Guide Rental Desk', 'Luggage Check / Lockers', 'Royal Guard March Ceremony', 'Direct Pier Link'],
    reviews: [
      {
        id: 'rev-gp-1',
        author: 'Thomas Weber',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '1 week ago',
        comment: 'The golden spires and mosaic murals of the Ramakien story are dazzling. Arrive right at 8:30 AM to beat the tropical heat.',
        helpfulCount: 54
      }
    ]
  },

  // ================= MUMBAI =================
  // 1. THEATRES
  {
    id: 'mumbai-theatre-1',
    cityId: 'mumbai',
    name: 'PVR INOX Palladium (Lower Parel)',
    category: 'theatre',
    tagline: 'Mumbai\'s premier luxury cinema with IMAX with Laser & Insignia VIP dining',
    description: 'Located in the high-end High Street Phoenix / Palladium Mall in Lower Parel, this flagship multiplex offers Mumbai\'s sharpest IMAX Laser projection, Insignia live chef culinary service right to your recliner, and star-studded Bollywood premieres.',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 6800,
    address: 'Level 4, Palladium Mall, 462 Senapati Bapat Marg, Lower Parel, Mumbai 400013',
    coordinates: { lat: 18.9950, lng: 72.8248 },
    timings: {
      open: '09:00 AM',
      close: '01:00 AM',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: false,
      generalPrice: 380,
      vipPrice: 950,
      currency: '₹',
      ticketNotes: 'Executive: ₹380, IMAX Laser: ₹650 - ₹850, Insignia Ultra-VIP Recliner: ₹950 - ₹1,400.',
      bookingAvailable: true
    },
    facilities: ['IMAX Laser Hall', 'Insignia Butler Service', 'Valet Parking', 'Gourmet Truffle Popcorn'],
    movies: [
      {
        id: 'mov-mum-1',
        title: 'Singham Again (Cop Universe)',
        poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
        language: 'Hindi (with English Subtitles)',
        format: 'IMAX Laser 2D',
        duration: '2h 45m',
        genre: ['Action', 'Thriller', 'Drama'],
        rating: 8.4,
        certification: 'UA',
        synopsis: 'High-octane action thriller featuring an ensemble Bollywood cast fighting criminal empires.',
        showtimes: [
          { time: '10:45 AM', price: 550, currency: '₹', seatAvailability: 'Available', screenType: 'IMAX Laser' },
          { time: '02:30 PM', price: 650, currency: '₹', seatAvailability: 'Filling Fast', screenType: 'IMAX Laser' },
          { time: '06:45 PM', price: 850, currency: '₹', seatAvailability: 'Almost Full', screenType: 'IMAX Laser' },
          { time: '10:30 PM', price: 700, currency: '₹', seatAvailability: 'Available', screenType: 'IMAX Laser' }
        ]
      }
    ],
    reviews: [
      {
        id: 'rev-pv-1',
        author: 'Karan Singhania',
        authorType: 'Local Guide',
        rating: 5,
        date: '3 days ago',
        comment: 'Best IMAX experience in Mumbai. Picture clarity and audio are unmatched. Great gourmet nachos and truffle popcorn.',
        helpfulCount: 39
      }
    ]
  },

  // 2. TEMPLES
  {
    id: 'mumbai-temple-1',
    cityId: 'mumbai',
    name: 'Shree Siddhivinayak Ganpati Mandir (Prabhadevi)',
    category: 'temple',
    tagline: 'Mumbai\'s most visited shrine of Lord Ganesha with gold-plated sanctum',
    description: 'Dedicated to Lord Ganesha (Siddhivinayak - "Ganesha who grants your wish"). The inner sanctum features a monolithic black stone idol with a right-sided trunk, nestled inside a 200-year-old gilded gold dome.',
    image: 'https://images.unsplash.com/photo-1567591414240-e1069ec31146?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewCount: 56000,
    address: 'SK Bole Marg, Prabhadevi, Mumbai, Maharashtra 400028',
    coordinates: { lat: 19.0169, lng: 72.8306 },
    templeDeity: 'Lord Ganesha (Navasacha Ganpati - Wish-Fulfilling Ganesha)',
    dressCode: 'Modest clothing. Western sleeveless and shorts discouraged.',
    timings: {
      open: '05:30 AM',
      close: '10:00 PM (Tuesdays: 03:15 AM - 11:30 PM)',
      days: 'Open Daily',
      currentStatus: 'Open Now',
      specialNote: 'Tuesdays open early from 3:15 AM for special Kakad Aarti.'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE (General Queue)',
      vipPrice: 100,
      currency: '₹',
      ticketNotes: 'General Darshan: FREE. VIP Fast-track QR pass: ₹100 per person (Book via official Siddhivinayak temple app or on-spot counter). Mahapuja: ₹500.',
      bookingAvailable: true
    },
    crowd: {
      peakHours: [
        '04:00 AM - 11:00 PM on TUESDAYS (Massive 200,000+ devotee queues stretching 2 km)',
        '07:00 PM - 09:00 PM (Daily Sandhya Aarti & Modak offering)'
      ],
      leastCrowdHours: '01:00 PM - 04:00 PM on Thursdays and Fridays (Under 20 mins wait)',
      peakDays: ['Tuesdays (Mangalwar)', 'Ganesh Chaturthi (10-day festival)', 'Angarika Sankashti Chaturthi'],
      liveCrowdLevel: 'High',
      hourlyCrowdIndex: [
        10, 5, 20, 50, 75, 80, 70, 60, 65, 80, 85, 70, 40, 30, 35, 50, 70, 85, 90, 85, 60, 30, 15, 10
      ],
      avgWaitTimeMinutes: {
        peak: 180,
        normal: 35,
        vip: 15
      },
      tipsToAvoidCrowd: [
        'If visiting on a Tuesday, ABSOLUTELY book the ₹100 VIP pass online in advance, or queue wait times can exceed 3 to 4 hours.',
        'Buy fresh hot Modaks and coconut garland prasad from the official trust stalls near Gate 3.'
      ],
      specialRituals: [
        { name: 'Kakad Aarti (Dawn awakening)', time: '05:30 AM', crowdImpact: 'High' },
        { name: 'Shree Darshan & Naivedya', time: '12:05 PM', crowdImpact: 'Medium' },
        { name: 'Evening Dhoop Aarti', time: '07:30 PM', crowdImpact: 'High' }
      ]
    },
    facilities: ['VIP Online Scanner Gate', 'Shoe Counters', 'Prasad Counters (Mawa Modak)', 'High Security Locker System'],
    reviews: [
      {
        id: 'rev-sv-1',
        author: 'Rohit Kadam',
        authorType: 'Family Traveler',
        rating: 5,
        date: 'Yesterday',
        comment: 'Booked the ₹100 VIP pass for our family and had darshan in just 12 minutes! The gold-embossed sanctum and positive vibes are divine.',
        visitedTime: '02:30 PM (Afternoon)',
        crowdExperience: 'Comfortable',
        helpfulCount: 68
      }
    ]
  },

  // 3. RESTAURANTS
  {
    id: 'mumbai-rest-1',
    cityId: 'mumbai',
    name: 'Britannia & Co. Restaurant (Ballard Estate)',
    category: 'restaurant',
    tagline: 'Legendary 100-year-old Parsi-Irani institution famous for Berry Pulao',
    description: 'Founded in 1923 in a charming colonial building with bentwood furniture and ticking grandfather clocks, famous for authentic Parsi recipes imported from Iran, fragrant Berry Pulao, and silky Caramel Custard.',
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewCount: 6200,
    address: 'Wakefield House, 11 Sport Rd, 16 Sprott Rd, Ballard Estate, Fort, Mumbai 400001',
    coordinates: { lat: 18.9351, lng: 72.8402 },
    cuisine: ['Authentic Parsi', 'Irani Heritage', 'Mutton & Chicken Specialties'],
    priceCategory: '$$',
    timings: {
      open: '11:30 AM',
      close: '04:00 PM (Lunch only)',
      days: 'Closed Sundays',
      currentStatus: 'Open Now',
      specialNote: 'Arrive early by 12:30 PM for lunch seats.'
    },
    ticket: {
      isFree: true,
      generalPrice: '₹600 - ₹900 per person',
      currency: '₹',
      ticketNotes: 'Cash and cards accepted.',
      bookingAvailable: false
    },
    topDishes: [
      {
        name: 'Mutton / Chicken Berry Pulao',
        isVeg: false,
        price: '₹750',
        rating: 4.9,
        reviewCount: 3800,
        badge: 'Most Rated',
        description: 'Aromatic fragrant basmati rice cooked with succulent slow-cooked meat, topped with tangy Iranian zereshk (barberries), fried onions, and cashews.'
      },
      {
        name: 'Caramel Custard (Heritage Recipe)',
        isVeg: false,
        price: '₹180',
        rating: 4.8,
        reviewCount: 2900,
        badge: 'Signature Dish',
        description: 'Velvety smooth, melt-in-mouth egg custard bathed in golden bittersweet burnt caramel syrup.'
      }
    ],
    facilities: ['Heritage Wooden Decor', 'Air Conditioned', 'Centuries-old Recipe Books'],
    reviews: [
      {
        id: 'rev-br-1',
        author: 'Zeenat Merchant',
        authorType: 'Local Guide',
        rating: 5,
        date: '1 week ago',
        comment: 'The Berry Pulao with sweet-sour Iranian barberries is legendary for a reason. Don\'t leave without ordering the caramel custard and Duke\'s Raspberry soda!',
        recommendedItem: 'Mutton Berry Pulao',
        helpfulCount: 46
      }
    ]
  },

  // 4. ATTRACTIONS
  {
    id: 'mumbai-attraction-1',
    cityId: 'mumbai',
    name: 'Gateway of India & Elephanta Island Caves',
    category: 'attraction',
    tagline: 'Colonial basalt arch overlooking Mumbai Harbour & UNESCO rock-cut Shiva caves',
    description: 'Built to commemorate the 1911 royal visit of King George V, this 26-meter Indo-Saracenic basalt arch is Mumbai\'s primary seaside monument and departure point for ferry boats heading to the 5th-century Elephanta rock-cut cave temples.',
    image: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=800&q=80',
    gallery: ['https://images.unsplash.com/photo-1567591414240-e1069ec31146?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewCount: 88000,
    address: 'Apollo Bandar, Colaba, Mumbai, Maharashtra 400001',
    coordinates: { lat: 18.9220, lng: 72.8347 },
    timings: {
      open: '24 Hours Open (Gateway Promenade)',
      close: 'Elephanta Ferries: 09:00 AM - 05:30 PM (Closed Mondays)',
      days: 'Open Daily',
      currentStatus: 'Open Now'
    },
    ticket: {
      isFree: true,
      generalPrice: 'FREE (Gateway of India)',
      currency: '₹',
      ticketNotes: 'Gateway of India Promenade: 100% FREE. Roundtrip Elephanta Island Ferry Ticket: ₹260 (Luxury boat) / ₹200 (Economy). Elephanta Caves ASI Entry: ₹40 (Indian) / ₹600 (Foreign).',
      bookingAvailable: true
    },
    crowd: {
      peakHours: ['04:30 PM - 08:30 PM (Evening sea breeze and sunset crowds)'],
      leastCrowdHours: '06:30 AM - 09:00 AM (Cool morning sunrise overlooking the Arabian Sea)',
      peakDays: ['Sundays', 'Public Holidays', 'New Year Eve'],
      liveCrowdLevel: 'Moderate',
      hourlyCrowdIndex: [
        10, 5, 5, 10, 20, 45, 60, 50, 40, 35, 30, 30, 30, 35, 45, 60, 80, 95, 95, 80, 50, 30, 20, 15
      ],
      tipsToAvoidCrowd: [
        'Visit at sunrise for crisp views of the Taj Mahal Palace Hotel reflecting off the ocean without crowds of street vendors.',
        'Catch the 9:00 AM first ferry to Elephanta to explore the UNESCO Trimurti Cave before the midday island heat.'
      ]
    },
    facilities: ['Ferry Boat Terminus', 'Opposite iconic Taj Mahal Palace Hotel', 'Seaside Promenade Benches', 'Tourist Police Assistance'],
    reviews: [
      {
        id: 'rev-gw-1',
        author: 'Siddharth Roy',
        authorType: 'Solo Traveler',
        rating: 5,
        date: '4 days ago',
        comment: 'Sitting by the Arabian Sea at sunset with the Gateway illuminated against the night sky is the quintessential Mumbai experience.',
        helpfulCount: 57
      }
    ]
  }
];
