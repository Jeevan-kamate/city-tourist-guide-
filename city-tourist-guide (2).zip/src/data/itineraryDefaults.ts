import { ItineraryPlan, City, Place, CityEvent } from '../types';

export const createDefaultPlanForCity = (
  city: City,
  cityPlaces: Place[],
  cityEvents: CityEvent[]
): ItineraryPlan => {
  const temples = cityPlaces.filter((p) => p.category === 'temple');
  const restaurants = cityPlaces.filter((p) => p.category === 'restaurant');
  const attractions = cityPlaces.filter((p) => p.category === 'attraction');
  const theatres = cityPlaces.filter((p) => p.category === 'theatre');

  const day1Items: any[] = [];
  const day2Items: any[] = [];

  // Day 1 Morning
  if (temples[0]) {
    day1Items.push({
      id: `plan-item-${city.id}-d1-1`,
      placeId: temples[0].id,
      place: temples[0],
      startTime: '08:00',
      endTime: '10:00',
      dayNumber: 1,
      order: 0,
      transportModeToNext: 'walk',
      travelTimeToNext: '15 mins',
      notes: `Optimal crowd timing: ${temples[0].crowd?.bestTimeToVisit || 'early morning'}.`,
      estimatedCost: temples[0].ticket.isFree ? 0 : temples[0].ticket.generalPrice,
      isCompleted: false,
    });
  }

  // Day 1 Afternoon
  if (restaurants[0]) {
    day1Items.push({
      id: `plan-item-${city.id}-d1-2`,
      placeId: restaurants[0].id,
      place: restaurants[0],
      startTime: '12:30',
      endTime: '14:00',
      dayNumber: 1,
      order: 1,
      transportModeToNext: 'taxi',
      travelTimeToNext: '20 mins',
      notes: `Top recommended dish: ${restaurants[0].topDishes?.[0]?.name || 'Specialty cuisine'}.`,
      estimatedCost: 15,
      isCompleted: false,
    });
  }

  // Day 1 Sights
  if (attractions[0]) {
    day1Items.push({
      id: `plan-item-${city.id}-d1-3`,
      placeId: attractions[0].id,
      place: attractions[0],
      startTime: '14:30',
      endTime: '17:30',
      dayNumber: 1,
      order: 2,
      transportModeToNext: 'walk',
      travelTimeToNext: '10 mins',
      notes: attractions[0].ticket.ticketNotes || 'Heritage landmark exploration.',
      estimatedCost: attractions[0].ticket.isFree ? 0 : attractions[0].ticket.generalPrice,
      isCompleted: false,
    });
  }

  // Day 1 Evening Event or Theatre
  if (cityEvents[0]) {
    day1Items.push({
      id: `plan-item-${city.id}-d1-4`,
      eventId: cityEvents[0].id,
      event: cityEvents[0],
      startTime: '18:30',
      endTime: '21:00',
      dayNumber: 1,
      order: 3,
      notes: `Local event: ${cityEvents[0].title}. ${cityEvents[0].timing}`,
      estimatedCost: cityEvents[0].isFree ? 0 : cityEvents[0].ticketPrice,
      isCompleted: false,
    });
  } else if (theatres[0]) {
    day1Items.push({
      id: `plan-item-${city.id}-d1-4`,
      placeId: theatres[0].id,
      place: theatres[0],
      startTime: '18:30',
      endTime: '21:30',
      dayNumber: 1,
      order: 3,
      notes: `Now showing: ${theatres[0].movies?.[0]?.title || 'Evening Cinema Show'}.`,
      estimatedCost: theatres[0].ticket.isFree ? 0 : theatres[0].ticket.generalPrice,
      isCompleted: false,
    });
  }

  // Day 2
  if (temples[1] || attractions[1]) {
    const morningPlace = temples[1] || attractions[1];
    day2Items.push({
      id: `plan-item-${city.id}-d2-1`,
      placeId: morningPlace.id,
      place: morningPlace,
      startTime: '09:00',
      endTime: '11:30',
      dayNumber: 2,
      order: 0,
      transportModeToNext: 'auto',
      travelTimeToNext: '20 mins',
      notes: morningPlace.tagline,
      estimatedCost: morningPlace.ticket.isFree ? 0 : morningPlace.ticket.generalPrice,
      isCompleted: false,
    });
  }

  if (restaurants[1]) {
    day2Items.push({
      id: `plan-item-${city.id}-d2-2`,
      placeId: restaurants[1].id,
      place: restaurants[1],
      startTime: '12:30',
      endTime: '14:00',
      dayNumber: 2,
      order: 1,
      transportModeToNext: 'walk',
      travelTimeToNext: '15 mins',
      notes: `Lunch highlight: ${restaurants[1].topDishes?.[0]?.name || 'Traditional lunch'}.`,
      estimatedCost: 20,
      isCompleted: false,
    });
  }

  if (cityEvents[1]) {
    day2Items.push({
      id: `plan-item-${city.id}-d2-3`,
      eventId: cityEvents[1].id,
      event: cityEvents[1],
      startTime: '15:30',
      endTime: '18:30',
      dayNumber: 2,
      order: 2,
      notes: cityEvents[1].description,
      estimatedCost: cityEvents[1].isFree ? 0 : cityEvents[1].ticketPrice,
      isCompleted: false,
    });
  }

  return {
    id: `itin-plan-${city.id}`,
    cityId: city.id,
    title: `3-Day Essence of ${city.name}`,
    description: `A curated tourist schedule integrating sacred rituals, cinema, rated gastronomy, entry tickets, and live cultural events.`,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    isCustom: false,
    days: [
      {
        id: `day-1-${city.id}`,
        dayNumber: 1,
        date: new Date().toISOString().split('T')[0],
        title: `Day 1: Highlights & Heritage`,
        items: day1Items,
      },
      {
        id: `day-2-${city.id}`,
        dayNumber: 2,
        date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        title: `Day 2: Culture & Cuisine`,
        items: day2Items,
      },
      {
        id: `day-3-${city.id}`,
        dayNumber: 3,
        date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        title: `Day 3: Scenic Explorations & Souvenirs`,
        items: [],
      },
    ],
  };
};
