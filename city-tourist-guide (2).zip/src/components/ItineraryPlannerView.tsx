import React, { useState, useMemo } from 'react';
import { 
  City, 
  Place, 
  CityEvent, 
  ItineraryPlan, 
  ItineraryDay, 
  ItineraryScheduleItem, 
  PlaceCategory 
} from '../types';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  ArrowUp, 
  ArrowDown, 
  Navigation, 
  Ticket, 
  DollarSign, 
  Share2, 
  Download, 
  Sparkles, 
  Footprints, 
  Car, 
  Train, 
  Bus, 
  AlertTriangle, 
  Search, 
  X, 
  Film, 
  UtensilsCrossed, 
  Landmark, 
  PartyPopper, 
  Save, 
  Copy, 
  Check, 
  Edit3 
} from 'lucide-react';

interface ItineraryPlannerViewProps {
  city: City;
  places: Place[];
  events: CityEvent[];
  activePlan: ItineraryPlan;
  onUpdatePlan: (plan: ItineraryPlan) => void;
  onShowOnMap: (place: Place | CityEvent) => void;
  onSelectPlace: (place: Place) => void;
  onSelectEvent: (event: CityEvent) => void;
  onOpenMapWithRoute?: (dayItems: ItineraryScheduleItem[]) => void;
}

export const ItineraryPlannerView: React.FC<ItineraryPlannerViewProps> = ({
  city,
  places,
  events,
  activePlan,
  onUpdatePlan,
  onShowOnMap,
  onSelectPlace,
  onSelectEvent,
  onOpenMapWithRoute,
}) => {
  const [selectedDayNumber, setSelectedDayNumber] = useState<number>(1);
  const [isAddPickerOpen, setIsAddPickerOpen] = useState(false);
  const [pickerCategory, setPickerCategory] = useState<'all' | PlaceCategory | 'events' | 'custom'>('all');
  const [pickerSearch, setPickerSearch] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [customTime, setCustomTime] = useState('12:00');
  const [customDuration, setCustomDuration] = useState('1');
  const [customLocation, setCustomLocation] = useState('');
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [planTitle, setPlanTitle] = useState(activePlan.title);
  const [copiedNotification, setCopiedNotification] = useState(false);

  const currentDay = useMemo(() => {
    return activePlan.days.find((d) => d.dayNumber === selectedDayNumber) || activePlan.days[0] || {
      id: 'day-1',
      dayNumber: 1,
      date: activePlan.startDate,
      items: [],
    };
  }, [activePlan, selectedDayNumber]);

  // Calculate total budget & stats
  const stats = useMemo(() => {
    let totalItems = 0;
    let totalEstimatedCost = 0;
    let completedItems = 0;

    activePlan.days.forEach((day) => {
      day.items.forEach((item) => {
        totalItems++;
        if (item.isCompleted) completedItems++;
        if (item.estimatedCost) {
          totalEstimatedCost += item.estimatedCost;
        }
      });
    });

    return { totalItems, totalEstimatedCost, completedItems };
  }, [activePlan]);

  // Add new day
  const handleAddNewDay = () => {
    const nextDayNumber = activePlan.days.length + 1;
    const newDay: ItineraryDay = {
      id: `day-${nextDayNumber}-${Date.now()}`,
      dayNumber: nextDayNumber,
      date: '',
      title: `Day ${nextDayNumber} in ${city.name}`,
      items: [],
    };

    const updatedPlan: ItineraryPlan = {
      ...activePlan,
      days: [...activePlan.days, newDay],
      updatedAt: new Date().toISOString(),
    };

    onUpdatePlan(updatedPlan);
    setSelectedDayNumber(nextDayNumber);
  };

  // Remove day
  const handleRemoveDay = (dayNum: number) => {
    if (activePlan.days.length <= 1) return; // Keep at least 1 day

    const filteredDays = activePlan.days
      .filter((d) => d.dayNumber !== dayNum)
      .map((d, index) => ({
        ...d,
        dayNumber: index + 1,
      }));

    const updatedPlan: ItineraryPlan = {
      ...activePlan,
      days: filteredDays,
      updatedAt: new Date().toISOString(),
    };

    onUpdatePlan(updatedPlan);
    setSelectedDayNumber(Math.min(selectedDayNumber, filteredDays.length));
  };

  // Toggle item completed
  const handleToggleComplete = (itemId: string) => {
    const updatedDays = activePlan.days.map((day) => {
      if (day.dayNumber === selectedDayNumber) {
        return {
          ...day,
          items: day.items.map((it) =>
            it.id === itemId ? { ...it, isCompleted: !it.isCompleted } : it
          ),
        };
      }
      return day;
    });

    onUpdatePlan({ ...activePlan, days: updatedDays, updatedAt: new Date().toISOString() });
  };

  // Remove item from day
  const handleRemoveItem = (itemId: string) => {
    const updatedDays = activePlan.days.map((day) => {
      if (day.dayNumber === selectedDayNumber) {
        return {
          ...day,
          items: day.items.filter((it) => it.id !== itemId),
        };
      }
      return day;
    });

    onUpdatePlan({ ...activePlan, days: updatedDays, updatedAt: new Date().toISOString() });
  };

  // Move item up/down in schedule
  const handleMoveItem = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= currentDay.items.length) return;

    const itemsCopy = [...currentDay.items];
    const temp = itemsCopy[index];
    itemsCopy[index] = itemsCopy[targetIndex];
    itemsCopy[targetIndex] = temp;

    const updatedDays = activePlan.days.map((day) => {
      if (day.dayNumber === selectedDayNumber) {
        return { ...day, items: itemsCopy };
      }
      return day;
    });

    onUpdatePlan({ ...activePlan, days: updatedDays, updatedAt: new Date().toISOString() });
  };

  // Update Item times or notes
  const handleUpdateItemTime = (itemId: string, startTime: string, endTime: string) => {
    const updatedDays = activePlan.days.map((day) => {
      if (day.dayNumber === selectedDayNumber) {
        return {
          ...day,
          items: day.items.map((it) =>
            it.id === itemId ? { ...it, startTime, endTime } : it
          ),
        };
      }
      return day;
    });

    onUpdatePlan({ ...activePlan, days: updatedDays, updatedAt: new Date().toISOString() });
  };

  // Add Place or Event to current day
  const handleAddStopToCurrentDay = (target: { type: 'place' | 'event' | 'custom'; item?: Place | CityEvent }) => {
    let newItem: ItineraryScheduleItem;

    if (target.type === 'custom') {
      const startH = parseInt(customTime.split(':')[0] || '12', 10);
      const endH = (startH + parseInt(customDuration, 10)) % 24;
      const endTime = `${endH < 10 ? '0' : ''}${endH}:${customTime.split(':')[1] || '00'}`;

      newItem = {
        id: `it-custom-${Date.now()}`,
        type: 'custom',
        customTitle: customTitle || 'Custom Activity',
        customLocation: customLocation || city.name,
        startTime: customTime,
        endTime,
        estimatedCost: 0,
        currency: city.currencySymbol,
        transportMode: 'walk',
        isCompleted: false,
      };
      setCustomTitle('');
      setCustomLocation('');
    } else if (target.type === 'place' && target.item) {
      const place = target.item as Place;
      let startTime = '10:00';
      let endTime = '12:00';

      if (currentDay.items.length > 0) {
        const lastItem = currentDay.items[currentDay.items.length - 1];
        const lastEndH = parseInt(lastItem.endTime.split(':')[0] || '12', 10);
        const newStartH = (lastEndH + 1) % 24;
        const newEndH = (newStartH + 2) % 24;
        startTime = `${newStartH < 10 ? '0' : ''}${newStartH}:00`;
        endTime = `${newEndH < 10 ? '0' : ''}${newEndH}:00`;
      }

      let estimatedCost = 0;
      if (!place.ticket.isFree && typeof place.ticket.generalPrice === 'number') {
        estimatedCost = place.ticket.generalPrice;
      }

      newItem = {
        id: `it-place-${Date.now()}`,
        type: 'place',
        placeId: place.id,
        place,
        startTime,
        endTime,
        estimatedCost,
        currency: place.ticket.currency || city.currencySymbol,
        transportMode: 'walk',
        isCompleted: false,
      };
    } else if (target.type === 'event' && target.item) {
      const event = target.item as CityEvent;
      let startTime = '18:30';
      let endTime = '21:00';

      let estimatedCost = 0;
      if (!event.isFree && typeof event.ticketPrice === 'number') {
        estimatedCost = event.ticketPrice;
      }

      newItem = {
        id: `it-event-${Date.now()}`,
        type: 'event',
        eventId: event.id,
        event,
        startTime,
        endTime,
        estimatedCost,
        currency: event.currency || city.currencySymbol,
        transportMode: 'walk',
        isCompleted: false,
      };
    } else {
      return;
    }

    const updatedDays = activePlan.days.map((day) => {
      if (day.dayNumber === selectedDayNumber) {
        return { ...day, items: [...day.items, newItem] };
      }
      return day;
    });

    onUpdatePlan({ ...activePlan, days: updatedDays, updatedAt: new Date().toISOString() });
    setIsAddPickerOpen(false);
  };

  // Copy Itinerary Text Summary
  const handleCopyItinerary = () => {
    let summary = `📍 ${activePlan.title} (${city.name})\n\n`;
    activePlan.days.forEach((day) => {
      summary += `--- DAY ${day.dayNumber} ---\n`;
      if (day.items.length === 0) {
        summary += `  No activities planned.\n`;
      } else {
        day.items.forEach((it, idx) => {
          const title = it.place?.name || it.event?.title || it.customTitle;
          const loc = it.place?.address || it.event?.locationName || it.customLocation;
          summary += `  ${idx + 1}. [${it.startTime} - ${it.endTime}] ${title} (${loc})\n`;
          if (it.notes) summary += `     Note: ${it.notes}\n`;
        });
      }
      summary += `\n`;
    });
    summary += `Total Estimated Ticket Budget: ${city.currencySymbol}${stats.totalEstimatedCost}\nGenerated by City Tourist Guide`;

    navigator.clipboard.writeText(summary);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  // Filter items for quick-add picker
  const pickerPlaces = useMemo(() => {
    return places.filter((p) => {
      if (pickerCategory !== 'all' && pickerCategory !== 'events' && pickerCategory !== 'custom' && p.category !== pickerCategory) {
        return false;
      }
      if (pickerSearch.trim()) {
        const q = pickerSearch.toLowerCase();
        return p.name.toLowerCase().includes(q) || p.address.toLowerCase().includes(q);
      }
      return true;
    });
  }, [places, pickerCategory, pickerSearch]);

  const pickerEvents = useMemo(() => {
    return events.filter((e) => {
      if (pickerCategory !== 'all' && pickerCategory !== 'events') return false;
      if (pickerSearch.trim()) {
        const q = pickerSearch.toLowerCase();
        return e.title.toLowerCase().includes(q) || e.locationName.toLowerCase().includes(q);
      }
      return true;
    });
  }, [events, pickerCategory, pickerSearch]);

  return (
    <div id="itinerary-planner-view" className="space-y-6 text-[#3D3D3D]">
      
      {/* Top Banner & Trip Control Card */}
      <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-3xl p-6 sm:p-8 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative overflow-hidden">
        
        <div className="space-y-3 z-10 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#5A5A40] text-white flex items-center gap-1.5 uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5" />
              <span>Personalized Itinerary Planner</span>
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-white text-[#5A5A40] border border-[#DEDACF]">
              {city.name} Tour
            </span>
          </div>

          <div className="flex items-center gap-2">
            {isEditingTitle ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={planTitle}
                  onChange={(e) => setPlanTitle(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-[#5A5A40] bg-white text-xl font-serif font-bold text-[#2D2D2A] focus:outline-hidden"
                />
                <button
                  onClick={() => {
                    setIsEditingTitle(false);
                    onUpdatePlan({ ...activePlan, title: planTitle || `${city.name} Vacation Itinerary` });
                  }}
                  className="p-2 bg-[#5A5A40] text-white rounded-xl text-xs font-bold"
                >
                  Save
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-bold font-serif text-[#2D2D2A]">
                  {activePlan.title}
                </h1>
                <button
                  onClick={() => setIsEditingTitle(true)}
                  className="p-1 text-[#8B8B6B] hover:text-[#2D2D2A] transition-colors"
                  title="Rename Itinerary"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          <p className="text-xs sm:text-sm text-[#5A5A40] leading-relaxed">
            Customize your daily schedule, arrange attractions & events by preferred hours, track admission fees, and sync waypoints with our interactive map.
          </p>

          {/* Quick Metrics */}
          <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
            <span className="px-3 py-1.5 rounded-xl bg-white border border-[#DEDACF] font-bold text-[#2D2D2A] flex items-center gap-1.5 shadow-2xs">
              <Calendar className="w-3.5 h-3.5 text-[#5A5A40]" />
              <span>{activePlan.days.length} Days Planned</span>
            </span>

            <span className="px-3 py-1.5 rounded-xl bg-white border border-[#DEDACF] font-bold text-[#2D2D2A] flex items-center gap-1.5 shadow-2xs">
              <MapPin className="w-3.5 h-3.5 text-[#D28E5D]" />
              <span>{stats.totalItems} Total Stops ({stats.completedItems} visited)</span>
            </span>

            <span className="px-3 py-1.5 rounded-xl bg-white border border-[#DEDACF] font-bold text-[#2D2D2A] flex items-center gap-1.5 shadow-2xs">
              <Ticket className="w-3.5 h-3.5 text-[#C2410C]" />
              <span>Estimated Fees: {city.currencySymbol}{stats.totalEstimatedCost}</span>
            </span>
          </div>
        </div>

        {/* Action Buttons: Share, Print, Map Route */}
        <div className="flex flex-wrap lg:flex-col items-center lg:items-end gap-2 shrink-0 z-10 w-full lg:w-auto">
          <button
            onClick={() => {
              if (onOpenMapWithRoute) {
                onOpenMapWithRoute(currentDay.items);
              }
            }}
            className="flex-1 lg:flex-initial px-4 py-2.5 bg-[#5A5A40] hover:bg-[#454530] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-xs"
          >
            <Navigation className="w-4 h-4 text-amber-300" />
            <span>View Day {selectedDayNumber} on Map</span>
          </button>

          <button
            onClick={handleCopyItinerary}
            className="flex-1 lg:flex-initial px-4 py-2 bg-white hover:bg-[#F9F7F2] text-[#5A5A40] border border-[#DEDACF] text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-2xs"
          >
            {copiedNotification ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Copied Plan!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Summary</span>
              </>
            )}
          </button>
        </div>

      </div>

      {/* Days Switcher Tabs Strip */}
      <div className="flex items-center justify-between gap-3 border-b border-[#E5E2D9] pb-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {activePlan.days.map((day) => (
            <button
              key={day.id}
              onClick={() => setSelectedDayNumber(day.dayNumber)}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-bold text-xs whitespace-nowrap transition-all ${
                selectedDayNumber === day.dayNumber
                  ? 'bg-[#2D2D2A] text-white shadow-xs'
                  : 'bg-white text-[#5A5A40] border border-[#DEDACF] hover:bg-[#F4F1EA]'
              }`}
            >
              <span>Day {day.dayNumber}</span>
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                selectedDayNumber === day.dayNumber ? 'bg-white/20 text-white' : 'bg-[#EAE7DC] text-[#5A5A40]'
              }`}>
                {day.items.length}
              </span>
            </button>
          ))}

          <button
            onClick={handleAddNewDay}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs text-[#5A5A40] hover:text-[#2D2D2A] hover:bg-[#F4F1EA] border border-dashed border-[#8B8B6B] whitespace-nowrap transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Day</span>
          </button>
        </div>

        {activePlan.days.length > 1 && (
          <button
            onClick={() => handleRemoveDay(selectedDayNumber)}
            className="text-xs font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 shrink-0 p-1"
            title="Delete current day"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Delete Day {selectedDayNumber}</span>
          </button>
        )}
      </div>

      {/* Main Schedule Timeline for Selected Day */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Timeline list */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-lg text-[#2D2D2A] flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#5A5A40]" />
              <span>Day {selectedDayNumber} Schedule ({currentDay.items.length} Activities)</span>
            </h3>

            <button
              onClick={() => setIsAddPickerOpen(true)}
              className="px-3.5 py-1.5 bg-[#5A5A40] hover:bg-[#454530] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Stop to Day</span>
            </button>
          </div>

          {/* Timeline Items */}
          {currentDay.items.length === 0 ? (
            <div className="p-10 text-center bg-white border border-[#E5E2D9] rounded-3xl space-y-3">
              <Calendar className="w-10 h-10 text-[#8B8B6B] mx-auto" />
              <h4 className="font-serif font-bold text-base text-[#2D2D2A]">No stops scheduled for Day {selectedDayNumber} yet</h4>
              <p className="text-xs text-[#8B8B6B] max-w-sm mx-auto">
                Add nearby theatres, sacred temples, rated dining, famous monuments, or local cultural events.
              </p>
              <button
                onClick={() => setIsAddPickerOpen(true)}
                className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-xs font-bold hover:bg-[#454530] transition-colors inline-flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Browse Attractions & Events</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4 relative before:absolute before:left-6 sm:before:left-8 before:top-4 before:bottom-4 before:w-0.5 before:bg-[#E5E2D9]">
              {currentDay.items.map((item, index) => {
                const place = item.place;
                const event = item.event;
                const title = place?.name || event?.title || item.customTitle || 'Activity';
                const image = place?.image || event?.image || 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=400&q=80';
                const address = place?.address || event?.locationName || item.customLocation || city.name;
                const category = place?.category || event?.category || 'custom';

                return (
                  <div key={item.id} className="relative flex items-start gap-3 sm:gap-4 group">
                    
                    {/* Timeline Node Circle */}
                    <div className="relative z-10 shrink-0 mt-3">
                      <button
                        onClick={() => handleToggleComplete(item.id)}
                        className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                          item.isCompleted
                            ? 'bg-[#4A6741] border-[#4A6741] text-white'
                            : 'bg-white border-[#5A5A40] text-[#5A5A40] hover:bg-[#F4F1EA]'
                        }`}
                        title={item.isCompleted ? 'Mark as pending' : 'Mark as visited'}
                      >
                        {item.isCompleted ? (
                          <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[3]" />
                        ) : (
                          <span className="text-[10px] sm:text-xs font-bold">{index + 1}</span>
                        )}
                      </button>
                    </div>

                    {/* Timeline Card */}
                    <div className={`flex-1 bg-white border rounded-2xl p-4 transition-all shadow-2xs hover:shadow-sm ${
                      item.isCompleted ? 'border-[#D0E2CF] opacity-80 bg-[#FAFBF9]' : 'border-[#E5E2D9]'
                    }`}>
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        
                        {/* Time Slot Inputs */}
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#F4F1EA] border border-[#DEDACF] text-xs font-bold text-[#2D2D2A]">
                            <Clock className="w-3.5 h-3.5 text-[#5A5A40]" />
                            <input
                              type="time"
                              value={item.startTime}
                              onChange={(e) => handleUpdateItemTime(item.id, e.target.value, item.endTime)}
                              className="bg-transparent text-xs font-bold w-14 focus:outline-hidden"
                            />
                            <span className="text-[#8B8B6B]">-</span>
                            <input
                              type="time"
                              value={item.endTime}
                              onChange={(e) => handleUpdateItemTime(item.id, item.startTime, e.target.value)}
                              className="bg-transparent text-xs font-bold w-14 focus:outline-hidden"
                            />
                          </div>

                          <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-[#EAE7DC] text-[#5A5A40]">
                            {category.replace('_', ' ')}
                          </span>
                        </div>

                        {/* Order & Remove Controls */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleMoveItem(index, 'up')}
                            disabled={index === 0}
                            className="p-1 rounded-lg hover:bg-[#F4F1EA] text-[#8B8B6B] disabled:opacity-30 transition-colors"
                            title="Move Up"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleMoveItem(index, 'down')}
                            disabled={index === currentDay.items.length - 1}
                            className="p-1 rounded-lg hover:bg-[#F4F1EA] text-[#8B8B6B] disabled:opacity-30 transition-colors"
                            title="Move Down"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1 rounded-lg hover:bg-rose-50 text-rose-600 transition-colors"
                            title="Remove Stop"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Content Row */}
                      <div className="flex items-center gap-3.5 mt-3">
                        <img
                          src={image}
                          alt={title}
                          className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl object-cover shrink-0"
                        />

                        <div className="flex-1 min-w-0">
                          <h4
                            onClick={() => {
                              if (place) onSelectPlace(place);
                              else if (event) onSelectEvent(event);
                            }}
                            className={`font-serif font-bold text-sm sm:text-base text-[#2D2D2A] hover:text-[#5A5A40] cursor-pointer truncate ${
                              item.isCompleted ? 'line-through text-[#8B8B6B]' : ''
                            }`}
                          >
                            {title}
                          </h4>

                          <p className="text-xs text-[#666] truncate flex items-center gap-1 mt-0.5">
                            <MapPin className="w-3 h-3 text-[#D28E5D] shrink-0" />
                            <span>{address}</span>
                          </p>

                          {item.notes && (
                            <p className="text-[11px] text-[#5A5A40] italic mt-1 bg-[#F9F7F2] px-2 py-0.5 rounded-md inline-block">
                              📝 {item.notes}
                            </p>
                          )}
                        </div>

                        {/* Quick View Button */}
                        <div className="shrink-0 flex flex-col items-end gap-1">
                          {item.estimatedCost ? (
                            <span className="text-xs font-bold text-[#2D2D2A]">
                              {item.currency}{item.estimatedCost}
                            </span>
                          ) : (
                            <span className="text-[11px] font-semibold text-[#4A6741]">Free Entry</span>
                          )}

                          <button
                            onClick={() => {
                              if (place) onShowOnMap(place);
                              else if (event) onShowOnMap(event);
                            }}
                            className="text-[11px] font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1"
                          >
                            <Navigation className="w-3 h-3" />
                            <span className="hidden sm:inline">Locate</span>
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>

        {/* Right 1 Column: Daily Summary & Local Travel Assistant */}
        <div className="space-y-4">
          
          {/* Day Overview Box */}
          <div className="bg-white border border-[#E5E2D9] rounded-3xl p-5 space-y-4 shadow-2xs">
            <h3 className="font-serif font-bold text-base text-[#2D2D2A]">Day {selectedDayNumber} Summary</h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-[#F4F1EA]">
                <span className="text-[#8B8B6B]">Total Scheduled Stops</span>
                <span className="font-bold text-[#2D2D2A]">{currentDay.items.length}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-[#F4F1EA]">
                <span className="text-[#8B8B6B]">Estimated Day Admission</span>
                <span className="font-bold text-[#2D2D2A]">
                  {city.currencySymbol}
                  {currentDay.items.reduce((acc, it) => acc + (it.estimatedCost || 0), 0)}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-[#F4F1EA]">
                <span className="text-[#8B8B6B]">Start / End Span</span>
                <span className="font-bold text-[#2D2D2A]">
                  {currentDay.items.length > 0
                    ? `${currentDay.items[0].startTime} - ${currentDay.items[currentDay.items.length - 1].endTime}`
                    : 'Not set'}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                if (onOpenMapWithRoute) {
                  onOpenMapWithRoute(currentDay.items);
                }
              }}
              className="w-full py-2.5 bg-[#5A5A40] hover:bg-[#454530] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-xs"
            >
              <Navigation className="w-4 h-4 text-amber-300" />
              <span>Interactive Route Waypoints</span>
            </button>
          </div>

          {/* Smart Local Routing & Transit Tips */}
          <div className="bg-[#F9F7F2] border border-[#E5E2D9] rounded-3xl p-5 space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B8B6B] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#D28E5D]" />
              <span>Smart Travel Tips for {city.name}</span>
            </span>

            <p className="text-xs text-[#3D3D3D] leading-relaxed">
              Plan indoor attractions or air-conditioned theatres during midday (12:00 - 15:30) to avoid afternoon heat. Schedule holy temples and sacred aartis in the early morning or sunset twilight for the best crowd experience.
            </p>

            <div className="pt-2 border-t border-[#E5E2D9]">
              <span className="text-[11px] font-bold text-[#2D2D2A] block mb-1">Local Transit Options:</span>
              <div className="grid grid-cols-2 gap-1.5 text-[11px] text-[#5A5A40]">
                <span>🚶 Walking: Best in historic cores</span>
                <span>🚕 Cabs / Auto: Best across zones</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Add Attraction / Event Drawer Modal */}
      {isAddPickerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl w-full max-w-2xl max-h-[85vh] overflow-hidden shadow-2xl flex flex-col text-[#3D3D3D] my-auto">
            
            {/* Modal Header */}
            <div className="p-5 bg-[#F4F1EA] border-b border-[#DEDACF] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-[#5A5A40] text-white rounded-xl">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-base text-[#2D2D2A]">
                    Add Stop to Day {selectedDayNumber}
                  </h3>
                  <p className="text-xs text-[#8B8B6B]">Select any place, movie show, or live event in {city.name}</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddPickerOpen(false)}
                className="p-1.5 rounded-full hover:bg-[#EAE7DC] text-[#5A5A40]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Filter Tabs & Search */}
            <div className="p-4 border-b border-[#E5E2D9] space-y-3 shrink-0 bg-white">
              <div className="relative">
                <input
                  type="text"
                  value={pickerSearch}
                  onChange={(e) => setPickerSearch(e.target.value)}
                  placeholder="Search temples, theatres, food, sights, or festivals..."
                  className="w-full pl-9 pr-4 py-2 rounded-xl border border-[#DEDACF] bg-white text-xs font-medium text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                />
                <Search className="w-4 h-4 text-[#8B8B6B] absolute left-3 top-2.5" />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
                {[
                  { id: 'all', label: 'All Items' },
                  { id: 'temple', label: 'Temples' },
                  { id: 'theatre', label: 'Theatres' },
                  { id: 'restaurant', label: 'Restaurants' },
                  { id: 'attraction', label: 'Attractions' },
                  { id: 'events', label: 'Events Near Me' },
                  { id: 'custom', label: '+ Custom Activity' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setPickerCategory(tab.id as any)}
                    className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap text-xs transition-all ${
                      pickerCategory === tab.id
                        ? 'bg-[#5A5A40] text-white shadow-xs'
                        : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Picker Content List */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1">
              
              {/* Custom Activity Form if selected */}
              {pickerCategory === 'custom' && (
                <div className="p-4 bg-white border border-[#E5E2D9] rounded-2xl space-y-3">
                  <h4 className="font-serif font-bold text-sm text-[#2D2D2A]">Add Custom Activity</h4>
                  <div className="space-y-2">
                    <div>
                      <span className="text-[10px] text-[#8B8B6B] block mb-1">Activity Title</span>
                      <input
                        type="text"
                        value={customTitle}
                        onChange={(e) => setCustomTitle(e.target.value)}
                        placeholder="e.g. Hotel Check-In, Souvenir Shopping, Tea Break..."
                        className="w-full px-3 py-2 rounded-xl border border-[#DEDACF] text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[10px] text-[#8B8B6B] block mb-1">Start Time</span>
                        <input
                          type="time"
                          value={customTime}
                          onChange={(e) => setCustomTime(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-[#DEDACF] text-xs"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-[#8B8B6B] block mb-1">Duration (Hours)</span>
                        <select
                          value={customDuration}
                          onChange={(e) => setCustomDuration(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-[#DEDACF] text-xs"
                        >
                          <option value="1">1 Hour</option>
                          <option value="2">2 Hours</option>
                          <option value="3">3 Hours</option>
                          <option value="4">4 Hours</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8B8B6B] block mb-1">Location / Notes</span>
                      <input
                        type="text"
                        value={customLocation}
                        onChange={(e) => setCustomLocation(e.target.value)}
                        placeholder="e.g. Main Market, Hotel Lobby..."
                        className="w-full px-3 py-2 rounded-xl border border-[#DEDACF] text-xs"
                      />
                    </div>
                    <button
                      onClick={() => handleAddStopToCurrentDay({ type: 'custom' })}
                      className="w-full py-2.5 bg-[#5A5A40] text-white rounded-xl text-xs font-bold hover:bg-[#454530]"
                    >
                      Add Custom Activity to Schedule
                    </button>
                  </div>
                </div>
              )}

              {/* Events List if matching */}
              {(pickerCategory === 'all' || pickerCategory === 'events') && pickerEvents.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B8B6B] block">
                    🎪 Events & Festivals ({pickerEvents.length})
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {pickerEvents.map((ev) => (
                      <div
                        key={ev.id}
                        className="p-3 rounded-2xl bg-white border border-[#E5E2D9] hover:border-[#8B8B6B] flex items-center justify-between gap-2 shadow-2xs transition-all"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img src={ev.image} alt="" className="w-12 h-12 rounded-xl object-cover shrink-0" />
                          <div className="min-w-0">
                            <span className="text-[9px] font-bold text-[#C2410C] uppercase block">
                              {ev.status}
                            </span>
                            <h5 className="font-bold text-xs text-[#2D2D2A] truncate">{ev.title}</h5>
                            <p className="text-[10px] text-[#8B8B6B] truncate">{ev.timing}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleAddStopToCurrentDay({ type: 'event', item: ev })}
                          className="px-2.5 py-1.5 bg-[#5A5A40] text-white text-[10px] font-bold rounded-lg hover:bg-[#454530] shrink-0"
                        >
                          + Add
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Places List */}
              {pickerCategory !== 'events' && pickerCategory !== 'custom' && (
                <div className="space-y-2 pt-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B8B6B] block">
                    🏛️ Places & Attractions ({pickerPlaces.length})
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {pickerPlaces.map((pl) => (
                      <div
                        key={pl.id}
                        className="p-3 rounded-2xl bg-white border border-[#E5E2D9] hover:border-[#8B8B6B] flex items-center justify-between gap-2 shadow-2xs transition-all"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img src={pl.image} alt="" className="w-12 h-12 rounded-xl object-cover shrink-0" />
                          <div className="min-w-0">
                            <span className="text-[9px] font-bold text-[#5A5A40] uppercase block">
                              {pl.category}
                            </span>
                            <h5 className="font-bold text-xs text-[#2D2D2A] truncate">{pl.name}</h5>
                            <p className="text-[10px] text-[#8B8B6B] truncate">{pl.address}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleAddStopToCurrentDay({ type: 'place', item: pl })}
                          className="px-2.5 py-1.5 bg-[#5A5A40] text-white text-[10px] font-bold rounded-lg hover:bg-[#454530] shrink-0"
                        >
                          + Add
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

    </div>
  );
};
