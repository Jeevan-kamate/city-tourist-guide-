import React from 'react';
import { Place } from '../types';
import { Landmark, Ticket, Clock, Star, MapPin, Sparkles, Shield, Camera, Users } from 'lucide-react';
import { CrowdVisualizer } from './CrowdVisualizer';

interface AttractionsViewProps {
  attractions: Place[];
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
}

export const AttractionsView: React.FC<AttractionsViewProps> = ({
  attractions,
  onSelectPlace,
  onShowOnMap,
}) => {
  return (
    <div id="attractions-section" className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-rose-950 via-stone-900 to-rose-900 text-white rounded-2xl p-6 shadow-lg border border-rose-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-rose-600/30 border border-rose-400/30 rounded-xl">
                <Landmark className="w-5 h-5 text-rose-400" />
              </span>
              <h2 className="text-xl md:text-2xl font-bold font-display">
                Tourist Places, Heritage Sights & Entry Tickets
              </h2>
            </div>
            <p className="text-sm text-rose-200">
              Complete pricing guide with current entry ticket fees (domestic & international), daily opening hours, audio guide details, and crowd tips.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/15 text-xs flex items-center gap-3">
            <div>
              <span className="text-rose-200 block">Attractions</span>
              <span className="font-bold text-base text-white">{attractions.length} Heritage Sights</span>
            </div>
            <div className="h-6 w-px bg-white/20" />
            <div>
              <span className="text-rose-200 block">Ticket Status</span>
              <span className="font-bold text-base text-emerald-300">Verified Live</span>
            </div>
          </div>
        </div>
      </div>

      {/* Attractions Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {attractions.map((place) => (
          <div
            key={place.id}
            className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Image & Header */}
              <div className="relative h-56 w-full bg-stone-100 overflow-hidden">
                <img
                  src={place.image}
                  alt={place.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />

                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-white/95 text-stone-900 backdrop-blur-md shadow-sm">
                    {place.ticket.isFree ? '100% FREE ADMISSION' : `Entry: ${place.ticket.currency}${place.ticket.generalPrice}`}
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-stone-900 shadow-sm">
                    ⭐ {place.rating} ({place.reviewCount.toLocaleString()})
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <h3 className="font-bold text-xl leading-tight drop-shadow-xs">
                    {place.name}
                  </h3>
                  <p className="text-xs text-stone-200 mt-1 line-clamp-1">
                    {place.tagline}
                  </p>
                </div>
              </div>

              {/* Content Body */}
              <div className="p-5 space-y-4">
                <p className="text-xs text-stone-600 leading-relaxed">
                  {place.description}
                </p>

                {/* Entry Ticket Breakdown Table */}
                <div className="bg-rose-50/60 border border-rose-100 rounded-xl p-3.5 space-y-2 text-xs">
                  <h4 className="font-bold text-rose-950 flex items-center gap-1.5">
                    <Ticket className="w-4 h-4 text-rose-600" />
                    <span>Present Entry Ticket Pricing Breakdown:</span>
                  </h4>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <div className="bg-white p-2 rounded-lg border border-rose-100">
                      <span className="text-[10px] text-stone-500 block">General / Domestic</span>
                      <span className="font-bold text-stone-900 text-sm">
                        {place.ticket.isFree ? 'FREE' : `${place.ticket.currency}${place.ticket.generalPrice}`}
                      </span>
                    </div>

                    {place.ticket.foreignTouristPrice !== undefined && (
                      <div className="bg-white p-2 rounded-lg border border-rose-100">
                        <span className="text-[10px] text-stone-500 block">Foreign Tourist</span>
                        <span className="font-bold text-rose-800 text-sm">
                          {place.ticket.currency}{place.ticket.foreignTouristPrice}
                        </span>
                      </div>
                    )}

                    <div className="bg-white p-2 rounded-lg border border-rose-100">
                      <span className="text-[10px] text-stone-500 block">Children / Kids</span>
                      <span className="font-bold text-emerald-700 text-sm">
                        {place.ticket.childPrice === 0 ? 'FREE' : place.ticket.childPrice ? `${place.ticket.currency}${place.ticket.childPrice}` : 'Standard'}
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-stone-600 pt-1">
                    {place.ticket.ticketNotes || 'Tickets available on spot or via online booking portal.'}
                  </p>
                </div>

                {/* Timing Strip */}
                <div className="flex items-center justify-between text-xs bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                  <div className="flex items-center gap-1.5 text-stone-700 font-medium">
                    <Clock className="w-4 h-4 text-stone-500" />
                    <span>Operating Hours:</span>
                    <span className="font-bold text-stone-900">{place.timings.open} - {place.timings.close}</span>
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-700">
                    {place.timings.days}
                  </span>
                </div>

                {/* Crowd preview if available */}
                {place.crowd && (
                  <CrowdVisualizer crowd={place.crowd} placeName={place.name} isCompact={true} />
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-5 pt-0 grid grid-cols-2 gap-2">
              <button
                onClick={() => onShowOnMap(place)}
                className="py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Show on Map</span>
              </button>
              <button
                onClick={() => onSelectPlace(place)}
                className="py-2.5 px-3 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Full Details & Reviews</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
