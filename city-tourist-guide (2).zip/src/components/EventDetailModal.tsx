import React from 'react';
import { CityEvent } from '../types';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  Ticket, 
  Users, 
  Building2, 
  Sparkles, 
  Navigation, 
  Share2, 
  Check, 
  ExternalLink,
  PlusCircle
} from 'lucide-react';

interface EventDetailModalProps {
  event: CityEvent | null;
  isOpen: boolean;
  onClose: () => void;
  onShowOnMap: (event: CityEvent) => void;
  onAddToItinerary: (event: CityEvent) => void;
  onBookEvent?: (event: CityEvent) => void;
  isSavedInItinerary?: boolean;
}

export const EventDetailModal: React.FC<EventDetailModalProps> = ({
  event,
  isOpen,
  onClose,
  onShowOnMap,
  onAddToItinerary,
  onBookEvent,
  isSavedInItinerary = false,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !event) return null;

  const handleShare = () => {
    navigator.clipboard.writeText(
      `Check out "${event.title}" in ${event.locationName}! Timing: ${event.timing}, Date: ${event.date}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'festival':
        return 'bg-[#FFF9F0] text-[#C2410C] border-[#F3E5D8]';
      case 'concert':
        return 'bg-[#F4F1EA] text-[#5A5A40] border-[#DEDACF]';
      case 'exhibition':
        return 'bg-[#E9F2E9] text-[#4A6741] border-[#D0E2CF]';
      case 'food_fair':
        return 'bg-[#FFF9F0] text-[#D28E5D] border-[#F3E5D8]';
      case 'theatre_drama':
        return 'bg-[#F4F1EA] text-[#5A5A40] border-[#DEDACF]';
      default:
        return 'bg-[#F9F7F2] text-[#8B8B6B] border-[#E5E2D9]';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl space-y-0 my-auto text-[#3D3D3D]">
        
        {/* Header Media Banner */}
        <div className="relative h-64 sm:h-72 w-full bg-[#EAE7DC] overflow-hidden">
          <img
            src={event.image}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#2D2D2A] via-[#2D2D2A]/40 to-transparent" />

          {/* Close & Share Buttons */}
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              onClick={handleShare}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md transition-colors"
              title="Share event"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Category & Status Pill */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2 z-10">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#5A5A40] text-white shadow-xs uppercase tracking-wider">
              {event.category.replace('_', ' ')}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-white/90 text-[#2D2D2A] backdrop-blur-md">
              {event.status}
            </span>
          </div>

          {/* Event Title & Subtitle */}
          <div className="absolute bottom-4 left-4 right-4 text-white space-y-1">
            <h2 className="text-2xl sm:text-3xl font-bold font-serif leading-tight">
              {event.title}
            </h2>
            <div className="flex flex-wrap items-center gap-3 text-xs text-stone-200">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#D28E5D]" />
                <span>{event.locationName}</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-300" />
                <span>{event.timing}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          
          {/* Key Quick Info Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#F4F1EA] border border-[#DEDACF] p-3 rounded-2xl">
              <div className="flex items-center gap-1.5 text-xs text-[#8B8B6B] font-bold uppercase tracking-wider mb-1">
                <Calendar className="w-3.5 h-3.5 text-[#5A5A40]" />
                <span>Date</span>
              </div>
              <p className="text-xs font-bold text-[#2D2D2A]">{event.date}</p>
            </div>

            <div className="bg-[#F4F1EA] border border-[#DEDACF] p-3 rounded-2xl">
              <div className="flex items-center gap-1.5 text-xs text-[#8B8B6B] font-bold uppercase tracking-wider mb-1">
                <Ticket className="w-3.5 h-3.5 text-[#C2410C]" />
                <span>Admission</span>
              </div>
              <p className="text-xs font-bold text-[#2D2D2A]">
                {event.isFree ? 'Free Entry' : `${event.currency}${event.ticketPrice} per person`}
              </p>
            </div>

            <div className="bg-[#F4F1EA] border border-[#DEDACF] p-3 rounded-2xl">
              <div className="flex items-center gap-1.5 text-xs text-[#8B8B6B] font-bold uppercase tracking-wider mb-1">
                <Users className="w-3.5 h-3.5 text-[#4A6741]" />
                <span>Crowd Scale</span>
              </div>
              <p className="text-xs font-bold text-[#2D2D2A]">{event.expectedCrowd || 'Moderate'}</p>
            </div>

            <div className="bg-[#F4F1EA] border border-[#DEDACF] p-3 rounded-2xl">
              <div className="flex items-center gap-1.5 text-xs text-[#8B8B6B] font-bold uppercase tracking-wider mb-1">
                <Building2 className="w-3.5 h-3.5 text-[#5A5A40]" />
                <span>Host</span>
              </div>
              <p className="text-xs font-bold text-[#2D2D2A] truncate" title={event.organizer}>
                {event.organizer || 'City Tourism'}
              </p>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h3 className="font-serif font-bold text-base text-[#2D2D2A]">About This Event</h3>
            <p className="text-xs sm:text-sm text-[#3D3D3D] leading-relaxed">
              {event.description}
            </p>
          </div>

          {/* Event Highlights */}
          {event.highlights && event.highlights.length > 0 && (
            <div className="space-y-2.5">
              <h3 className="font-serif font-bold text-base text-[#2D2D2A] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#D28E5D]" />
                <span>Event Highlights & What to Expect</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {event.highlights.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white border border-[#E5E2D9] text-xs font-medium text-[#2D2D2A]"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#5A5A40] shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Location & Address Box */}
          <div className="bg-[#F9F7F2] border border-[#E5E2D9] p-4 rounded-2xl space-y-2">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B8B6B] block">
                  Venue & Address
                </span>
                <p className="font-bold text-xs sm:text-sm text-[#2D2D2A]">{event.locationName}</p>
                <p className="text-xs text-[#666] mt-0.5">{event.address}</p>
              </div>

              <button
                onClick={() => {
                  onShowOnMap(event);
                  onClose();
                }}
                className="px-3 py-1.5 bg-white hover:bg-[#F4F1EA] text-[#5A5A40] border border-[#DEDACF] text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shrink-0 shadow-2xs"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Show on Map</span>
              </button>
            </div>
          </div>

          {/* Tags */}
          {event.tags && (
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] font-bold text-[#8B8B6B] uppercase mr-1">Tags:</span>
              {event.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2.5 py-1 rounded-lg bg-[#EAE7DC] text-[#5A5A40] text-[11px] font-medium"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-[#F9F7F2] border-t border-[#E5E2D9] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#8B8B6B]">Admission:</span>
            <span className="text-sm font-bold text-[#2D2D2A]">
              {event.isFree ? 'Free Admission' : `${event.currency}${event.ticketPrice}`}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {onBookEvent && (
              <button
                onClick={() => onBookEvent(event)}
                className="px-4 py-2.5 bg-[#C2410C] hover:bg-[#9A3412] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-xs"
              >
                <Ticket className="w-4 h-4" />
                <span>Book Event Passes Directly</span>
              </button>
            )}

            <button
              onClick={() => onAddToItinerary(event)}
              className={`px-4 py-2.5 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-sm ${
                isSavedInItinerary
                  ? 'bg-[#E9F2E9] text-[#4A6741] border border-[#D0E2CF]'
                  : 'bg-[#5A5A40] hover:bg-[#454530] text-white'
              }`}
            >
              {isSavedInItinerary ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Added to Itinerary</span>
                </>
              ) : (
                <>
                  <PlusCircle className="w-4 h-4 text-amber-300" />
                  <span>Add to Daily Schedule</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
