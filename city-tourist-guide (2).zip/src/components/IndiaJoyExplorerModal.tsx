import React, { useState, useMemo } from 'react';
import { 
  ALL_INDIAN_STATES_AND_UTS, 
  StateInfo, 
  DistrictInfo, 
  convertDistrictToCity, 
  generatePlacesForDistrict 
} from '../data/indiaStatesAndDistricts';
import { City, Place } from '../types';
import { 
  Sparkles, 
  MapPin, 
  Search, 
  X, 
  Compass, 
  Film, 
  Landmark, 
  UtensilsCrossed, 
  Heart, 
  Check, 
  ChevronRight,
  Navigation,
  Globe
} from 'lucide-react';

interface IndiaJoyExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDistrict: (city: City, places: Place[]) => void;
  currentCityName?: string;
}

export const IndiaJoyExplorerModal: React.FC<IndiaJoyExplorerModalProps> = ({
  isOpen,
  onClose,
  onSelectDistrict,
  currentCityName,
}) => {
  const [selectedStateId, setSelectedStateId] = useState<string>('karnataka');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<'All' | 'State' | 'Union Territory'>('All');

  const selectedState = useMemo(() => {
    return ALL_INDIAN_STATES_AND_UTS.find((s) => s.id === selectedStateId) || ALL_INDIAN_STATES_AND_UTS[0];
  }, [selectedStateId]);

  // Filtered States list
  const filteredStates = useMemo(() => {
    return ALL_INDIAN_STATES_AND_UTS.filter((state) => {
      const matchType = filterType === 'All' || state.type === filterType;
      const matchQuery = state.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        state.districts.some(d => d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.tagline.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchType && matchQuery;
    });
  }, [searchQuery, filterType]);

  // Filtered districts within selected state (or across all if searching)
  const matchingDistricts = useMemo(() => {
    if (!searchQuery.trim()) {
      return selectedState.districts;
    }
    // If user is actively searching, return matching districts across all states
    const query = searchQuery.toLowerCase();
    const results: { district: DistrictInfo; stateName: string }[] = [];
    ALL_INDIAN_STATES_AND_UTS.forEach((st) => {
      st.districts.forEach((d) => {
        if (
          d.name.toLowerCase().includes(query) ||
          d.state.toLowerCase().includes(query) ||
          d.tagline.toLowerCase().includes(query) ||
          d.famousFood.some(f => f.toLowerCase().includes(query)) ||
          d.temples.some(t => t.toLowerCase().includes(query))
        ) {
          results.push({ district: d, stateName: st.name });
        }
      });
    });
    return results.map(r => r.district);
  }, [selectedState, searchQuery]);

  if (!isOpen) return null;

  const handlePickDistrict = (district: DistrictInfo) => {
    const city = convertDistrictToCity(district);
    const places = generatePlacesForDistrict(district);
    onSelectDistrict(city, places);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-[#FDFCF8] border-2 border-[#DEDACF] rounded-3xl w-full max-w-5xl overflow-hidden shadow-2xl space-y-0 my-auto text-[#2D2D2A] max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#5A5A40] text-white p-5 flex items-center justify-between border-b border-[#474732]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-400/20 border border-amber-300/30 rounded-2xl">
              <Compass className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif font-bold text-lg sm:text-xl">India Joy Explorer</h3>
                <span className="px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-200 text-[10px] font-bold uppercase tracking-wider">
                  28 States & 8 UTs
                </span>
              </div>
              <p className="text-xs text-[#DEDACF]">
                Find theatres, temples with crowd timings, iconic cuisines & scenic attractions in any district
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 bg-[#F4F1EA] border-b border-[#E5E2D9] flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search any state, district, famous food or temple (e.g. Mysuru, Belagavi, Ooty, Varanasi, Pune)..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {(['All', 'State', 'Union Territory'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                  filterType === type
                    ? 'bg-[#2D2D2A] text-white shadow-2xs'
                    : 'bg-white border border-[#DEDACF] text-[#5A5A40] hover:bg-[#EAE7DC]'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Content Body: Left States Sidebar + Right Districts Grid */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row min-h-[420px]">
          {/* Left States List */}
          <div className="w-full md:w-72 bg-[#F9F7F2] border-r border-[#E5E2D9] overflow-y-auto p-3 space-y-1 shrink-0 max-h-48 md:max-h-none">
            <div className="text-[11px] font-bold text-[#8B8B6B] px-3 py-1 uppercase tracking-wider">
              States & Territories ({filteredStates.length})
            </div>
            {filteredStates.map((st) => (
              <button
                key={st.id}
                onClick={() => {
                  setSelectedStateId(st.id);
                  setSearchQuery('');
                }}
                className={`w-full text-left px-3 py-2.5 rounded-2xl text-xs flex items-center justify-between transition-all ${
                  selectedStateId === st.id
                    ? 'bg-[#5A5A40] text-white font-bold shadow-xs'
                    : 'text-[#2D2D2A] hover:bg-[#EAE7DC]'
                }`}
              >
                <div className="truncate">
                  <div className="font-semibold truncate">{st.name}</div>
                  <div className={`text-[10px] truncate ${selectedStateId === st.id ? 'text-amber-200' : 'text-[#8B8B6B]'}`}>
                    {st.districts.length} Districts · {st.capital}
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 shrink-0 ${selectedStateId === st.id ? 'text-amber-300' : 'text-[#8B8B6B]'}`} />
              </button>
            ))}
          </div>

          {/* Right Districts & Joy Finder */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#FDFCF8] space-y-4">
            {/* State Banner */}
            <div className="p-4 bg-gradient-to-r from-[#F4F1EA] to-[#EAE7DC] border border-[#DEDACF] rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-serif font-bold text-lg text-[#2D2D2A]">
                    {selectedState.name}
                  </span>
                  <span className="text-[11px] font-semibold text-[#8B8B6B] bg-white px-2 py-0.5 rounded-md border border-[#DEDACF]">
                    {selectedState.type}
                  </span>
                </div>
                <p className="text-xs text-[#5A5A40] mt-0.5">
                  {selectedState.tagline}
                </p>
              </div>
              <div className="text-xs font-bold text-[#5A5A40] shrink-0">
                Capital: <span className="text-[#2D2D2A]">{selectedState.capital}</span>
              </div>
            </div>

            {/* Districts List Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#5A5A40]">
                  Districts & Joy Hubs ({matchingDistricts.length})
                </h4>
                <span className="text-[11px] text-[#8B8B6B]">Click any district to explore inside app</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {matchingDistricts.map((d) => {
                  const isCurrent = currentCityName?.toLowerCase().includes(d.name.toLowerCase()) || 
                                    d.name.toLowerCase().includes(currentCityName?.toLowerCase() || '');
                  return (
                    <div
                      key={d.id}
                      onClick={() => handlePickDistrict(d)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer text-left flex flex-col justify-between group relative overflow-hidden ${
                        isCurrent
                          ? 'bg-amber-50/70 border-amber-400 shadow-sm ring-1 ring-amber-400'
                          : 'bg-white border-[#E5E2D9] hover:border-[#5A5A40] hover:shadow-md'
                      }`}
                    >
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-[#D28E5D] shrink-0" />
                              <span className="font-serif font-bold text-sm text-[#2D2D2A] group-hover:text-amber-800 transition-colors">
                                {d.name}
                              </span>
                            </div>
                            <span className="text-[10px] text-[#8B8B6B] block">
                              {d.state}
                            </span>
                          </div>

                          {isCurrent && (
                            <span className="px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 text-[10px] font-bold flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              Active
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-[#5A5A40] line-clamp-2 leading-relaxed">
                          {d.tagline}
                        </p>

                        {/* Badges for Theatres, Temples, Food */}
                        <div className="space-y-1.5 pt-1 text-[11px]">
                          {d.theatres.length > 0 && (
                            <div className="flex items-center gap-1.5 text-[#5A5A40]">
                              <Film className="w-3 h-3 text-amber-600 shrink-0" />
                              <span className="truncate"><strong>Theatres:</strong> {d.theatres.slice(0, 2).join(', ')}</span>
                            </div>
                          )}

                          {d.temples.length > 0 && (
                            <div className="flex items-center gap-1.5 text-[#5A5A40]">
                              <Landmark className="w-3 h-3 text-amber-700 shrink-0" />
                              <span className="truncate"><strong>Temples:</strong> {d.temples.slice(0, 2).join(', ')}</span>
                            </div>
                          )}

                          {d.famousFood.length > 0 && (
                            <div className="flex items-center gap-1.5 text-[#5A5A40]">
                              <UtensilsCrossed className="w-3 h-3 text-orange-600 shrink-0" />
                              <span className="truncate"><strong>Food:</strong> {d.famousFood.slice(0, 2).join(', ')}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="mt-3 pt-2 border-t border-[#F0ECE1] flex items-center justify-between text-xs font-bold text-[#5A5A40] group-hover:text-[#2D2D2A]">
                        <span>Explore {d.name} →</span>
                        <span className="text-[10px] text-[#8B8B6B] font-normal">Best: {d.bestSeason}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#F4F1EA] border-t border-[#E5E2D9] flex items-center justify-between text-xs text-[#8B8B6B] px-6">
          <span>Created by <strong>jeevan m k</strong> for exploring joy across India</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white text-xs font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
