import React, { useState, useRef, useEffect } from 'react';
import { City, Place } from '../types';
import { 
  Bot, 
  Send, 
  X, 
  Sparkles, 
  Clock, 
  Film, 
  UtensilsCrossed, 
  Landmark, 
  Users, 
  Ticket, 
  CornerDownLeft,
  Loader2
} from 'lucide-react';

interface AIConciergeModalProps {
  city: City;
  places: Place[];
  isOpen: boolean;
  onClose: () => void;
  onSelectPlace?: (place: Place) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestions?: string[];
}

export const AIConciergeModal: React.FC<AIConciergeModalProps> = ({
  city,
  places,
  isOpen,
  onClose,
  onSelectPlace,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Hello traveler! I am your AI Tourist Concierge for **${city.name}**.\n\nYou can ask me about:\n- 🛕 **Peak crowd timings for temples** & how to avoid wait times\n- 🎬 **Current movies playing in nearby theatres** & ticket rates\n- 🍽️ **Highest rated signature dishes** & authentic food spots\n- 🎟️ **Attraction ticket prices**, opening timings & dress codes!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: [
        `What is the best time to visit temples with lowest crowd in ${city.name}?`,
        `Which restaurant has the most rated local dish?`,
        `What movies are currently playing in ${city.name} theatres?`,
        `What is the entry ticket price for top heritage sights?`
      ]
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cityName: city.name,
          query: textToSend,
          contextPlaces: places.map((p) => ({
            name: p.name,
            category: p.category,
            ticket: p.ticket,
            timings: p.timings,
            crowd: p.crowd ? {
              peakHours: p.crowd.peakHours,
              leastCrowdHours: p.crowd.leastCrowdHours,
              dressCode: p.dressCode
            } : undefined,
            topDishes: p.topDishes,
            movies: p.movies?.map((m) => ({ title: m.title, format: m.format, showtimes: m.showtimes }))
          })),
        }),
      });

      const data = await response.json();

      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: data.reply || data.fallback || "I'm happy to help you discover the city!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestions: data.suggestions || [
          `Show me free entry places in ${city.name}`,
          `Recommend a 1-day itinerary for ${city.name}`
        ]
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error('AI Concierge error:', error);
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        text: `For temples in ${city.name}, early afternoon (12:30 PM - 3:30 PM) is usually the least crowded. For movies, evening slots fill quickly. For food, check the 'Most Rated' badges in our restaurant directory!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white border border-stone-200 rounded-3xl w-full max-w-2xl h-[650px] max-h-[92vh] overflow-hidden shadow-2xl flex flex-col my-auto text-stone-900">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-900 to-indigo-950 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-400/30 rounded-xl">
              <Sparkles className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base font-display">AI Tourist Concierge</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/30 text-indigo-300 border border-indigo-400/30">
                  Powered by Gemini
                </span>
              </div>
              <p className="text-xs text-indigo-200">
                Live assistant for {city.name} crowd times, tickets, movies & food
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-stone-50/50 text-xs">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} space-y-1`}
            >
              <div className="flex items-center gap-1.5 px-1 text-[10px] text-stone-400">
                <span>{msg.sender === 'user' ? 'You' : 'AI Concierge'}</span>
                <span>•</span>
                <span>{msg.timestamp}</span>
              </div>

              <div
                className={`p-4 rounded-2xl max-w-[88%] leading-relaxed shadow-xs ${
                  msg.sender === 'user'
                    ? 'bg-stone-900 text-white rounded-tr-none'
                    : 'bg-white border border-stone-200 text-stone-800 rounded-tl-none space-y-2'
                }`}
              >
                <div className="whitespace-pre-line text-xs">{msg.text}</div>

                {/* AI Suggestions Chips */}
                {msg.suggestions && msg.suggestions.length > 0 && (
                  <div className="pt-2 border-t border-stone-100 space-y-1.5">
                    <span className="text-[10px] font-semibold text-stone-500 block">
                      Quick Questions:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {msg.suggestions.map((sug, sIdx) => (
                        <button
                          key={sIdx}
                          onClick={() => handleSend(sug)}
                          className="text-left px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-indigo-50 hover:text-indigo-900 border border-stone-200 text-[11px] text-stone-700 transition-colors"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 p-3 bg-white border border-stone-200 rounded-2xl w-fit text-stone-600">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              <span className="text-xs">Analyzing tourist database & crowd schedules...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3.5 bg-white border-t border-stone-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder={`Ask about temple crowds, movie showtimes, or food in ${city.name}...`}
              className="flex-1 px-4 py-2.5 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white focus:border-stone-900 focus:outline-hidden text-xs transition-colors"
            />
            <button
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="p-2.5 bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white rounded-xl transition-colors shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
