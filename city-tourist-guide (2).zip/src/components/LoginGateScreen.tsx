import React, { useState } from 'react';
import { UserAccount } from '../types';
import { ALL_INDIAN_STATES_AND_UTS } from '../data/indiaStatesAndDistricts';
import { 
  Compass, 
  MapPin, 
  Shield, 
  User, 
  UserPlus, 
  Lock, 
  Mail, 
  Phone, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Film, 
  Landmark, 
  UtensilsCrossed, 
  Heart,
  Globe
} from 'lucide-react';

interface LoginGateScreenProps {
  allUsers: UserAccount[];
  onLogin: (user: UserAccount) => void;
  onRegister: (userData: Omit<UserAccount, 'id' | 'joinedAt' | 'lastLoginAt' | 'bookingsCount' | 'totalSpent' | 'activityLogs'>) => void;
  onOpenAdminPortal: () => void;
}

export const LoginGateScreen: React.FC<LoginGateScreenProps> = ({
  allUsers,
  onLogin,
  onRegister,
  onOpenAdminPortal,
}) => {
  const [tabMode, setTabMode] = useState<'login' | 'signup' | 'admin'>('login');
  
  // Login form states (clean initial inputs for fresh visitors & shared URLs)
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Signup form states
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [signupError, setSignupError] = useState('');

  // Admin form states
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [adminError, setAdminError] = useState('');

  const totalDistrictsCount = ALL_INDIAN_STATES_AND_UTS.reduce(
    (acc, st) => acc + st.districts.length, 
    0
  );

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!loginEmail.trim() || !loginPassword.trim()) {
      setLoginError('Please enter your email and password');
      return;
    }

    const cleanEmail = loginEmail.trim().toLowerCase();
    const user = allUsers.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      setLoginError('Account not found with this email. Please check your spelling or create a new account.');
      return;
    }

    if (user.password && user.password !== loginPassword) {
      setLoginError('Incorrect password. For demo account use: user123');
      return;
    }

    onLogin(user);
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError('');

    if (!regName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setSignupError('Please fill in all required fields.');
      return;
    }

    const cleanEmail = regEmail.trim().toLowerCase();
    const existing = allUsers.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      setSignupError('An account with this email address already exists. Please sign in instead.');
      return;
    }

    onRegister({
      name: regName.trim(),
      email: cleanEmail,
      phone: regPhone.trim() || '+91 99000 00000',
      password: regPassword,
    });
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');

    if (adminPassword === '6867123') {
      onOpenAdminPortal();
    } else {
      setAdminError(
        'CAUTION: Permission Denied! This is a restricted Admin Page. Only the system administrator (jeevan m k) can log in on this page with his authorized password.'
      );
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F5EE] text-[#2D2D2A] flex flex-col justify-between selection:bg-amber-200 selection:text-amber-900">
      {/* Top Header */}
      <header className="border-b border-[#E5E2D9] bg-[#FDFCF8]/90 backdrop-blur-md px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#5A5A40] text-white flex items-center justify-center font-serif font-extrabold shadow-sm">
              <Compass className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <span className="font-serif font-bold text-base tracking-tight text-[#2D2D2A] block leading-tight">
                City Tourist Guide
              </span>
              <span className="text-[11px] text-[#8B8B6B] font-medium block">
                created by jeevan m k
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-[#8B8B6B] font-semibold hidden sm:inline-block">
              Tourist Account Required
            </span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 flex-1 flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-12 w-full">
        {/* Left Hero & India Joy Highlights */}
        <div className="w-full lg:w-1/2 space-y-6 text-left">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-100/70 border border-amber-300/80 text-amber-900 text-xs font-bold tracking-wide shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>All 28 States & 8 UTs of India · Find Your Joy</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-extrabold text-[#2D2D2A] leading-tight tracking-tight">
            Discover Joy in Every Corner of India & the World
          </h1>

          <p className="text-sm sm:text-base text-[#5A5A40] leading-relaxed max-w-xl">
            Welcome to your comprehensive tourist and joy guide. Explore every state and district across India—from sacred heritage temples with live crowd timings to laser cinemas, iconic regional delicacies, and scenic joy spots.
          </p>

          {/* Feature Highlights Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div className="p-3 bg-white border border-[#E5E2D9] rounded-2xl shadow-2xs">
              <Film className="w-5 h-5 text-amber-600 mb-1.5" />
              <div className="font-bold text-xs text-[#2D2D2A]">Theatres</div>
              <div className="text-[10px] text-[#8B8B6B]">Laser 4K & Recliners</div>
            </div>

            <div className="p-3 bg-white border border-[#E5E2D9] rounded-2xl shadow-2xs">
              <Landmark className="w-5 h-5 text-amber-700 mb-1.5" />
              <div className="font-bold text-xs text-[#2D2D2A]">Temples</div>
              <div className="text-[10px] text-[#8B8B6B]">Darshan & Crowd Hour</div>
            </div>

            <div className="p-3 bg-white border border-[#E5E2D9] rounded-2xl shadow-2xs">
              <UtensilsCrossed className="w-5 h-5 text-orange-600 mb-1.5" />
              <div className="font-bold text-xs text-[#2D2D2A]">Cuisines</div>
              <div className="text-[10px] text-[#8B8B6B]">Famous Local Feasts</div>
            </div>

            <div className="p-3 bg-white border border-[#E5E2D9] rounded-2xl shadow-2xs">
              <Heart className="w-5 h-5 text-rose-600 mb-1.5" />
              <div className="font-bold text-xs text-[#2D2D2A]">Attractions</div>
              <div className="text-[10px] text-[#8B8B6B]">Scenic Wonders & Joy</div>
            </div>
          </div>

          {/* Quick Coverage Pill */}
          <div className="p-3.5 bg-[#EAE7DC]/70 border border-[#DEDACF] rounded-2xl text-xs text-[#5A5A40] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#D28E5D] shrink-0" />
              <span>Covering <strong>36 States & UTs</strong> and <strong>{totalDistrictsCount}+ curated districts</strong></span>
            </div>
            <span className="font-bold text-[#2D2D2A] text-[11px]">Instant Joy Finder</span>
          </div>
        </div>

        {/* Right Authentication Card */}
        <div className="w-full lg:w-1/2 max-w-md">
          <div className="bg-[#FDFCF8] border-2 border-[#DEDACF] rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
            {/* Top Accent Ribbon */}
            <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-[#5A5A40] via-amber-600 to-[#5A5A40]" />

            {/* Tab Navigation */}
            <div className="flex p-1 bg-[#F4F1EA] rounded-2xl border border-[#E5E2D9] mb-6 gap-1">
              <button
                type="button"
                onClick={() => {
                  setTabMode('login');
                  setLoginError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                  tabMode === 'login'
                    ? 'bg-[#2D2D2A] text-white shadow-xs'
                    : 'text-[#5A5A40] hover:text-[#2D2D2A]'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTabMode('signup');
                  setSignupError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                  tabMode === 'signup'
                    ? 'bg-[#2D2D2A] text-white shadow-xs'
                    : 'text-[#5A5A40] hover:text-[#2D2D2A]'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>New Account</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTabMode('admin');
                  setAdminError('');
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                  tabMode === 'admin'
                    ? 'bg-amber-900 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-900 border border-amber-300/60 hover:bg-amber-100'
                }`}
                title="Restricted Admin Command Portal (jeevan m k)"
              >
                <Shield className="w-3.5 h-3.5 text-amber-500" />
                <span>Admin</span>
              </button>
            </div>

            {/* 1. SIGN IN FORM */}
            {tabMode === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4 text-left">
                <div>
                  <h2 className="text-xl font-serif font-bold text-[#2D2D2A]">Welcome Back</h2>
                  <p className="text-xs text-[#8B8B6B]">Sign in to access your city guides, itineraries & bookings</p>
                </div>

                {loginError && (
                  <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{loginError}</span>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="e.g. jeevankamate10@gmail.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showLoginPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                    >
                      {showLoginPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white text-xs font-bold rounded-2xl shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
                >
                  <span>Sign In & Open App</span>
                  <ArrowRight className="w-4 h-4 text-amber-400" />
                </button>
              </form>
            )}

            {/* 2. SIGN UP FORM */}
            {tabMode === 'signup' && (
              <form onSubmit={handleSignupSubmit} className="space-y-3.5 text-left">
                <div>
                  <h2 className="text-xl font-serif font-bold text-[#2D2D2A]">Create New Account</h2>
                  <p className="text-xs text-[#8B8B6B]">Register to save itineraries and book tickets</p>
                </div>

                {signupError && (
                  <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{signupError}</span>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. Jeevan Kamate"
                      className="w-full pl-10 pr-4 py-2 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="e.g. jeevankamate10@gmail.com"
                      className="w-full pl-10 pr-4 py-2 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Phone Number</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+91 99001 23456"
                      className="w-full pl-10 pr-4 py-2 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Set Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Create a password"
                      className="w-full pl-10 pr-10 py-2 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40] shadow-inner"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                    >
                      {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#5A5A40] hover:bg-[#474732] text-white text-xs font-bold rounded-2xl shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4 text-amber-300" />
                  <span>Create Account & Enter App</span>
                </button>
              </form>
            )}

            {/* 3. ADMIN ACCESS FORM */}
            {tabMode === 'admin' && (
              <form onSubmit={handleAdminSubmit} className="space-y-4 text-left">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-serif font-bold text-[#2D2D2A]">Admin Command Portal</h2>
                    <p className="text-xs text-amber-800 font-semibold">Authorized Administrator: jeevan m k</p>
                  </div>
                </div>

                {adminError && (
                  <div className="p-4 rounded-2xl bg-rose-50 border-2 border-rose-300 text-rose-900 text-xs font-semibold flex items-start gap-3 shadow-xs">
                    <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <div className="font-bold uppercase tracking-wider text-[10px] text-rose-700">Access Restricted</div>
                      <div className="leading-relaxed">{adminError}</div>
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#5A5A40]">Administrator Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showAdminPassword ? 'text' : 'password'}
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      placeholder="Enter administrator password"
                      className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#DEDACF] rounded-2xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-amber-600 shadow-inner font-mono tracking-wider text-center"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPassword(!showAdminPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                    >
                      {showAdminPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-amber-900 hover:bg-amber-950 text-white text-xs font-bold rounded-2xl shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
                >
                  <Shield className="w-4 h-4 text-amber-400" />
                  <span>Verify Administrator & Open Portal</span>
                </button>

                <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 text-[11px] text-amber-900 text-center">
                  Restricted access for creator and administrator <strong className="font-bold">jeevan m k</strong>
                </div>
              </form>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#E5E2D9] py-3 text-center text-xs text-[#8B8B6B]">
        City Tourist Guide & Joy Finder · All 28 States & 8 Union Territories · created by jeevan m k
      </footer>
    </div>
  );
};
