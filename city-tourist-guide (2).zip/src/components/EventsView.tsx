import React, { useState, useMemo } from 'react';
import { CityEvent, City, EventCategory } from '../types';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Ticket, 
  Sparkles, 
  Search, 
  SlidersHorizontal, 
  Navigation, 
  PlusCircle, 
  Check, 
  Users, 
  PartyPopper, 
  Music, 
  Palette, 
  UtensilsCrossed, 
  Drama, 
  Compass
} from 'lucide-react';

interface EventsViewProps {
  city: City;
  events: CityEvent[];
  onSelectEvent: (event: CityEvent) => void;
  onShowOnMap: (event: CityEvent) => void;
  onAddToItinerary: (event: CityEvent) => void;
  onBookEvent?: (event: CityEvent) => void;
  itineraryEventIds?: string[];
}

export const EventsView: React.FC<EventsViewProps> = ({
  city,
  events,
  onSelectEvent,
  onShowOnMap,
  onAddToItinerary,
  onBookEvent,
  itineraryEventIds = [],
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTimeframe, setSelectedTimeframe] = useState<'all' | 'today' | 'weekend' | 'upcoming'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Events', icon: PartyPopper },
    { id: 'cultural_ritual', label: 'Cultural & Rituals', icon: Sparkles },
    { id: 'festival', label: 'Festivals', icon: PartyPopper },
    { id: 'concert', label: 'Music & Concerts', icon: Music },
    { id: 'exhibition', label: 'Exhibitions & Art', icon: Palette },
    { id: 'food_fair', label: 'Food & Night Fairs', icon: UtensilsCrossed },
    { id: 'theatre_drama', label: 'Theatre & Cinema', icon: Drama },
  ];

  const timeframes = [
    { id: 'all', label: 'All Dates' },
    { id: 'today', label: '⚡ Happening Today' },
    { id: 'weekend', label: '📅 This Weekend' },
    { id: 'upcoming', label: '🌟 Upcoming' },
  ];

  const filteredEvents = useMemo(() => {
    return events.filter((event) => {
      // Search match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = event.title.toLowerCase().includes(q);
        const matchesDesc = event.description.toLowerCase().includes(q);
        const matchesLoc = event.locationName.toLowerCase().includes(q);
        const matchesTags = event.tags?.some((t) => t.toLowerCase().includes(q));
        if (!matchesTitle && !matchesDesc && !matchesLoc && !matchesTags) return false;
      }

      // Timeframe filter
      if (selectedTimeframe === 'today' && event.status !== 'Happening Today') return false;
      if (selectedTimeframe === 'weekend' && event.status !== 'This Weekend') return false;
      if (selectedTimeframe === 'upcoming' && event.status !== 'Upcoming' && event.status !== 'Annual Festival') return false;

      // Category filter
      if (selectedCategory !== 'all' && event.category !== selectedCategory) return false;

      return true;
    });
  }, [events, searchQuery, selectedTimeframe, selectedCategory]);

  return (
    <div id="events-near-me-section" className="space-y-6">
      
      {/* Top Banner Header in Natural Tones */}
      <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 z-10 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#5A5A40] text-white flex items-center gap-1.5 uppercase tracking-wider">
              <PartyPopper className="w-3.5 h-3.5" />
              <span>Events Near Me</span>
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-white text-[#5A5A40] border border-[#DEDACF]">
              {city.name} Cultural Calendar
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-[#2D2D2A]">
            Current & Upcoming Events in {city.name}
          </h2>
          <p className="text-xs sm:text-sm text-[#5A5A40] leading-relaxed">
            Discover live traditional aartis, sacred concerts, artisan handloom expos, open-air cinema nights, and authentic street food carnivals happening right now.
          </p>
        </div>

        {/* Local Tip Card */}
        <div className="bg-white/80 backdrop-blur-md border border-[#DEDACF] p-4 rounded-2xl max-w-xs shrink-0 space-y-1 shadow-2xs z-10">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B8B6B] block">
            💡 Local Event Tip
          </span>
          <p className="text-xs text-[#3D3D3D] italic leading-relaxed">
            "Evening ghat rituals & temple illuminations draw peak crowds between 18:00 - 19:30. Arrive 30 minutes early for front-row views!"
          </p>
        </div>
      </div>

      {/* Controls Bar: Search & Category Chips */}
      <div className="space-y-3">
        {/* Search & Timeframe selector */}
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search events, concerts or festivals in ${city.name}...`}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#DEDACF] bg-white text-xs font-medium text-[#2D2D2A] placeholder:text-[#8B8B6B] focus:outline-hidden focus:border-[#5A5A40] focus:ring-1 focus:ring-[#5A5A40] transition-colors"
            />
            <Search className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-3" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-xs text-[#8B8B6B] hover:text-[#2D2D2A] font-medium"
              >
                Clear
              </button>
            )}
          </div>

          {/* Timeframe Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {timeframes.map((tf) => (
              <button
                key={tf.id}
                onClick={() => setSelectedTimeframe(tf.id as any)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedTimeframe === tf.id
                    ? 'bg-[#5A5A40] text-white shadow-xs'
                    : 'bg-white text-[#5A5A40] border border-[#DEDACF] hover:bg-[#F9F7F2]'
                }`}
              >
                {tf.label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-[#2D2D2A] text-white shadow-xs'
                    : 'bg-white text-[#3D3D3D] border border-[#E5E2D9] hover:bg-[#F4F1EA]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-300' : 'text-[#8B8B6B]'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Events Grid */}
      {filteredEvents.length === 0 ? (
        <div className="p-12 text-center bg-white border border-[#E5E2D9] rounded-3xl space-y-3">
          <Calendar className="w-10 h-10 text-[#8B8B6B] mx-auto" />
          <h3 className="font-serif font-bold text-base text-[#2D2D2A]">No events match your criteria</h3>
          <p className="text-xs text-[#8B8B6B] max-w-sm mx-auto">
            Try adjusting your search query or switching to "All Events" to explore all happenings in {city.name}.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedTimeframe('all');
              setSelectedCategory('all');
            }}
            className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl text-xs font-semibold hover:bg-[#454530] transition-colors"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((event) => {
            const isSaved = itineraryEventIds.includes(event.id);

            return (
              <div
                key={event.id}
                className="bg-white border border-[#E5E2D9] hover:border-[#8B8B6B] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between group text-[#3D3D3D]"
              >
                <div>
                  {/* Event Media Banner */}
                  <div className="relative h-48 w-full bg-[#EAE7DC] overflow-hidden">
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                    {/* Status & Category Badge */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#5A5A40] text-white shadow-xs uppercase tracking-wider">
                        {event.category.replace('_', ' ')}
                      </span>
                    </div>

                    {/* Admission Price Tag */}
                    <div className="absolute top-3 right-3">
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/95 text-[#2D2D2A] backdrop-blur-md shadow-xs">
                        {event.isFree ? 'FREE' : `${event.currency}${event.ticketPrice}`}
                      </span>
                    </div>

                    {/* Status Label on Banner Bottom */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
                      <span className="font-bold flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-amber-300" />
                        <span>{event.status}</span>
                      </span>
                      <span className="text-[11px] text-stone-200">{event.timing}</span>
                    </div>
                  </div>

                  {/* Event Details Content */}
                  <div className="p-5 space-y-3">
                    <div>
                      <h3
                        onClick={() => onSelectEvent(event)}
                        className="font-serif font-bold text-lg text-[#2D2D2A] group-hover:text-[#5A5A40] cursor-pointer transition-colors line-clamp-1"
                      >
                        {event.title}
                      </h3>
                      <p className="text-xs text-[#666] line-clamp-2 mt-1 leading-relaxed">
                        {event.description}
                      </p>
                    </div>

                    {/* Venue & Date Strip */}
                    <div className="space-y-1.5 pt-1 text-xs text-[#3D3D3D]">
                      <div className="flex items-center gap-2 text-xs">
                        <MapPin className="w-3.5 h-3.5 text-[#D28E5D] shrink-0" />
                        <span className="font-medium truncate">{event.locationName}</span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-[#8B8B6B]">
                        <Clock className="w-3.5 h-3.5 text-[#5A5A40] shrink-0" />
                        <span>{event.date}</span>
                      </div>
                    </div>

                    {/* Highlights tags */}
                    {event.highlights && event.highlights.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-1">
                        {event.highlights.slice(0, 2).map((hl, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-md bg-[#F4F1EA] text-[#5A5A40] text-[10px] font-medium border border-[#DEDACF]"
                          >
                            ✓ {hl}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="p-4 bg-[#F9F7F2] border-t border-[#E5E2D9] flex flex-wrap items-center justify-between gap-2">
                  <button
                    onClick={() => onShowOnMap(event)}
                    className="p-2 rounded-xl bg-white hover:bg-[#F4F1EA] text-[#5A5A40] border border-[#DEDACF] text-xs font-semibold flex items-center gap-1 transition-colors"
                    title="View on Map"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Map</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {onBookEvent && (
                      <button
                        onClick={() => onBookEvent(event)}
                        className="px-3 py-1.5 bg-[#C2410C] hover:bg-[#9A3412] text-white text-xs font-bold rounded-xl flex items-center gap-1 transition-all shadow-2xs"
                      >
                        <Ticket className="w-3 h-3" />
                        <span>Book Passes</span>
                      </button>
                    )}

                    <button
                      onClick={() => onSelectEvent(event)}
                      className="px-3 py-1.5 text-xs font-bold text-[#5A5A40] hover:text-[#2D2D2A] hover:bg-[#EAE7DC] rounded-xl transition-colors"
                    >
                      Details
                    </button>

                    <button
                      onClick={() => onAddToItinerary(event)}
                      className={`px-3 py-1.5 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-2xs ${
                        isSaved
                          ? 'bg-[#E9F2E9] text-[#4A6741] border border-[#D0E2CF]'
                          : 'bg-[#5A5A40] hover:bg-[#454530] text-white'
                      }`}
                    >
                      {isSaved ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <PlusCircle className="w-3.5 h-3.5 text-amber-300" />
                          <span>Add to Plan</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
