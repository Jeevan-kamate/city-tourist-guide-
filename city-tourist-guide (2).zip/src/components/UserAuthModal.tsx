import React, { useState } from 'react';
import { 
  X, 
  User, 
  Mail, 
  Phone, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  CheckCircle2, 
  LogOut, 
  Receipt, 
  Sparkles,
  UserPlus,
  LogIn,
  Shield,
  Clock
} from 'lucide-react';
import { UserAccount } from '../types';

interface UserAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount | null;
  onLogin: (user: UserAccount) => void;
  onLogout: () => void;
  onRegister: (newUser: Omit<UserAccount, 'id' | 'joinedAt' | 'lastLoginAt' | 'bookingsCount' | 'totalSpent' | 'activityLogs'>) => UserAccount;
  allUsers?: UserAccount[];
  registeredUsers?: UserAccount[];
  onOpenMyBookings?: () => void;
  onOpenAdminPortal?: () => void;
}

export const UserAuthModal: React.FC<UserAuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLogin,
  onLogout,
  onRegister,
  allUsers: propAllUsers,
  registeredUsers,
  onOpenMyBookings,
  onOpenAdminPortal,
}) => {
  const allUsers = propAllUsers || registeredUsers || [];
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanIdentifier = email.trim().toLowerCase();
    const cleanPhone = phone.trim();

    if (!cleanIdentifier && !cleanPhone) {
      setError('Please enter your email or phone number');
      return;
    }
    if (!password.trim()) {
      setError('Please enter your password');
      return;
    }

    // Match in registered users
    const matchedUser = allUsers.find(
      (u) =>
        (cleanIdentifier && u.email.toLowerCase() === cleanIdentifier) ||
        (cleanPhone && u.phone === cleanPhone) ||
        (cleanIdentifier && u.phone === cleanIdentifier)
    );

    if (matchedUser) {
      if (matchedUser.password && matchedUser.password !== password) {
        setError('Incorrect password. Please try again.');
        return;
      }

      onLogin(matchedUser);
      setSuccessMessage(`Welcome back, ${matchedUser.name}!`);
      setTimeout(() => {
        setSuccessMessage(null);
        onClose();
      }, 1000);
    } else {
      // Auto-create user if not found or prompt signup
      setError('No account found with this email/phone. Please sign up below.');
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Please enter your full name');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    if (!phone.trim() || phone.replace(/\D/g, '').length < 8) {
      setError('Please enter a valid phone number');
      return;
    }
    if (password.length < 4) {
      setError('Password should be at least 4 characters long');
      return;
    }

    const existing = allUsers.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase()
    );
    if (existing) {
      setError('An account with this email already exists. Please log in.');
      return;
    }

    const newUser = onRegister({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      password: password,
    });

    setSuccessMessage(`Account created! Welcome, ${newUser.name}!`);
    setTimeout(() => {
      setSuccessMessage(null);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-md bg-[#FDFCF8] rounded-3xl overflow-hidden shadow-2xl border border-[#E5E2D9] my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-6 bg-[#2D2D2A] text-white relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <User className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[10px] font-bold tracking-wider text-amber-300 uppercase">
                Tourist Guide Account
              </div>
              <h2 className="text-xl font-serif font-bold">
                {currentUser ? 'Your Profile' : authMode === 'login' ? 'User Login' : 'Create New Account'}
              </h2>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {successMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-medium">
              {error}
            </div>
          )}

          {/* IF ALREADY LOGGED IN: Show Profile & Stats */}
          {currentUser ? (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#F4F1EA] border border-[#E5E2D9] space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-[#5A5A40] text-white flex items-center justify-center font-bold text-lg">
                      {currentUser.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-sm text-[#2D2D2A]">{currentUser.name}</div>
                      <div className="text-xs text-[#8B8B6B]">{currentUser.email}</div>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                    Active User
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#E5E2D9] text-xs">
                  <div>
                    <span className="text-[#8B8B6B] block text-[10px]">Phone</span>
                    <span className="font-semibold text-[#2D2D2A]">{currentUser.phone || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-[#8B8B6B] block text-[10px]">Bookings Made</span>
                    <span className="font-semibold text-[#5A5A40]">{currentUser.bookingsCount} Passes</span>
                  </div>
                </div>
              </div>

              {/* Recent Activity List */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-[#5A5A40] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Recent Account Activity</span>
                </div>
                <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1 text-xs">
                  {currentUser.activityLogs && currentUser.activityLogs.length > 0 ? (
                    currentUser.activityLogs.slice(0, 5).map((log) => (
                      <div key={log.id} className="p-2 rounded-xl bg-white border border-[#E5E2D9] flex items-center justify-between gap-2">
                        <div>
                          <div className="font-medium text-[#2D2D2A]">{log.action}</div>
                          {log.itemTitle && <div className="text-[10px] text-[#8B8B6B]">{log.itemTitle}</div>}
                        </div>
                        <span className="text-[10px] text-[#8B8B6B] shrink-0">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-3 text-xs text-[#8B8B6B] bg-[#F4F1EA] rounded-xl">
                      No recent activity recorded yet.
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                {onOpenMyBookings && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenMyBookings();
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#5A5A40] hover:bg-[#484832] text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                  >
                    <Receipt className="w-4 h-4" />
                    <span>View My Tickets & Passes</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    onLogout();
                    setSuccessMessage('Logged out successfully');
                    setTimeout(() => setSuccessMessage(null), 1000);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-rose-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors border border-[#DEDACF]"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out of Account</span>
                </button>
              </div>
            </div>
          ) : (
            /* IF NOT LOGGED IN: Show Login or Signup Form */
            <div className="space-y-4">
              {/* Tab Switcher */}
              <div className="flex p-1 bg-[#F4F1EA] rounded-2xl border border-[#E5E2D9] gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                    authMode === 'login'
                      ? 'bg-white text-[#2D2D2A] shadow-xs'
                      : 'text-[#8B8B6B] hover:text-[#2D2D2A]'
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('signup');
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
                    authMode === 'signup'
                      ? 'bg-white text-[#2D2D2A] shadow-xs'
                      : 'text-[#8B8B6B] hover:text-[#2D2D2A]'
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>New Account</span>
                </button>
                {onOpenAdminPortal && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenAdminPortal();
                    }}
                    className="flex-1 py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all bg-amber-50/80 hover:bg-amber-100 text-amber-900 border border-amber-300/60 shadow-2xs"
                    title="Switch to Admin Command Portal (jeevan m k)"
                  >
                    <Shield className="w-3.5 h-3.5 text-amber-600" />
                    <span>Admin</span>
                  </button>
                )}
              </div>

              {/* Login Form */}
              {authMode === 'login' ? (
                <form onSubmit={handleLogin} className="space-y-3.5">
                  <div>
                    <label className="block text-[11px] font-bold text-[#5A5A40] mb-1">
                      Email or Mobile Number
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="e.g. jeevankamate10@gmail.com or phone"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#5A5A40] mb-1">
                      Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#5A5A40] hover:bg-[#484832] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
                  >
                    <span>Sign In to Tourist Guide</span>
                    <ArrowRight className="w-4 h-4 text-amber-300" />
                  </button>

                  <div className="pt-2 border-t border-[#E5E2D9] text-center">
                    <p className="text-[11px] text-[#7A7A65]">
                      Demo Account: <span className="font-mono font-semibold text-[#2D2D2A]">jeevankamate10@gmail.com</span> · Password: <span className="font-mono font-semibold text-[#2D2D2A]">user123</span>
                    </p>
                  </div>

                  {/* Side Admin Access Banner */}
                  {onOpenAdminPortal && (
                    <div className="p-3 bg-amber-50/80 rounded-2xl border border-amber-200/80 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-left">
                        <div className="w-7 h-7 rounded-lg bg-amber-200/60 flex items-center justify-center text-amber-800 shrink-0">
                          <Shield className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-[11px] font-bold text-amber-900">Admin Command Portal</div>
                          <div className="text-[10px] text-amber-700">Restricted for jeevan m k</div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenAdminPortal();
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white text-[11px] font-bold transition-colors shrink-0 flex items-center gap-1 shadow-2xs"
                      >
                        <span>Open Admin</span>
                        <ArrowRight className="w-3 h-3 text-amber-400" />
                      </button>
                    </div>
                  )}
                </form>
              ) : (
                /* Registration Form */
                <form onSubmit={handleSignUp} className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#5A5A40] mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="e.g. Jeevan M K"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#5A5A40] mb-1">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        placeholder="e.g. jeevankamate10@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#5A5A40] mb-1">
                      Mobile Number
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="tel"
                        placeholder="+91 98765 43210"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#5A5A40] mb-1">
                      Create Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-[#8B8B6B] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Create a password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#5A5A40] hover:bg-[#484832] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
                  >
                    <span>Register New Account</span>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
