import React, { useState } from 'react';
import { Place, Review } from '../types';
import { Star, X, Check, MessageSquare, ThumbsUp, Sparkles } from 'lucide-react';

interface WriteReviewModalProps {
  place: Place;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReview: (placeId: string, review: Review) => void;
}

export const WriteReviewModal: React.FC<WriteReviewModalProps> = ({
  place,
  isOpen,
  onClose,
  onSubmitReview,
}) => {
  const [userName, setUserName] = useState('');
  const [userLocation, setUserLocation] = useState('');
  const [userType, setUserType] = useState<string>('Solo Traveler');
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState('');
  const [crowdExperience, setCrowdExperience] = useState<string>('Moderate');
  const [recommendedItem, setRecommendedItem] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !comment.trim()) return;

    const newReview: Review = {
      id: `rev-${Date.now()}`,
      userName: userName.trim(),
      userLocation: userLocation.trim() || 'Tourist',
      userType,
      rating,
      date: 'Just now',
      comment: comment.trim(),
      helpfulCount: 0,
      crowdExperience: crowdExperience as any,
      recommendedItem: recommendedItem.trim() || undefined,
      verifiedVisit: true,
    };

    onSubmitReview(place.id, newReview);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-stone-200 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl space-y-4">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-stone-100">
          <div>
            <h3 className="font-bold text-base text-stone-900">
              Write a Tourist Review
            </h3>
            <p className="text-xs text-stone-500">
              Share your genuine feedback for <strong>{place.name}</strong>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-400 hover:text-stone-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 pt-0 space-y-4 text-xs">
          {/* Star Rating Selector */}
          <div className="space-y-1.5">
            <label className="font-semibold text-stone-800 block">Overall Rating:</label>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="p-1 text-2xl focus:outline-hidden transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-7 h-7 ${
                      (hoverRating || rating) >= star
                        ? 'fill-amber-400 text-amber-500'
                        : 'text-stone-300'
                    }`}
                  />
                </button>
              ))}
              <span className="font-bold text-stone-700 text-sm ml-2">
                {rating} of 5 Stars
              </span>
            </div>
          </div>

          {/* Name & Origin */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-stone-700 block mb-1">Your Name *</label>
              <input
                type="text"
                required
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="e.g. Sophie M."
                className="w-full px-3 py-2 rounded-xl border border-stone-200 focus:border-stone-800 focus:outline-hidden bg-stone-50"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700 block mb-1">Your City / Country</label>
              <input
                type="text"
                value={userLocation}
                onChange={(e) => setUserLocation(e.target.value)}
                placeholder="e.g. London, UK"
                className="w-full px-3 py-2 rounded-xl border border-stone-200 focus:border-stone-800 focus:outline-hidden bg-stone-50"
              />
            </div>
          </div>

          {/* Tourist Traveler Profile */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-stone-700 block mb-1">Traveler Type</label>
              <select
                value={userType}
                onChange={(e) => setUserType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 focus:border-stone-800 focus:outline-hidden bg-stone-50 text-xs"
              >
                <option value="Solo Traveler">Solo Backpacker</option>
                <option value="Family Vacation">Family with Kids</option>
                <option value="Couple">Couple / Duo</option>
                <option value="Food Enthusiast">Food Enthusiast</option>
                <option value="Local Resident">Local Resident</option>
              </select>
            </div>
            <div>
              <label className="font-semibold text-stone-700 block mb-1">Crowd Experienced</label>
              <select
                value={crowdExperience}
                onChange={(e) => setCrowdExperience(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 focus:border-stone-800 focus:outline-hidden bg-stone-50 text-xs"
              >
                <option value="Low">Low / Easy Access</option>
                <option value="Moderate">Moderate / Tolerable</option>
                <option value="High">High / 20-30m Queue</option>
                <option value="Peak">Heavy Peak Rush</option>
              </select>
            </div>
          </div>

          {/* Highlighted Dish or Tip */}
          <div>
            <label className="font-semibold text-stone-700 block mb-1">
              Highlight / Most-Rated Dish / Tip for New Tourists:
            </label>
            <input
              type="text"
              value={recommendedItem}
              onChange={(e) => setRecommendedItem(e.target.value)}
              placeholder="e.g. Try the Tamatar Chaat, or visit at 3 PM for zero waiting"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 focus:border-stone-800 focus:outline-hidden bg-stone-50"
            />
          </div>

          {/* Review Text */}
          <div>
            <label className="font-semibold text-stone-700 block mb-1">Detailed Review *</label>
            <textarea
              required
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Describe your experience, queue timings, ticket ease, food quality, or atmosphere..."
              className="w-full px-3 py-2 rounded-xl border border-stone-200 focus:border-stone-800 focus:outline-hidden bg-stone-50 resize-none"
            />
          </div>

          {/* Submit Button */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Check className="w-4 h-4" />
              <span>Post Review</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
