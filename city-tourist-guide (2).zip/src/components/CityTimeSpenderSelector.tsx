import React from 'react';
import { Film, Sparkles, UtensilsCrossed, Landmark, CheckCircle2, ArrowRight } from 'lucide-react';
import { AppViewMode } from './Navbar';

interface CityTimeSpenderSelectorProps {
  cityName: string;
  theatreCount: number;
  templeCount: number;
  restaurantCount: number;
  attractionCount: number;
  activeView: AppViewMode;
  onSelectOption: (option: 'theatre' | 'temple' | 'restaurant' | 'attraction' | 'all') => void;
}

export const CityTimeSpenderSelector: React.FC<CityTimeSpenderSelectorProps> = ({
  cityName,
  theatreCount,
  templeCount,
  restaurantCount,
  attractionCount,
  activeView,
  onSelectOption,
}) => {
  const options = [
    {
      id: 'theatre' as const,
      title: 'Theatres',
      subtitle: '4K Laser, Dolby Atmos & Live Movie Showtimes',
      count: theatreCount,
      countLabel: 'Cinemas',
      icon: Film,
      bgActive: 'bg-[#2D2D2A] text-white border-[#2D2D2A]',
      accentBg: 'bg-indigo-500/20 text-indigo-300',
      badgeColor: 'bg-indigo-100 text-indigo-900 border-indigo-200',
      preview: 'Watch Kalki 2898 AD, Stree 2 & Regional Hits',
    },
    {
      id: 'temple' as const,
      title: 'Temples',
      subtitle: 'Sacred Darshans, Live Crowd Radar & Aarti Times',
      count: templeCount,
      countLabel: 'Shrines',
      icon: Sparkles,
      bgActive: 'bg-[#5A5A40] text-white border-[#5A5A40]',
      accentBg: 'bg-amber-400/20 text-amber-300',
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-200',
      preview: 'Darshan queue status, dress code & VIP tokens',
    },
    {
      id: 'restaurant' as const,
      title: 'Restaurants',
      subtitle: 'Iconic Regional Delicacies, Sweets & Thalis',
      count: restaurantCount,
      countLabel: 'Eateries',
      icon: UtensilsCrossed,
      bgActive: 'bg-[#C2410C] text-white border-[#C2410C]',
      accentBg: 'bg-orange-500/20 text-orange-200',
      badgeColor: 'bg-orange-100 text-orange-900 border-orange-200',
      preview: 'Authentic local dishes, sweets & dining tables',
    },
    {
      id: 'attraction' as const,
      title: 'Tourist Spots',
      subtitle: 'Scenic Waterfalls, Historic Forts & Heritage Sights',
      count: attractionCount,
      countLabel: 'Spots',
      icon: Landmark,
      bgActive: 'bg-[#3F5A36] text-white border-[#3F5A36]',
      accentBg: 'bg-emerald-500/20 text-emerald-200',
      badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-200',
      preview: 'Entry tickets, photography spots & nature trails',
    },
  ];

  return (
    <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E2D9]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-[#F4F1EA] text-[#5A5A40] border border-[#DEDACF]">
              Explore Options
            </span>
            <h2 className="font-serif font-bold text-lg sm:text-xl text-[#2D2D2A]">
              Where would you like to spend your time in {cityName}?
            </h2>
          </div>
          <p className="text-xs text-[#8B8B6B] mt-1">
            Choose from the 4 primary categories below to view its complete list separately:
          </p>
        </div>

        {/* View All button */}
        <button
          onClick={() => onSelectOption('all')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 ${
            activeView === 'all'
              ? 'bg-[#2D2D2A] text-white shadow-xs'
              : 'bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#5A5A40] border border-[#DEDACF]'
          }`}
        >
          <span>View All 4 Categories Together</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 4 Interactive Option Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {options.map((opt) => {
          const Icon = opt.icon;
          const isSelected = activeView === opt.id;

          return (
            <div
              key={opt.id}
              id={`option-card-${opt.id}`}
              onClick={() => onSelectOption(opt.id)}
              className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between text-left relative group ${
                isSelected
                  ? `${opt.bgActive} shadow-md scale-[1.01]`
                  : 'bg-white border-[#E5E2D9] hover:border-[#8B8B6B] hover:shadow-xs'
              }`}
            >
              {/* Top Row: Icon & Count */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                      isSelected
                        ? opt.accentBg
                        : 'bg-[#F4F1EA] text-[#5A5A40] group-hover:bg-[#EAE7DC]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                      isSelected
                        ? 'bg-white/20 text-white border-white/30'
                        : opt.badgeColor
                    }`}
                  >
                    {opt.count} {opt.countLabel}
                  </span>
                </div>

                {/* Option Title & Subtitle */}
                <h3
                  className={`font-serif font-bold text-base ${
                    isSelected ? 'text-white' : 'text-[#2D2D2A]'
                  }`}
                >
                  {opt.title} List
                </h3>

                <p
                  className={`text-xs mt-1 leading-relaxed ${
                    isSelected ? 'text-white/80' : 'text-[#5A5A40]'
                  }`}
                >
                  {opt.subtitle}
                </p>
              </div>

              {/* Bottom Action Hint */}
              <div
                className={`mt-4 pt-2.5 border-t text-xs font-bold flex items-center justify-between ${
                  isSelected
                    ? 'border-white/20 text-amber-300'
                    : 'border-[#F4F1EA] text-[#5A5A40] group-hover:text-[#2D2D2A]'
                }`}
              >
                <span>{isSelected ? '✓ Currently Viewing' : `Open ${opt.title} List`}</span>
                <ArrowRight className={`w-3.5 h-3.5 ${isSelected ? 'translate-x-0.5' : 'group-hover:translate-x-1'} transition-transform`} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
