import React, { useState } from 'react';
import { Place } from '../types';
import { 
  Sparkles, 
  Users, 
  Clock, 
  Ticket, 
  AlertTriangle, 
  ShieldCheck, 
  MapPin, 
  Info, 
  Sun, 
  Moon, 
  CheckCircle2,
  Calendar,
  Compass,
  ArrowRight
} from 'lucide-react';
import { CrowdVisualizer } from './CrowdVisualizer';

interface TemplesViewProps {
  temples: Place[];
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
  onAddToItinerary?: (place: Place) => void;
  onBookDirectly?: (target: { place: Place; category: 'temple' }) => void;
}

export const TemplesView: React.FC<TemplesViewProps> = ({
  temples,
  onSelectPlace,
  onShowOnMap,
  onAddToItinerary,
  onBookDirectly,
}) => {
  const [selectedTempleId, setSelectedTempleId] = useState<string>(temples[0]?.id || '');
  const activeTemple = temples.find((t) => t.id === selectedTempleId) || temples[0];

  const currentHour = new Date().getHours();

  if (temples.length === 0) {
    return (
      <div className="p-12 text-center bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl space-y-3">
        <Sparkles className="w-10 h-10 text-[#8B8B6B] mx-auto" />
        <h3 className="font-serif font-bold text-base text-[#2D2D2A]">No Sacred Temples Recorded</h3>
        <p className="text-xs text-[#8B8B6B] max-w-sm mx-auto">
          No temple records currently found for this city. Use the Explore City tool to generate data.
        </p>
      </div>
    );
  }

  return (
    <div id="temples-section" className="space-y-6">
      {/* Banner & Crowd Radar Overview in Natural Earth/Sage Palette */}
      <div className="bg-[#2D2D2A] text-white rounded-3xl p-6 sm:p-7 shadow-sm border border-[#5A5A40]/30 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-[#5A5A40]/50 border border-amber-300/30 rounded-2xl">
                <Sparkles className="w-5 h-5 text-amber-300" />
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold tracking-tight">
                Sacred Temples & Live Crowd Radar
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-stone-300 font-sans leading-relaxed">
              Real-time crowd forecasts, morning/evening Aarti rush hours, VIP Darshan fast-track passes, dress code mandates, and optimal quiet hours.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15 text-xs flex items-center gap-4 shrink-0">
            <div>
              <span className="text-stone-300 block text-[10px] font-bold uppercase tracking-wider">Temples Tracked</span>
              <span className="font-bold text-base text-white">{temples.length} Sacred Shrines</span>
            </div>
            <div className="h-7 w-px bg-white/20" />
            <div>
              <span className="text-stone-300 block text-[10px] font-bold uppercase tracking-wider">Live Time</span>
              <span className="font-bold text-base text-amber-300">{currentHour}:00 Radar</span>
            </div>
          </div>
        </div>

        {/* Quick Temple Selection Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pt-4 border-t border-white/10 text-xs">
          <span className="text-stone-300 font-bold whitespace-nowrap text-xs">Select Temple Slot:</span>
          {temples.map((t) => {
            const density = t.crowd?.hourlyCrowdIndex[currentHour] ?? 40;
            const isSelected = activeTemple?.id === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTempleId(t.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-white text-[#2D2D2A] shadow-md ring-2 ring-amber-300'
                    : 'bg-white/10 hover:bg-white/20 text-stone-200'
                }`}
              >
                <span>{t.name.split('(')[0]}</span>
                <span className={`w-2 h-2 rounded-full ${density > 70 ? 'bg-rose-400 animate-pulse' : density > 40 ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Featured Active Temple Crowd Dashboard */}
      {activeTemple && (
        <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl p-6 sm:p-7 shadow-xs space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6 pb-6 border-b border-[#E5E2D9]">
            {/* Left Info */}
            <div className="space-y-4 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 bg-[#F4F1EA] text-[#5A5A40] rounded-full text-xs font-bold border border-[#DEDACF]">
                  {activeTemple.templeDeity || 'Sacred Shrine'}
                </span>
                <span className="text-xs text-[#8B8B6B] flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#D28E5D]" />
                  {activeTemple.address}
                </span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2D2A]">
                  {activeTemple.name}
                </h3>
                <p className="text-xs sm:text-sm text-[#5A5A40] mt-1.5 leading-relaxed font-sans">
                  {activeTemple.description}
                </p>
              </div>

              {/* Darshan & VIP Ticket Breakdown */}
              <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-4 space-y-3">
                <h4 className="font-bold text-xs text-[#2D2D2A] flex items-center gap-1.5 uppercase tracking-wider">
                  <Ticket className="w-4 h-4 text-[#5A5A40]" />
                  <span>Darshan Ticket & VIP Pass Pricing:</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-[#FDFCF8] p-3 rounded-xl border border-[#E5E2D9]">
                    <span className="text-[#8B8B6B] block text-[11px] font-medium">General Devotee Queue</span>
                    <span className="font-bold text-[#2D2D2A] text-sm">{activeTemple.ticket.generalPrice === 0 || activeTemple.ticket.isFree ? 'FREE ENTRY' : `${activeTemple.ticket.currency}${activeTemple.ticket.generalPrice}`}</span>
                    <p className="text-[10px] text-[#8B8B6B] mt-0.5">Free access via designated entry gates</p>
                  </div>
                  {activeTemple.ticket.vipPrice && (
                    <div className="bg-[#FDFCF8] p-3 rounded-xl border border-[#DEDACF]">
                      <span className="text-[#5A5A40] font-bold block text-[11px]">VIP Fast-Track Pass</span>
                      <span className="font-bold text-[#2D2D2A] text-sm">
                        {activeTemple.ticket.currency}{activeTemple.ticket.vipPrice} per devotee
                      </span>
                      <p className="text-[10px] text-[#8B8B6B] mt-0.5">Shortens queue time to 10-15 minutes</p>
                    </div>
                  )}
                </div>
                {activeTemple.ticket.ticketNotes && (
                  <p className="text-[11px] text-[#5A5A40] pt-1">
                    {activeTemple.ticket.ticketNotes}
                  </p>
                )}
              </div>

              {/* Dress code & Entry Guidelines */}
              {activeTemple.dressCode && (
                <div className="bg-[#FFF9F0] border border-[#F3E5D8] rounded-2xl p-4 flex items-start gap-3 text-xs">
                  <Info className="w-4 h-4 text-[#C2410C] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#2D2D2A] block">Temple Dress Code & Entry Guidelines:</span>
                    <p className="text-[#5A5A40] mt-0.5 leading-relaxed">{activeTemple.dressCode}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Right Quick Actions & Image */}
            <div className="w-full lg:w-80 shrink-0 space-y-3">
              <div className="relative h-52 w-full rounded-2xl overflow-hidden shadow-xs border border-[#E5E2D9]">
                <img
                  src={activeTemple.image}
                  alt={activeTemple.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3 bg-[#FDFCF8]/95 backdrop-blur-xs px-2.5 py-1 rounded-xl text-xs font-bold text-[#2D2D2A] shadow-xs border border-[#E5E2D9]">
                  ⭐ {activeTemple.rating} ({activeTemple.reviewCount.toLocaleString()} reviews)
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onShowOnMap(activeTemple)}
                  className="py-2.5 px-3 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors border border-[#DEDACF]"
                >
                  <MapPin className="w-4 h-4 text-[#D28E5D]" />
                  <span>View on Map</span>
                </button>
                <button
                  onClick={() => onSelectPlace(activeTemple)}
                  className="py-2.5 px-3 bg-[#5A5A40] hover:bg-[#484832] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
                >
                  <span>Reviews & Info</span>
                </button>
              </div>

              {onBookDirectly && (
                <button
                  onClick={() => onBookDirectly({ place: activeTemple, category: 'temple' })}
                  className="w-full py-2.5 px-3 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-xs"
                >
                  <Sparkles className="w-4 h-4 text-amber-200" />
                  <span>Book VIP Darshan / Pooja Pass</span>
                </button>
              )}

              {onAddToItinerary && (
                <button
                  onClick={() => onAddToItinerary(activeTemple)}
                  className="w-full py-2.5 px-3 bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
                >
                  <Calendar className="w-4 h-4 text-amber-300" />
                  <span>Add to Daily Itinerary</span>
                </button>
              )}
            </div>
          </div>

          {/* Full Visual Crowd Analyzer for Active Temple */}
          {activeTemple.crowd && (
            <CrowdVisualizer crowd={activeTemple.crowd} placeName={activeTemple.name} isCompact={false} />
          )}
        </div>
      )}

      {/* Comparative Peak Crowd Time Table for All Temples in City */}
      <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5E2D9] pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#5A5A40]" />
            <h3 className="font-serif font-bold text-lg text-[#2D2D2A]">
              Temple Crowd Comparison & Quiet Hours Schedule
            </h3>
          </div>
          <span className="text-xs text-[#8B8B6B] font-medium">
            Plan your darshan without long waiting queues
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#F4F1EA] border-b border-[#E5E2D9] text-[#5A5A40] uppercase font-bold text-[10px] tracking-wider">
                <th className="py-3 px-4 rounded-l-xl">Temple Name</th>
                <th className="py-3 px-4">Peak Aarti Hours (Long Queue)</th>
                <th className="py-3 px-4">Best Quiet Hours (No Queue)</th>
                <th className="py-3 px-4">Busiest Days</th>
                <th className="py-3 px-4">Entry / VIP Pass</th>
                <th className="py-3 px-4 text-right rounded-r-xl">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E2D9]">
              {temples.map((t) => (
                <tr key={t.id} className="hover:bg-[#F4F1EA]/60 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-[#2D2D2A]">
                    <span className="block">{t.name}</span>
                    <span className="text-[11px] text-[#8B8B6B] font-normal">{t.templeDeity}</span>
                  </td>
                  <td className="py-3.5 px-4 text-rose-700 font-medium">
                    {t.crowd?.peakHours[0] || 'Morning & Evening Aarti'}
                  </td>
                  <td className="py-3.5 px-4 text-emerald-800 font-bold">
                    {t.crowd?.leastCrowdHours || 'Mid-day 1:00 PM - 3:30 PM'}
                  </td>
                  <td className="py-3.5 px-4 text-[#5A5A40]">
                    {t.crowd?.peakDays?.join(', ') || 'Weekends & Festivals'}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-[#2D2D2A] block">
                      {t.ticket.isFree ? 'FREE' : `${t.ticket.currency}${t.ticket.generalPrice}`}
                    </span>
                    {t.ticket.vipPrice && (
                      <span className="text-[10px] text-[#5A5A40] bg-[#EAE7DC] px-1.5 py-0.5 rounded-md font-bold">
                        VIP: {t.ticket.currency}{t.ticket.vipPrice}
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => {
                        setSelectedTempleId(t.id);
                        onSelectPlace(t);
                      }}
                      className="px-3 py-1.5 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-xs font-bold rounded-xl transition-colors border border-[#DEDACF]"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

