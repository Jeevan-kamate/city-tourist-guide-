import React from 'react';
import { Place } from '../types';
import { 
  Film, 
  Sparkles, 
  UtensilsCrossed, 
  Landmark, 
  Star, 
  MapPin, 
  Clock, 
  Ticket, 
  Users, 
  ChevronRight,
  ShieldAlert,
  Flame,
  PlusCircle,
  Check,
  Calendar
} from 'lucide-react';
import { CrowdVisualizer } from './CrowdVisualizer';

interface PlaceCardProps {
  place: Place;
  onSelect: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
  onAddToItinerary?: (place: Place) => void;
  onBookDirectly?: (place: Place) => void;
  isSavedInItinerary?: boolean;
}

export const PlaceCard: React.FC<PlaceCardProps> = ({
  place,
  onSelect,
  onShowOnMap,
  onAddToItinerary,
  onBookDirectly,
  isSavedInItinerary = false,
}) => {
  const getCategoryConfig = () => {
    switch (place.category) {
      case 'theatre':
        return {
          icon: Film,
          label: 'Theatre & Cinema',
          badgeClass: 'bg-[#F4F1EA] text-[#5A5A40] border-[#DEDACF]',
          accentColor: '#5A5A40',
          bookLabel: 'Book Movie Tickets',
          bookClass: 'bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white',
        };
      case 'temple':
        return {
          icon: Sparkles,
          label: 'Sacred Temple / Shrine',
          badgeClass: 'bg-[#F4F1EA] text-[#5A5A40] border-[#DEDACF]',
          accentColor: '#8B8B6B',
          bookLabel: 'Book VIP Darshan Pass',
          bookClass: 'bg-[#5A5A40] hover:bg-[#484832] text-white',
        };
      case 'restaurant':
        return {
          icon: UtensilsCrossed,
          label: 'Restaurant & Dining',
          badgeClass: 'bg-[#E9F2E9] text-[#4A6741] border-[#D0E2CF]',
          accentColor: '#4A6741',
          bookLabel: 'Reserve Table & Dishes',
          bookClass: 'bg-[#4A6741] hover:bg-[#385032] text-white',
        };
      case 'attraction':
      default:
        return {
          icon: Landmark,
          label: 'Attraction & Sights',
          badgeClass: 'bg-[#FFF9F0] text-[#C2410C] border-[#F3E5D8]',
          accentColor: '#C2410C',
          bookLabel: 'Book Entry Tickets',
          bookClass: 'bg-[#C2410C] hover:bg-[#9A3412] text-white',
        };
    }
  };

  const config = getCategoryConfig();
  const IconComponent = config.icon;

  const currentHour = new Date().getHours();
  const currentCrowd = place.crowd?.hourlyCrowdIndex[currentHour] ?? 40;

  return (
    <div
      id={`place-card-${place.id}`}
      className="group bg-white border border-[#E5E2D9] rounded-3xl overflow-hidden hover:border-[#8B8B6B] hover:shadow-lg transition-all duration-300 flex flex-col justify-between text-[#3D3D3D]"
    >
      <div>
        {/* Card Image Banner */}
        <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-[#EAE7DC]">
          <img
            src={place.image}
            alt={place.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#2D2D2A]/80 via-transparent to-transparent" />

          {/* Top Badges */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
            <span
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold backdrop-blur-md shadow-xs border ${config.badgeClass}`}
            >
              <IconComponent className="w-3.5 h-3.5" />
              <span>{config.label}</span>
            </span>

            {/* Timings Status */}
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/95 text-[#2D2D2A] backdrop-blur-md shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
              {place.timings.currentStatus || 'Open Today'}
            </span>
          </div>

          {/* Bottom Title on Image */}
          <div className="absolute bottom-3 left-3 right-3 text-white">
            <h3 className="font-serif font-bold text-lg leading-snug drop-shadow-xs line-clamp-1">
              {place.name}
            </h3>
            <p className="text-xs text-stone-200 line-clamp-1 mt-0.5">
              {place.tagline}
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-3.5">
          {/* Rating, Reviews & Address */}
          <div className="flex items-center justify-between text-xs text-[#5A5A40]">
            <div className="flex items-center gap-1.5">
              <div className="flex items-center gap-1 bg-[#FFF9F0] text-[#C2410C] border border-[#F3E5D8] px-2 py-0.5 rounded-md font-bold text-xs">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                <span>{place.rating}</span>
              </div>
              <span className="text-[#8B8B6B] font-medium">({place.reviewCount.toLocaleString()} reviews)</span>
            </div>

            <div className="flex items-center gap-1 text-[#8B8B6B] text-[11px] truncate max-w-[180px]">
              <MapPin className="w-3.5 h-3.5 shrink-0 text-[#D28E5D]" />
              <span className="truncate">{place.address.split(',')[0]}</span>
            </div>
          </div>

          {/* Description snippet */}
          <p className="text-xs text-[#666] line-clamp-2 leading-relaxed">
            {place.description}
          </p>

          {/* Category-Specific Highlight Box */}
          {place.category === 'theatre' && place.movies && place.movies.length > 0 && (
            <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#2D2D2A]">
                <span className="flex items-center gap-1">
                  <Film className="w-3.5 h-3.5 text-[#5A5A40]" />
                  Now Showing Movies ({place.movies.length})
                </span>
                <span className="text-[10px] text-[#8B8B6B] font-medium">Showtimes</span>
              </div>
              <div className="space-y-1.5">
                {place.movies.slice(0, 2).map((mov) => (
                  <div key={mov.id} className="bg-white rounded-xl p-2 border border-[#E5E2D9] flex items-center justify-between text-xs">
                    <div className="truncate pr-2">
                      <span className="font-bold text-[#2D2D2A] truncate block">{mov.title}</span>
                      <span className="text-[11px] text-[#8B8B6B]">{mov.format} · {mov.language.split('(')[0]}</span>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-bold text-[#5A5A40] block">
                        {mov.showtimes[0]?.price ? `${mov.showtimes[0].currency}${mov.showtimes[0].price}` : 'Available'}
                      </span>
                      <span className="text-[10px] text-[#8B8B6B]">{mov.showtimes[0]?.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {place.category === 'temple' && place.crowd && (
            <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#2D2D2A] flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-[#5A5A40]" />
                  Live Crowd Density
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  currentCrowd > 75 ? 'bg-rose-100 text-rose-800 border-rose-200' : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                }`}>
                  {currentCrowd > 75 ? '🔥 High Rush' : '✨ Moderate / Low'}
                </span>
              </div>
              
              <CrowdVisualizer crowd={place.crowd} placeName={place.name} isCompact={true} />

              {place.crowd.peakHours[0] && (
                <p className="text-[11px] text-[#5A5A40] bg-white/70 px-2 py-1 rounded-lg border border-[#E5E2D9] leading-tight">
                  <strong>Avoid:</strong> {place.crowd.peakHours[0].split('(')[0]}
                </p>
              )}
            </div>
          )}

          {place.category === 'restaurant' && place.topDishes && place.topDishes.length > 0 && (
            <div className="bg-[#E9F2E9] border border-[#D0E2CF] rounded-2xl p-3 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#2D2D2A]">
                <span className="flex items-center gap-1 text-[#4A6741]">
                  <Flame className="w-3.5 h-3.5 text-[#C2410C]" />
                  Top-Rated Dishes
                </span>
                <span className="text-[10px] text-[#4A6741] font-bold">{place.priceCategory || '$$'}</span>
              </div>
              <div className="space-y-1.5">
                {place.topDishes.slice(0, 2).map((dish, i) => (
                  <div key={i} className="bg-white rounded-xl p-2 border border-[#D0E2CF] flex items-center justify-between text-xs">
                    <div className="truncate pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-[#2D2D2A] truncate">{dish.name}</span>
                        {dish.badge && (
                          <span className="text-[9px] bg-[#FFF9F0] text-[#C2410C] font-bold px-1.5 py-0.2 rounded-md shrink-0">
                            {dish.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-[#8B8B6B] truncate">{dish.description}</p>
                    </div>
                    <span className="font-bold text-[#4A6741] shrink-0">{dish.price}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {place.category === 'attraction' && (
            <div className="bg-[#FFF9F0] border border-[#F3E5D8] rounded-2xl p-3 space-y-1.5 text-xs">
              <div className="flex items-center justify-between font-bold text-[#C2410C]">
                <span className="flex items-center gap-1">
                  <Ticket className="w-3.5 h-3.5 text-[#C2410C]" />
                  Entry Ticket
                </span>
                <span className="font-bold">
                  {place.ticket.isFree ? 'FREE ENTRY' : `${place.ticket.currency}${place.ticket.generalPrice}`}
                </span>
              </div>
              <p className="text-[11px] text-[#666] line-clamp-2">
                {place.ticket.ticketNotes || 'Official counter & digital bookings available.'}
              </p>
            </div>
          )}

          {/* Ticket & Timing Quick Strip */}
          <div className="flex items-center justify-between pt-1 text-xs border-t border-[#E5E2D9] text-[#5A5A40]">
            <div className="flex items-center gap-1.5">
              <Ticket className="w-3.5 h-3.5 text-[#8B8B6B]" />
              <span className="font-bold text-[#2D2D2A]">
                {place.ticket.isFree
                  ? 'Free Entry'
                  : `From ${place.ticket.currency}${place.ticket.generalPrice}`}
              </span>
              {place.ticket.vipPrice && (
                <span className="text-[10px] text-[#C2410C] bg-[#FFF9F0] border border-[#F3E5D8] px-1.5 py-0.2 rounded-md font-bold">
                  VIP: {place.ticket.currency}{place.ticket.vipPrice}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1 text-[11px] text-[#8B8B6B]">
              <Clock className="w-3 h-3 text-[#8B8B6B]" />
              <span>{place.timings.open} - {place.timings.close}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Card Action Footer */}
      <div className="p-4 pt-0 space-y-2 mt-2">
        {/* Direct Booking CTA */}
        {onBookDirectly && (
          <button
            id={`btn-book-${place.id}`}
            onClick={() => onBookDirectly(place)}
            className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs ${config.bookClass}`}
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>{config.bookLabel}</span>
          </button>
        )}

        <div className="grid grid-cols-2 gap-2">
          <button
            id={`btn-map-${place.id}`}
            onClick={() => onShowOnMap(place)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-[#DEDACF] bg-[#F4F1EA] hover:bg-[#EAE7DC] text-xs font-bold text-[#5A5A40] transition-colors"
          >
            <MapPin className="w-3.5 h-3.5 text-[#D28E5D]" />
            <span>Show on Map</span>
          </button>

          <button
            id={`btn-details-${place.id}`}
            onClick={() => onSelect(place)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#5A5A40] hover:bg-[#454530] text-white text-xs font-bold transition-colors shadow-2xs"
          >
            <span>Details & Guide</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {onAddToItinerary && (
          <button
            id={`btn-itinerary-${place.id}`}
            onClick={() => onAddToItinerary(place)}
            className={`w-full py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
              isSavedInItinerary
                ? 'bg-[#E9F2E9] border-[#D0E2CF] text-[#4A6741]'
                : 'border-dashed border-[#8B8B6B] text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            {isSavedInItinerary ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#4A6741]" />
                <span>Added to Daily Itinerary Schedule</span>
              </>
            ) : (
              <>
                <Calendar className="w-3.5 h-3.5 text-[#5A5A40]" />
                <span>+ Add to Daily Itinerary Schedule</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
