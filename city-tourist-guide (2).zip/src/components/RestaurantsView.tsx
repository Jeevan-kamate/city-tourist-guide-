import React, { useState } from 'react';
import { Place, MenuItem } from '../types';
import { 
  UtensilsCrossed, 
  Flame, 
  Star, 
  DollarSign, 
  Clock, 
  MapPin, 
  Check, 
  Award, 
  Heart,
  MessageSquare
} from 'lucide-react';

interface RestaurantsViewProps {
  restaurants: Place[];
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
}

export const RestaurantsView: React.FC<RestaurantsViewProps> = ({
  restaurants,
  onSelectPlace,
  onShowOnMap,
}) => {
  const [dietFilter, setDietFilter] = useState<'all' | 'veg' | 'non-veg'>('all');
  const [selectedCuisine, setSelectedCuisine] = useState<string>('all');

  // Collect all dishes across all restaurants
  const allDishes: { dish: MenuItem; restaurant: Place }[] = [];
  restaurants.forEach((r) => {
    r.topDishes?.forEach((d) => {
      allDishes.push({ dish: d, restaurant: r });
    });
  });

  // Extract unique cuisines
  const cuisines = ['all', ...Array.from(new Set(restaurants.flatMap((r) => r.cuisine || [])))];

  const filteredDishes = allDishes.filter(({ dish, restaurant }) => {
    if (dietFilter === 'veg' && !dish.isVeg) return false;
    if (dietFilter === 'non-veg' && dish.isVeg) return false;
    if (selectedCuisine !== 'all' && !restaurant.cuisine?.includes(selectedCuisine)) return false;
    return true;
  });

  return (
    <div id="restaurants-section" className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-emerald-900 text-white rounded-2xl p-6 shadow-lg border border-emerald-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-emerald-600/30 border border-emerald-400/30 rounded-xl">
                <UtensilsCrossed className="w-5 h-5 text-emerald-400" />
              </span>
              <h2 className="text-xl md:text-2xl font-bold font-display">
                Top Rated Restaurants & Most-Rated Signature Dishes
              </h2>
            </div>
            <p className="text-sm text-emerald-200">
              Discover authentic local culinary gems, iconic street stalls, and celebrated restaurants ranked by visitor reviews and signature must-eat dishes.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/15 text-xs flex items-center gap-3">
            <div>
              <span className="text-emerald-200 block">Food Spots</span>
              <span className="font-bold text-base text-white">{restaurants.length} Places</span>
            </div>
            <div className="h-6 w-px bg-white/20" />
            <div>
              <span className="text-emerald-200 block">Rated Dishes</span>
              <span className="font-bold text-base text-amber-300">{allDishes.length} Must-Try</span>
            </div>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-5 border-t border-emerald-800/60 mt-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-emerald-300 font-medium">Diet:</span>
            <button
              onClick={() => setDietFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                dietFilter === 'all' ? 'bg-emerald-500 text-white' : 'bg-white/10 hover:bg-white/20 text-emerald-100'
              }`}
            >
              All Items
            </button>
            <button
              onClick={() => setDietFilter('veg')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                dietFilter === 'veg' ? 'bg-emerald-500 text-white' : 'bg-white/10 hover:bg-white/20 text-emerald-100'
              }`}
            >
              🥦 Pure Veg
            </button>
            <button
              onClick={() => setDietFilter('non-veg')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                dietFilter === 'non-veg' ? 'bg-emerald-500 text-white' : 'bg-white/10 hover:bg-white/20 text-emerald-100'
              }`}
            >
              🍗 Non-Veg / Seafood
            </button>
          </div>

          {cuisines.length > 2 && (
            <div className="flex items-center gap-1.5 overflow-x-auto max-w-full">
              <span className="text-emerald-300 font-medium whitespace-nowrap">Cuisine:</span>
              {cuisines.map((c) => (
                <button
                  key={c}
                  onClick={() => setSelectedCuisine(c)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap ${
                    selectedCuisine === c ? 'bg-white text-emerald-950 font-bold' : 'bg-white/10 text-emerald-200 hover:bg-white/20'
                  }`}
                >
                  {c === 'all' ? 'All Cuisines' : c}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Featured Most-Rated Dishes Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-500" />
            <span>Highest Rated Dishes in the City</span>
          </h3>
          <span className="text-xs text-stone-500">
            Sorted by authenticity & verified traveler reviews
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDishes.map(({ dish, restaurant }, idx) => (
            <div
              key={`${restaurant.id}-${idx}`}
              className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs hover:shadow-md transition-all space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-3.5 h-3.5 rounded-xs border flex items-center justify-center shrink-0 ${
                        dish.isVeg ? 'border-emerald-600' : 'border-rose-600'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          dish.isVeg ? 'bg-emerald-600' : 'bg-rose-600'
                        }`}
                      />
                    </span>
                    <span className="text-xs font-semibold text-stone-500">
                      {dish.isVeg ? 'Pure Veg' : 'Non-Veg'}
                    </span>
                  </div>

                  {dish.badge && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200 shadow-2xs">
                      ⭐ {dish.badge}
                    </span>
                  )}
                </div>

                <div>
                  <h4 className="font-bold text-sm text-stone-900 leading-snug">
                    {dish.name}
                  </h4>
                  <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                    {dish.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-base font-extrabold text-emerald-700">
                    {dish.price}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-stone-500">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    <span className="font-bold text-stone-800">{dish.rating}</span>
                    <span>({dish.reviewCount.toLocaleString()} votes)</span>
                  </div>
                </div>
              </div>

              {/* Restaurant tag footer */}
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                <div className="truncate pr-2">
                  <span className="font-semibold text-stone-900 truncate block">
                    {restaurant.name}
                  </span>
                  <span className="text-[10px] text-stone-500 truncate block">
                    {restaurant.address.split(',')[0]}
                  </span>
                </div>
                <button
                  onClick={() => onSelectPlace(restaurant)}
                  className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg shrink-0 transition-colors"
                >
                  View Menu
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full Restaurant Cards Section */}
      <div className="space-y-4 pt-4">
        <h3 className="font-bold text-base text-stone-900">
          All Featured Culinary Landmarks & Stalls ({restaurants.length})
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {restaurants.map((rest) => (
            <div
              key={rest.id}
              className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs hover:border-stone-400 transition-all flex flex-col md:flex-row"
            >
              <div className="md:w-56 h-48 md:h-auto bg-stone-100 relative shrink-0">
                <img
                  src={rest.image}
                  alt={rest.name}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold bg-white/95 text-stone-900 shadow-sm">
                  {rest.priceCategory || '$$'} Price
                </span>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-base text-stone-900">{rest.name}</h4>
                    <span className="text-xs font-bold text-amber-700">⭐ {rest.rating}</span>
                  </div>
                  <p className="text-xs text-stone-500 line-clamp-1">{rest.tagline}</p>
                  
                  <div className="flex flex-wrap gap-1 mt-2">
                    {rest.cuisine?.map((c, i) => (
                      <span key={i} className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded font-medium">
                        {c}
                      </span>
                    ))}
                  </div>

                  {/* Top Rated Food Items */}
                  {rest.topDishes && rest.topDishes.length > 0 && (
                    <div className="mt-3 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100 space-y-1">
                      <span className="text-[11px] font-bold text-emerald-950 flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-emerald-700" />
                        Signature Must-Eat:
                      </span>
                      <p className="text-xs text-emerald-900 font-medium">
                        {rest.topDishes[0]?.name} ({rest.topDishes[0]?.price})
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-stone-100">
                  <div className="flex items-center gap-1 text-[11px] text-stone-500">
                    <Clock className="w-3.5 h-3.5 text-stone-400" />
                    <span>{rest.timings.open} - {rest.timings.close}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onShowOnMap(rest)}
                      className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg"
                    >
                      Map
                    </button>
                    <button
                      onClick={() => onSelectPlace(rest)}
                      className="px-3 py-1 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg"
                    >
                      Details & Reviews
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
