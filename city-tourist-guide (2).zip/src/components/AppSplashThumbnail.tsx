import React, { useEffect, useState } from 'react';
import { Compass, Sparkles, MapPin, ArrowRight, X, ShieldCheck, Ticket, Star } from 'lucide-react';

interface AppSplashThumbnailProps {
  isOpen: boolean;
  onClose: () => void;
  activeCityName?: string;
}

export const AppSplashThumbnail: React.FC<AppSplashThumbnailProps> = ({
  isOpen,
  onClose,
  activeCityName = 'City'
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setMounted(true);
    }
  }, [isOpen]);

  if (!isOpen && !mounted) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 transition-all duration-500 ${
        isOpen
          ? 'opacity-100 backdrop-blur-md bg-black/60 pointer-events-auto'
          : 'opacity-0 backdrop-blur-none bg-black/0 pointer-events-none'
      }`}
    >
      {/* Centered Thumbnail Card */}
      <div
        className={`relative w-full max-w-lg bg-[#FDFCF8] rounded-3xl overflow-hidden shadow-2xl border border-[#E5E2D9] transition-all duration-500 transform ${
          isOpen ? 'scale-100 translate-y-0 opacity-100' : 'scale-95 translate-y-4 opacity-0'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md text-white flex items-center justify-center transition-colors shadow-sm"
          title="Close intro"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Visual Thumbnail Hero Image Banner */}
        <div className="relative h-60 sm:h-64 w-full overflow-hidden bg-[#2D2D2A]">
          <img
            src="https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=1200&q=80"
            alt="City Tourist Guide Thumbnail"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out hover:scale-100 brightness-[0.75]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1C1C1A] via-black/40 to-transparent" />

          {/* Floating Pill Badge */}
          <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white text-xs font-semibold tracking-wide">
            <Compass className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
            <span>Smart Travel Companion</span>
          </div>

          {/* Title & Author on Thumbnail Banner */}
          <div className="absolute bottom-4 left-5 right-5 z-10 text-white space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-amber-500/90 text-stone-900 text-[10px] font-extrabold uppercase tracking-wider">
                Official Edition
              </span>
              <span className="text-stone-300 text-xs font-medium flex items-center gap-1">
                <MapPin className="w-3 h-3 text-amber-400" /> Exploring {activeCityName} & Beyond
              </span>
            </div>
            
            {/* Primary Main Title */}
            <h1 className="text-2xl sm:text-3xl font-serif font-extrabold tracking-tight text-white drop-shadow-md leading-tight">
              City Tourist Guide
            </h1>

            {/* Author Credit in small font */}
            <p className="text-xs sm:text-sm text-amber-200 font-medium tracking-normal flex items-center gap-1">
              <span>created by jeevan m k</span>
              <Sparkles className="w-3 h-3 text-amber-300 inline" />
            </p>
          </div>
        </div>

        {/* Thumbnail Card Content & Features Summary */}
        <div className="p-5 sm:p-6 space-y-5 bg-[#FDFCF8]">
          <div className="grid grid-cols-2 gap-2.5 text-xs text-[#5A5A40]">
            <div className="p-2.5 rounded-xl bg-[#F4F1EA] border border-[#E5E2D9] flex items-center gap-2.5">
              <span className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center shrink-0 text-xs">
                🎬
              </span>
              <div>
                <div className="font-bold text-[#2D2D2A]">Cinema Passes</div>
                <div className="text-[10px] text-[#8B8B6B]">Showtimes & Seats</div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-[#F4F1EA] border border-[#E5E2D9] flex items-center gap-2.5">
              <span className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center shrink-0 text-xs">
                🛕
              </span>
              <div>
                <div className="font-bold text-[#2D2D2A]">Temple Darshans</div>
                <div className="text-[10px] text-[#8B8B6B]">VIP Passes & Timings</div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-[#F4F1EA] border border-[#E5E2D9] flex items-center gap-2.5">
              <span className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center shrink-0 text-xs">
                🍽️
              </span>
              <div>
                <div className="font-bold text-[#2D2D2A]">Top Restaurants</div>
                <div className="text-[10px] text-[#8B8B6B]">Best Rated Foods</div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-[#F4F1EA] border border-[#E5E2D9] flex items-center gap-2.5">
              <span className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center shrink-0 text-xs">
                🎫
              </span>
              <div>
                <div className="font-bold text-[#2D2D2A]">Instant PDF Tickets</div>
                <div className="text-[10px] text-[#8B8B6B]">Save to Mobile Device</div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-1 flex flex-col sm:flex-row items-center gap-2.5">
            <button
              onClick={onClose}
              className="w-full py-3 px-5 rounded-2xl bg-[#5A5A40] hover:bg-[#484832] text-white font-bold text-sm flex items-center justify-center gap-2 transition-transform active:scale-[0.98] shadow-md group"
            >
              <span>Explore City Guide</span>
              <ArrowRight className="w-4 h-4 text-amber-300 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Subtle Bottom Credit Footnote */}
          <div className="text-center pt-1 border-t border-[#EAE7DC]">
            <span className="text-[11px] text-[#8B8B6B] font-medium">
              City Tourist Guide · <span className="text-[#5A5A40] font-semibold">created by jeevan m k</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
