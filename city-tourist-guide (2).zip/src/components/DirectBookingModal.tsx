import React, { useState, useEffect } from 'react';
import { 
  Place, 
  CityEvent, 
  BookingTarget, 
  Booking, 
  MovieShow,
  MenuItem,
  UserAccount
} from '../types';
import { 
  X, 
  Film, 
  Sparkles, 
  UtensilsCrossed, 
  Landmark, 
  PartyPopper,
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  Phone, 
  Mail, 
  CreditCard, 
  CheckCircle2, 
  QrCode, 
  Printer, 
  ShieldCheck,
  Plus,
  Minus,
  Check,
  ChevronRight,
  ArrowLeft,
  Coffee,
  Info,
  CalendarPlus,
  Receipt,
  Download,
  Share2,
  Smartphone,
  Edit2
} from 'lucide-react';
import { downloadTicketPDF } from '../utils/pdfTicketGenerator';

interface DirectBookingModalProps {
  isOpen: boolean;
  target: BookingTarget | null;
  cityName: string;
  currentUser?: UserAccount | null;
  onClose: () => void;
  onBookingSuccess: (booking: Booking) => void;
  onAddToItinerary?: (booking: Booking) => void;
  onOpenMyBookings?: () => void;
}

export const DirectBookingModal: React.FC<DirectBookingModalProps> = ({
  isOpen,
  target,
  cityName = 'City',
  currentUser,
  onClose,
  onBookingSuccess,
  onAddToItinerary,
  onOpenMyBookings,
}) => {
  const place = target?.place;
  const event = target?.event;
  const initialMovie = target?.initialMovie || target?.movie;
  const initialShowtime = target?.initialShowtime || target?.showtime;
  const initialDarshanType = target?.initialDarshanType;

  const resolvedCategory: 'theatre' | 'temple' | 'restaurant' | 'attraction' | 'event' = 
    (target?.category === 'theatre' || target?.type === 'theatre' || target?.type === 'movie') ? 'theatre' :
    (target?.category === 'temple' || target?.type === 'temple') ? 'temple' :
    (target?.category === 'restaurant' || target?.type === 'restaurant') ? 'restaurant' :
    (target?.category === 'attraction' || target?.type === 'attraction') ? 'attraction' :
    (target?.category === 'event' || target?.type === 'event') ? 'event' :
    (place?.category === 'theatre' ? 'theatre' : (place?.category as any)) ||
    (event ? 'event' : 'theatre');

  // Booking step: 1 = Selection/Seats, 2 = Contact & Payment, 3 = Confirmed E-Ticket
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  // Common date & timing
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const dayAfter = new Date(today);
  dayAfter.setDate(dayAfter.getDate() + 2);

  const formatDateLabel = (d: Date) => d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  const [selectedDate, setSelectedDate] = useState<string>(formatDateLabel(today));

  // --- MOVIE BOOKING STATE ---
  const moviesList = place?.movies || [];
  const [selectedMovie, setSelectedMovie] = useState<MovieShow | undefined>(
    initialMovie || moviesList[0]
  );
  const [selectedShowtime, setSelectedShowtime] = useState<{
    time: string;
    price: number;
    currency: string;
    screenType: string;
  }>(
    initialShowtime || 
    (selectedMovie?.showtimes?.[0] || { time: '18:30', price: 280, currency: '₹', screenType: 'IMAX 3D Laser' })
  );

  // Visual Cinema Seats (A to E rows, 8 cols)
  // Rows: A-B = VIP Diamond (Recliner, +₹120), C-D = Premium Gold (+₹50), E-F = Executive Silver
  const [selectedSeats, setSelectedSeats] = useState<string[]>(['C4', 'C5']);
  const [selectedSnacks, setSelectedSnacks] = useState<{ name: string; quantity: number; price: number }[]>([
    { name: 'Jumbo Caramel Popcorn Tub', quantity: 1, price: 250 },
  ]);

  // --- TEMPLE BOOKING STATE ---
  const [selectedDarshan, setSelectedDarshan] = useState<string>(
    initialDarshanType || (place?.ticket?.vipPrice ? 'VIP Fast-Track Darshan' : 'Special Darshan Pass')
  );
  const [templeDevoteeCount, setTempleDevoteeCount] = useState<number>(2);
  const [templeSlot, setTempleSlot] = useState<string>('09:30 AM Morning Pooja & Darshan');
  const [prasaadamCount, setPrasaadamCount] = useState<number>(2);
  const [idProofType, setIdProofType] = useState<string>('Government ID / Aadhaar / Passport');
  const [idProofNumber, setIdProofNumber] = useState<string>('');
  const [dressCodeAgreed, setDressCodeAgreed] = useState<boolean>(true);

  // --- RESTAURANT BOOKING STATE ---
  const [partySize, setPartySize] = useState<number>(2);
  const [mealSlot, setMealSlot] = useState<string>('Dinner');
  const [diningTime, setDiningTime] = useState<string>('19:30 PM');
  const [seatingArea, setSeatingArea] = useState<string>('Rooftop Panorama Terrace');
  const [preOrderedDishes, setPreOrderedDishes] = useState<{ [dishName: string]: number }>({});
  const [specialInstructions, setSpecialInstructions] = useState<string>('Window seating if available. Celebrating special occasion.');

  // --- ATTRACTION / MONUMENT BOOKING STATE ---
  const [attractionAdults, setAttractionAdults] = useState<number>(2);
  const [attractionChildren, setAttractionChildren] = useState<number>(0);
  const [attractionSeniors, setAttractionSeniors] = useState<number>(0);
  const [attractionForeigners, setAttractionForeigners] = useState<number>(0);
  const [audioGuides, setAudioGuides] = useState<number>(1);
  const [attractionEntrySlot, setAttractionEntrySlot] = useState<string>('Morning Entry (09:00 AM - 12:30 PM)');

  // --- EVENT BOOKING STATE ---
  const [eventTier, setEventTier] = useState<string>('General Admission Pass');
  const [eventTicketsCount, setEventTicketsCount] = useState<number>(2);

  // --- CONTACT & PAYMENT STATE (Autofilled from Logged-in User) ---
  const [customerName, setCustomerName] = useState<string>(() => currentUser?.name || 'Alex Johnson');
  const [customerEmail, setCustomerEmail] = useState<string>(() => currentUser?.email || 'alex.johnson@traveler.com');
  const [customerPhone, setCustomerPhone] = useState<string>(() => currentUser?.phone || '+91 98765 43210');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'ApplePay' | 'NetBanking' | 'PayAtCounter'>('UPI');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isEditingName, setIsEditingName] = useState<boolean>(false);
  const [isEditingEmail, setIsEditingEmail] = useState<boolean>(false);
  const [isEditingPhone, setIsEditingPhone] = useState<boolean>(false);

  // Auto-sync contact information whenever currentUser changes or modal opens
  useEffect(() => {
    if (currentUser) {
      if (currentUser.name) setCustomerName(currentUser.name);
      if (currentUser.email) setCustomerEmail(currentUser.email);
      if (currentUser.phone) setCustomerPhone(currentUser.phone);
    }
  }, [currentUser, isOpen]);

  // Update selected movie showtime if movie changes
  useEffect(() => {
    if (selectedMovie && selectedMovie.showtimes && selectedMovie.showtimes.length > 0) {
      if (!selectedMovie.showtimes.some(st => st.time === selectedShowtime.time)) {
        setSelectedShowtime(selectedMovie.showtimes[0]);
      }
    }
  }, [selectedMovie]);

  // Sync state with target changes
  useEffect(() => {
    if (target) {
      setStep(1);
      if (initialMovie) setSelectedMovie(initialMovie);
      else if (place?.movies && place.movies.length > 0) setSelectedMovie(place.movies[0]);
      if (initialShowtime) setSelectedShowtime(initialShowtime);
      if (initialDarshanType) setSelectedDarshan(initialDarshanType);
    }
  }, [target]);

  if (!isOpen || !target) return null;

  // Seat toggle handler
  const handleToggleSeat = (seatId: string) => {
    if (selectedSeats.includes(seatId)) {
      if (selectedSeats.length > 1) {
        setSelectedSeats(selectedSeats.filter(s => s !== seatId));
      }
    } else {
      if (selectedSeats.length < 8) {
        setSelectedSeats([...selectedSeats, seatId]);
      }
    }
  };

  // Snack quantity handler
  const handleUpdateSnack = (snackName: string, delta: number, price: number) => {
    const existing = selectedSnacks.find(s => s.name === snackName);
    if (existing) {
      const newQty = Math.max(0, existing.quantity + delta);
      if (newQty === 0) {
        setSelectedSnacks(selectedSnacks.filter(s => s.name !== snackName));
      } else {
        setSelectedSnacks(selectedSnacks.map(s => s.name === snackName ? { ...s, quantity: newQty } : s));
      }
    } else if (delta > 0) {
      setSelectedSnacks([...selectedSnacks, { name: snackName, quantity: 1, price }]);
    }
  };

  // Dish quantity handler
  const handleTogglePreOrderDish = (dishName: string, delta: number) => {
    setPreOrderedDishes(prev => {
      const cur = prev[dishName] || 0;
      const next = Math.max(0, cur + delta);
      if (next === 0) {
        const copy = { ...prev };
        delete copy[dishName];
        return copy;
      }
      return { ...prev, [dishName]: next };
    });
  };

  // Price Calculation
  const calculateTotal = (): { total: number; currency: string } => {
    const curr = place?.ticket?.currency || event?.currency || '₹';

    if (resolvedCategory === 'theatre') {
      const basePrice = selectedShowtime?.price || 250;
      // Seat premium
      let seatsTotal = 0;
      selectedSeats.forEach(seat => {
        const row = seat.charAt(0);
        if (row === 'A' || row === 'B') seatsTotal += (basePrice + 120); // Recliner VIP
        else if (row === 'C' || row === 'D') seatsTotal += (basePrice + 50); // Premium Gold
        else seatsTotal += basePrice; // Executive Silver
      });
      const snacksTotal = selectedSnacks.reduce((acc, s) => acc + (s.quantity * s.price), 0);
      const convFee = selectedSeats.length * 25;
      return { total: seatsTotal + snacksTotal + convFee, currency: curr };
    }

    if (resolvedCategory === 'temple') {
      let perPerson = 0;
      if (selectedDarshan.includes('VIP')) {
        perPerson = typeof place?.ticket?.vipPrice === 'number' ? place.ticket.vipPrice : 250;
      } else if (selectedDarshan.includes('Abhishekam')) {
        perPerson = 500;
      } else if (selectedDarshan.includes('Archana')) {
        perPerson = 100;
      } else {
        perPerson = typeof place?.ticket?.generalPrice === 'number' ? place.ticket.generalPrice : 0;
      }
      const devoteeTotal = perPerson * templeDevoteeCount;
      const prasaadamTotal = prasaadamCount * 100;
      return { total: devoteeTotal + prasaadamTotal, currency: curr };
    }

    if (resolvedCategory === 'restaurant') {
      // Nominal table reservation holding fee (adjusted against bill)
      const reservationHoldingFee = 200; 
      let preOrderTotal = 0;
      if (place?.topDishes) {
        place.topDishes.forEach(d => {
          const qty = preOrderedDishes[d.name] || 0;
          if (qty > 0) {
            const numericPrice = parseInt(d.price.replace(/[^0-9]/g, ''), 10) || 280;
            preOrderTotal += qty * numericPrice;
          }
        });
      }
      return { total: reservationHoldingFee + preOrderTotal, currency: curr };
    }

    if (resolvedCategory === 'attraction') {
      const genPrice = typeof place?.ticket?.generalPrice === 'number' ? place.ticket.generalPrice : (place?.ticket?.isFree ? 0 : 100);
      const childPrice = typeof place?.ticket?.childPrice === 'number' ? place.ticket.childPrice : Math.round(genPrice * 0.5);
      const seniorPrice = typeof place?.ticket?.seniorPrice === 'number' ? place.ticket.seniorPrice : Math.round(genPrice * 0.7);
      const foreignPrice = typeof place?.ticket?.foreignTouristPrice === 'number' ? place.ticket.foreignTouristPrice : (genPrice * 5 || 500);

      const adultsTotal = attractionAdults * genPrice;
      const childTotal = attractionChildren * childPrice;
      const seniorTotal = attractionSeniors * seniorPrice;
      const foreignTotal = attractionForeigners * foreignPrice;
      const audioTotal = audioGuides * 150;

      return { total: adultsTotal + childTotal + seniorTotal + foreignTotal + audioTotal, currency: curr };
    }

    if (resolvedCategory === 'event') {
      let tierPrice = 0;
      if (typeof event?.ticketPrice === 'number') {
        tierPrice = event.ticketPrice;
      } else {
        tierPrice = event?.isFree ? 0 : 350;
      }
      if (eventTier.includes('VIP')) tierPrice = tierPrice * 2.5 || 999;
      return { total: tierPrice * eventTicketsCount, currency: curr };
    }

    return { total: 250, currency: curr };
  };

  const { total: totalAmount, currency } = calculateTotal();

  // Submission handler
  const handleConfirmAndPay = () => {
    setIsProcessing(true);

    setTimeout(() => {
      const randomSuffix = Math.floor(100000 + Math.random() * 900000);
      const categoryCode = resolvedCategory.toUpperCase().substring(0, 4);
      const bookingRef = `${categoryCode}-${cityName.substring(0, 3).toUpperCase()}-${randomSuffix}`;
      const nowIso = new Date().toISOString();

      let bookingDetails = {};
      let serviceTime = '';

      if (resolvedCategory === 'theatre') {
        serviceTime = `${selectedShowtime.time} (${selectedShowtime.screenType})`;
        bookingDetails = {
          movieTitle: selectedMovie?.title,
          movieFormat: selectedMovie?.format,
          movieLanguage: selectedMovie?.language,
          screenName: selectedShowtime.screenType,
          showtime: selectedShowtime.time,
          selectedSeats,
          selectedSnacks: selectedSnacks.filter(s => s.quantity > 0),
        };
      } else if (resolvedCategory === 'temple') {
        serviceTime = templeSlot;
        bookingDetails = {
          darshanType: selectedDarshan,
          poojaSlot: templeSlot,
          prasaadamQuantity: prasaadamCount,
          devoteeCount: templeDevoteeCount,
          idProofType,
          idProofNumber: idProofNumber || 'VERIFIED-GOVT-ID',
        };
      } else if (resolvedCategory === 'restaurant') {
        serviceTime = diningTime;
        const dishes = place?.topDishes
          ?.filter(d => (preOrderedDishes[d.name] || 0) > 0)
          .map(d => ({ name: d.name, quantity: preOrderedDishes[d.name], price: d.price })) || [];

        bookingDetails = {
          partySize,
          mealSlot,
          tableTime: diningTime,
          seatingArea,
          preOrderedDishes: dishes,
          specialInstructions,
        };
      } else if (resolvedCategory === 'attraction') {
        serviceTime = attractionEntrySlot;
        bookingDetails = {
          entrySlot: attractionEntrySlot,
          ticketBreakdown: {
            adults: attractionAdults,
            children: attractionChildren,
            seniors: attractionSeniors,
            foreignTourists: attractionForeigners,
            audioGuides,
          },
        };
      } else if (resolvedCategory === 'event') {
        serviceTime = event?.timing || 'Evening Event';
        bookingDetails = {
          eventTier,
          ticketCount: eventTicketsCount,
          eventDate: event?.date || selectedDate,
          eventTime: event?.timing,
        };
      }

      const newBooking: Booking = {
        id: `BKG-${Date.now()}`,
        bookingRef,
        bookingDate: nowIso,
        serviceDate: selectedDate,
        serviceTime,
        category: (place?.category || (resolvedCategory === 'theatre' ? 'theatre' : (resolvedCategory as any)) || 'event'),
        itemId: (place?.id || event?.id || 'item-1'),
        itemTitle: (place?.name || event?.title || 'City Booking'),
        itemSubtitle: (place?.tagline || event?.category || cityName),
        itemAddress: (place?.address || event?.address || cityName),
        itemImage: (place?.image || event?.image || ''),
        cityName,
        customerName: customerName || 'Valued Guest',
        customerEmail: customerEmail || 'guest@citycompass.com',
        customerPhone: customerPhone || '+91 98765 43210',
        details: bookingDetails,
        totalAmount,
        currency,
        paymentMethod,
        paymentStatus: paymentMethod === 'PayAtCounter' ? 'Confirmed (Pay at Venue)' : 'Paid & Confirmed',
        bookingStatus: 'Confirmed',
        qrCodeValue: `CITYCOMPASS-PASS|${bookingRef}|${place?.name || event?.title}|${selectedDate}|${customerName}`,
        createdAt: nowIso,
      };

      setConfirmedBooking(newBooking);
      onBookingSuccess(newBooking);
      setIsProcessing(false);
      setStep(3);

      // Automatically download & save high-resolution PDF ticket to mobile device / browser
      try {
        downloadTicketPDF(newBooking, cityName, false);
      } catch (e) {
        console.error('Auto PDF generation on booking completion:', e);
      }
    }, 900);
  };

  const itemTitle = place?.name || event?.title;
  const itemImage = place?.image || event?.image;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col justify-between text-[#2D2D2A]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header Banner */}
        <div className="relative bg-[#2D2D2A] text-white p-5 sm:p-6 shrink-0 overflow-hidden">
          <div className="absolute inset-0 opacity-25">
            {itemImage && <img src={itemImage} alt="" className="w-full h-full object-cover blur-xs" />}
            <div className="absolute inset-0 bg-gradient-to-r from-[#2D2D2A] via-[#2D2D2A]/90 to-[#2D2D2A]/60" />
          </div>

          <div className="relative z-10 flex items-start justify-between gap-4">
            <div className="space-y-1 max-w-lg">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-400 text-stone-900">
                  {resolvedCategory === 'theatre' && 'Direct Movie Booking'}
                  {resolvedCategory === 'temple' && 'Sacred VIP Darshan Pass'}
                  {resolvedCategory === 'restaurant' && 'Table Reservation & Dining'}
                  {resolvedCategory === 'attraction' && 'Monument Entry Tickets'}
                  {resolvedCategory === 'event' && 'Event Pass Booking'}
                </span>
                <span className="text-xs text-stone-300 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#D28E5D]" />
                  {cityName}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-serif font-bold text-white leading-tight">
                {itemTitle}
              </h2>
              <p className="text-xs text-stone-300 line-clamp-1">
                {place?.address || event?.address}
              </p>
            </div>

            <button
              onClick={onClose}
              className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-colors shrink-0"
              aria-label="Close booking modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Step Indicator */}
          {step !== 3 && (
            <div className="relative z-10 flex items-center justify-between pt-4 mt-3 border-t border-white/15 text-xs">
              <div className="flex items-center gap-2 font-bold text-white">
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step === 1 ? 'bg-amber-400 text-[#2D2D2A]' : 'bg-emerald-500 text-white'}`}>
                  {step === 1 ? '1' : <Check className="w-3 h-3" />}
                </span>
                <span>1. Choose Slots & Seats</span>
              </div>
              <div className="h-0.5 flex-1 mx-3 bg-white/20" />
              <div className={`flex items-center gap-2 font-bold ${step === 2 ? 'text-white' : 'text-stone-400'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step === 2 ? 'bg-amber-400 text-[#2D2D2A]' : 'bg-white/20 text-white'}`}>
                  2
                </span>
                <span>2. Guest & Instant Payment</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6 text-xs sm:text-sm">
          {/* STEP 1: CATEGORY SPECIFIC CONFIGURATION */}
          {step === 1 && (
            <div className="space-y-6">
              {/* Date Selection Strip */}
              <div className="space-y-2">
                <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40] flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#D28E5D]" />
                  <span>Select Date of Visit / Show:</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[today, tomorrow, dayAfter].map((d, idx) => {
                    const label = formatDateLabel(d);
                    const isSelected = selectedDate === label;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedDate(label)}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          isSelected
                            ? 'bg-[#2D2D2A] text-white border-[#2D2D2A] shadow-xs'
                            : 'bg-[#F4F1EA] text-[#2D2D2A] border-[#DEDACF] hover:bg-[#EAE7DC]'
                        }`}
                      >
                        <span className="block text-[10px] uppercase font-bold opacity-75">
                          {idx === 0 ? 'Today' : idx === 1 ? 'Tomorrow' : 'Day After'}
                        </span>
                        <span className="block font-bold text-xs mt-0.5">{label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 1. MOVIE BOOKING CONTROLS */}
              {resolvedCategory === 'theatre' && (
                <div className="space-y-5">
                  {/* Movie Selection if multiple */}
                  {moviesList.length > 1 && (
                    <div className="space-y-2">
                      <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40] flex items-center gap-1.5">
                        <Film className="w-3.5 h-3.5" />
                        <span>Select Movie:</span>
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {moviesList.map((mov) => (
                          <button
                            key={mov.id}
                            type="button"
                            onClick={() => setSelectedMovie(mov)}
                            className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                              selectedMovie?.id === mov.id
                                ? 'bg-[#F4F1EA] border-[#5A5A40] ring-1 ring-[#5A5A40]'
                                : 'bg-white border-[#E5E2D9] hover:bg-[#F9F7F2]'
                            }`}
                          >
                            <img src={mov.poster} alt="" className="w-10 h-14 object-cover rounded-lg shrink-0" />
                            <div className="truncate">
                              <span className="font-bold text-xs text-[#2D2D2A] block truncate">{mov.title}</span>
                              <span className="text-[11px] text-[#8B8B6B] block">{mov.format} · {mov.language}</span>
                              <span className="text-[10px] text-amber-700 font-bold">⭐ {mov.rating}/10</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Showtimes & Screen format */}
                  {selectedMovie && (
                    <div className="space-y-2">
                      <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40] flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#5A5A40]" />
                        <span>Select Showtime Slot:</span>
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {selectedMovie.showtimes.map((st, i) => {
                          const isSel = selectedShowtime?.time === st.time;
                          return (
                            <button
                              key={i}
                              type="button"
                              onClick={() => setSelectedShowtime(st)}
                              className={`p-2.5 rounded-2xl border text-center transition-all ${
                                isSel
                                  ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                                  : 'bg-white border-[#E5E2D9] hover:bg-[#F4F1EA] text-[#2D2D2A]'
                              }`}
                            >
                              <span className="block font-bold text-sm">{st.time}</span>
                              <span className="block text-[10px] opacity-80 mt-0.5">{st.screenType}</span>
                              <span className="block text-[11px] font-bold mt-1 text-amber-300">
                                {st.currency}{st.price}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Visual Cinema Seat Matrix */}
                  <div className="bg-[#2D2D2A] text-white rounded-3xl p-4 sm:p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <div>
                        <h4 className="font-serif font-bold text-sm text-white">Select Your Cinema Seats</h4>
                        <p className="text-[11px] text-stone-300">Tap seats to reserve ({selectedSeats.length} Selected)</p>
                      </div>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-emerald-500" /> Selected</span>
                        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-white/20" /> Available</span>
                        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-stone-700 opacity-50" /> Taken</span>
                      </div>
                    </div>

                    {/* Cinema Screen Curve */}
                    <div className="space-y-1 text-center">
                      <div className="h-1.5 w-3/4 mx-auto bg-gradient-to-r from-transparent via-amber-400 to-transparent rounded-full shadow-md" />
                      <span className="text-[10px] uppercase tracking-widest text-stone-400">All Eyes This Way · Cinema Screen</span>
                    </div>

                    {/* Seat Grid */}
                    <div className="space-y-2 pt-2">
                      {['A', 'B', 'C', 'D', 'E'].map((row) => {
                        const isVipRow = row === 'A' || row === 'B';
                        const isGoldRow = row === 'C' || row === 'D';
                        const tierName = isVipRow ? 'VIP Recliner (+₹120)' : isGoldRow ? 'Premium Gold (+₹50)' : 'Executive Silver';

                        return (
                          <div key={row} className="flex items-center justify-between gap-1 text-xs">
                            <span className="w-6 font-bold text-stone-400 text-center">{row}</span>
                            <div className="flex items-center justify-center gap-1.5 flex-1">
                              {[1, 2, 3, 4, 5, 6, 7, 8].map((col) => {
                                const seatId = `${row}${col}`;
                                const isSelected = selectedSeats.includes(seatId);
                                const isOccupied = (row === 'B' && col === 3) || (row === 'D' && col === 6);

                                return (
                                  <button
                                    key={col}
                                    type="button"
                                    disabled={isOccupied}
                                    onClick={() => handleToggleSeat(seatId)}
                                    className={`w-7 h-7 rounded-lg text-[10px] font-bold flex items-center justify-center transition-all ${
                                      isOccupied
                                        ? 'bg-stone-800 text-stone-600 cursor-not-allowed'
                                        : isSelected
                                        ? 'bg-emerald-500 text-white scale-110 shadow-md ring-2 ring-emerald-300 font-extrabold'
                                        : isVipRow
                                        ? 'bg-amber-500/30 text-amber-200 border border-amber-400/40 hover:bg-amber-400 hover:text-stone-900'
                                        : 'bg-white/10 text-stone-300 hover:bg-white/30'
                                    }`}
                                    title={`${seatId} (${tierName})`}
                                  >
                                    {col}
                                  </button>
                                );
                              })}
                            </div>
                            <span className="text-[9px] text-stone-400 w-16 text-right hidden sm:inline">{tierName.split('(')[0]}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Selected Seat Badges */}
                    <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-stone-400 text-[11px]">Chosen:</span>
                        {selectedSeats.map(s => (
                          <span key={s} className="px-2 py-0.5 rounded-md bg-emerald-500 text-white font-bold text-[11px]">
                            {s}
                          </span>
                        ))}
                      </div>
                      <span className="font-bold text-amber-300">
                        {selectedSeats.length} Seats
                      </span>
                    </div>
                  </div>

                  {/* F&B Snack Add-ons */}
                  <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-3xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-[#2D2D2A] flex items-center gap-1.5 uppercase tracking-wider">
                        <Coffee className="w-3.5 h-3.5 text-[#5A5A40]" />
                        <span>Cinema Concessions & Snack Combos:</span>
                      </h4>
                      <span className="text-[10px] text-[#8B8B6B]">Served directly at seat</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[
                        { name: 'Jumbo Caramel Popcorn Tub', price: 250, desc: 'Hot gourmet kettle-popped corn' },
                        { name: 'Nachos with Warm Cheese Dip', price: 220, desc: 'Crispy corn tortilla with jalapenos' },
                        { name: 'Chilled Artisanal Cold Brew (300ml)', price: 180, desc: 'Slow-steeped Arabica coffee' },
                        { name: 'Fountain Soda Combo (Large)', price: 150, desc: 'Choice of chilled beverage' },
                      ].map((snk) => {
                        const sel = selectedSnacks.find(s => s.name === snk.name);
                        const qty = sel?.quantity || 0;
                        return (
                          <div key={snk.name} className="bg-white border border-[#E5E2D9] rounded-2xl p-3 flex items-center justify-between gap-2">
                            <div className="truncate pr-1">
                              <span className="font-bold text-xs text-[#2D2D2A] block truncate">{snk.name}</span>
                              <span className="text-[10px] text-[#8B8B6B] block">{snk.desc}</span>
                              <span className="font-bold text-xs text-[#5A5A40]">₹{snk.price}</span>
                            </div>
                            <div className="flex items-center gap-1.5 bg-[#F4F1EA] border border-[#DEDACF] rounded-xl p-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleUpdateSnack(snk.name, -1, snk.price)}
                                className="w-6 h-6 rounded-lg bg-white text-[#2D2D2A] flex items-center justify-center font-bold hover:bg-[#EAE7DC]"
                              >
                                -
                              </button>
                              <span className="w-5 text-center font-bold text-xs">{qty}</span>
                              <button
                                type="button"
                                onClick={() => handleUpdateSnack(snk.name, 1, snk.price)}
                                className="w-6 h-6 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center font-bold hover:bg-[#484832]"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. TEMPLE BOOKING CONTROLS */}
              {resolvedCategory === 'temple' && (
                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40]">
                      Choose Darshan / Seva Type:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {[
                        { title: 'VIP Fast-Track Darshan Pass', price: place?.ticket.vipPrice ? `₹${place.ticket.vipPrice}` : '₹250', time: '10-15 min queue', desc: 'Direct fast-line entry near Garbhagudi' },
                        { title: 'Special Morning Abhishekam & Pooja', price: '₹500', time: 'Priority Seating', desc: 'Full Vedic chant offering & dedicated seating' },
                        { title: 'Special Archana Seva Pass', price: '₹100', time: 'Standard Seva Line', desc: 'Individual family name sankalpam offering' },
                        { title: 'General Devotee Darshan', price: 'FREE (₹0)', time: 'General Queue', desc: 'Standard temple darshan gate entry' },
                      ].map((darshan) => {
                        const isSel = selectedDarshan === darshan.title;
                        return (
                          <button
                            key={darshan.title}
                            type="button"
                            onClick={() => setSelectedDarshan(darshan.title)}
                            className={`p-3.5 rounded-2xl border text-left transition-all ${
                              isSel
                                ? 'bg-[#F4F1EA] border-[#5A5A40] ring-1 ring-[#5A5A40] shadow-xs'
                                : 'bg-white border-[#E5E2D9] hover:bg-[#F9F7F2]'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-xs text-[#2D2D2A]">{darshan.title}</span>
                              <span className="font-bold text-xs text-[#5A5A40] bg-[#EAE7DC] px-2 py-0.5 rounded-md">
                                {darshan.price}
                              </span>
                            </div>
                            <p className="text-[11px] text-[#8B8B6B] mt-1">{darshan.desc}</p>
                            <span className="text-[10px] text-emerald-700 font-bold block mt-1">⏳ {darshan.time}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Devotees Counter & Timing Slot */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3.5 space-y-2">
                      <label className="font-bold text-xs text-[#2D2D2A] block">Number of Devotees:</label>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#8B8B6B]">Family / Devotee count</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setTempleDevoteeCount(Math.max(1, templeDevoteeCount - 1))}
                            className="w-8 h-8 rounded-xl bg-white border border-[#DEDACF] font-bold text-sm hover:bg-[#EAE7DC]"
                          >
                            -
                          </button>
                          <span className="font-bold text-sm w-6 text-center">{templeDevoteeCount}</span>
                          <button
                            type="button"
                            onClick={() => setTempleDevoteeCount(Math.min(10, templeDevoteeCount + 1))}
                            className="w-8 h-8 rounded-xl bg-[#5A5A40] text-white font-bold text-sm hover:bg-[#484832]"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3.5 space-y-2">
                      <label className="font-bold text-xs text-[#2D2D2A] block">Aarti / Darshan Timing Slot:</label>
                      <select
                        value={templeSlot}
                        onChange={(e) => setTempleSlot(e.target.value)}
                        className="w-full p-2 bg-white border border-[#DEDACF] rounded-xl text-xs font-bold text-[#2D2D2A]"
                      >
                        <option value="06:30 AM Suprabhatam & Morning Darshan">06:30 AM Suprabhatam & Darshan</option>
                        <option value="09:30 AM Morning Pooja & Darshan">09:30 AM Morning Pooja & Darshan</option>
                        <option value="12:00 PM Madhyana Aarti & Darshan">12:00 PM Madhyana Aarti & Darshan</option>
                        <option value="04:30 PM Afternoon Darshan (Quiet Hours)">04:30 PM Afternoon (Quiet Hours)</option>
                        <option value="07:00 PM Sandhya Deepa Aarti & Darshan">07:00 PM Sandhya Aarti & Darshan</option>
                      </select>
                    </div>
                  </div>

                  {/* Prasaadam boxes & ID Proof */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-white border border-[#E5E2D9] rounded-2xl p-3.5 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="font-bold text-xs text-[#2D2D2A]">Laddoo / Prasaadam Boxes:</label>
                        <span className="font-bold text-xs text-[#5A5A40]">₹100/box</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-[#8B8B6B]">Sanctified temple offering</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setPrasaadamCount(Math.max(0, prasaadamCount - 1))}
                            className="w-7 h-7 rounded-lg bg-[#F4F1EA] font-bold text-xs hover:bg-[#EAE7DC]"
                          >
                            -
                          </button>
                          <span className="font-bold text-xs w-4 text-center">{prasaadamCount}</span>
                          <button
                            type="button"
                            onClick={() => setPrasaadamCount(prasaadamCount + 1)}
                            className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white font-bold text-xs hover:bg-[#484832]"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white border border-[#E5E2D9] rounded-2xl p-3.5 space-y-2">
                      <label className="font-bold text-xs text-[#2D2D2A]">Primary Devotee ID Proof:</label>
                      <input
                        type="text"
                        placeholder="e.g. Aadhaar / Passport / DL Number"
                        value={idProofNumber}
                        onChange={(e) => setIdProofNumber(e.target.value)}
                        className="w-full p-2 bg-[#FDFCF8] border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] placeholder:text-[#8B8B6B]"
                      />
                    </div>
                  </div>

                  {/* Dress Code Agreement */}
                  <label className="flex items-start gap-2.5 p-3.5 bg-[#FFF9F0] border border-[#F3E5D8] rounded-2xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={dressCodeAgreed}
                      onChange={(e) => setDressCodeAgreed(e.target.checked)}
                      className="mt-0.5 rounded text-[#5A5A40] focus:ring-[#5A5A40]"
                    />
                    <div className="text-[11px] text-[#5A5A40] leading-relaxed">
                      <strong>Mandatory Temple Dress Code Agreement:</strong> I confirm all devotees will wear traditional modest attire (Dhoti/Kurta for men, Saree/Salwar for women). Leather items and camera equipment are strictly prohibited inside inner sanctum.
                    </div>
                  </label>
                </div>
              )}

              {/* 3. RESTAURANT BOOKING CONTROLS */}
              {resolvedCategory === 'restaurant' && (
                <div className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3.5 space-y-1.5">
                      <label className="font-bold text-xs text-[#2D2D2A]">Party Size (Guests):</label>
                      <div className="flex items-center justify-between pt-1">
                        <button
                          type="button"
                          onClick={() => setPartySize(Math.max(1, partySize - 1))}
                          className="w-8 h-8 rounded-xl bg-white border border-[#DEDACF] font-bold text-sm"
                        >
                          -
                        </button>
                        <span className="font-bold text-base">{partySize} Guests</span>
                        <button
                          type="button"
                          onClick={() => setPartySize(Math.min(16, partySize + 1))}
                          className="w-8 h-8 rounded-xl bg-[#5A5A40] text-white font-bold text-sm"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3.5 space-y-1.5">
                      <label className="font-bold text-xs text-[#2D2D2A]">Meal Slot:</label>
                      <select
                        value={mealSlot}
                        onChange={(e) => setMealSlot(e.target.value)}
                        className="w-full p-2 bg-white border border-[#DEDACF] rounded-xl text-xs font-bold text-[#2D2D2A] mt-1"
                      >
                        <option value="Lunch">Lunch Service</option>
                        <option value="High Tea">High Tea & Snacks</option>
                        <option value="Sunset Dinner">Sunset Dinner</option>
                        <option value="Late Night Dining">Late Night Dining</option>
                      </select>
                    </div>

                    <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-3.5 space-y-1.5">
                      <label className="font-bold text-xs text-[#2D2D2A]">Preferred Time:</label>
                      <select
                        value={diningTime}
                        onChange={(e) => setDiningTime(e.target.value)}
                        className="w-full p-2 bg-white border border-[#DEDACF] rounded-xl text-xs font-bold text-[#2D2D2A] mt-1"
                      >
                        <option value="12:30 PM">12:30 PM</option>
                        <option value="01:15 PM">01:15 PM</option>
                        <option value="02:00 PM">02:00 PM</option>
                        <option value="07:00 PM">07:00 PM</option>
                        <option value="07:45 PM">07:45 PM</option>
                        <option value="08:30 PM">08:30 PM</option>
                        <option value="09:15 PM">09:15 PM</option>
                      </select>
                    </div>
                  </div>

                  {/* Seating Preference */}
                  <div className="space-y-2">
                    <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40]">
                      Select Seating Atmosphere:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        'Rooftop Panorama Terrace',
                        'Courtyard Heritage Garden',
                        'Indoor AC Family Hall',
                        'Chef’s Tasting Table',
                      ].map((area) => (
                        <button
                          key={area}
                          type="button"
                          onClick={() => setSeatingArea(area)}
                          className={`p-2.5 rounded-2xl border text-center text-xs font-bold transition-all ${
                            seatingArea === area
                              ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                              : 'bg-white text-[#2D2D2A] border-[#E5E2D9] hover:bg-[#F4F1EA]'
                          }`}
                        >
                          {area}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Optional Pre-order Signature Dishes */}
                  {place?.topDishes && place.topDishes.length > 0 && (
                    <div className="bg-[#E9F2E9] border border-[#D0E2CF] rounded-3xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-xs text-[#4A6741] flex items-center gap-1.5 uppercase tracking-wider">
                          <UtensilsCrossed className="w-3.5 h-3.5" />
                          <span>Pre-Order Signature Dishes (Optional):</span>
                        </h4>
                        <span className="text-[10px] text-[#4A6741] font-medium">Ready when you sit</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {place.topDishes.map((dish) => {
                          const qty = preOrderedDishes[dish.name] || 0;
                          return (
                            <div key={dish.name} className="bg-white border border-[#D0E2CF] rounded-2xl p-3 flex items-center justify-between gap-2">
                              <div className="truncate pr-1">
                                <span className="font-bold text-xs text-[#2D2D2A] block truncate">{dish.name}</span>
                                <span className="text-[10px] text-[#8B8B6B] block truncate">{dish.description}</span>
                                <span className="font-bold text-xs text-[#4A6741]">{dish.price}</span>
                              </div>
                              <div className="flex items-center gap-1.5 bg-[#E9F2E9] border border-[#D0E2CF] rounded-xl p-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleTogglePreOrderDish(dish.name, -1)}
                                  className="w-6 h-6 rounded-lg bg-white text-[#2D2D2A] flex items-center justify-center font-bold"
                                >
                                  -
                                </button>
                                <span className="w-4 text-center font-bold text-xs">{qty}</span>
                                <button
                                  type="button"
                                  onClick={() => handleTogglePreOrderDish(dish.name, 1)}
                                  className="w-6 h-6 rounded-lg bg-[#4A6741] text-white flex items-center justify-center font-bold"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Special Instructions */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-xs text-[#2D2D2A]">Special Requests & Dietary Preferences:</label>
                    <input
                      type="text"
                      value={specialInstructions}
                      onChange={(e) => setSpecialInstructions(e.target.value)}
                      placeholder="e.g. Birthday candle, low salt, high-chair needed"
                      className="w-full p-2.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A]"
                    />
                  </div>
                </div>
              )}

              {/* 4. ATTRACTION / MONUMENT BOOKING CONTROLS */}
              {resolvedCategory === 'attraction' && (
                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40]">
                      Select Entry Slot:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {[
                        'Morning Entry (09:00 AM - 12:30 PM)',
                        'Afternoon Entry (12:30 PM - 04:00 PM)',
                        'Sunset Entry (04:00 PM - 06:30 PM)',
                      ].map((slot) => (
                        <button
                          key={slot}
                          type="button"
                          onClick={() => setAttractionEntrySlot(slot)}
                          className={`p-3 rounded-2xl border text-center text-xs font-bold transition-all ${
                            attractionEntrySlot === slot
                              ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                              : 'bg-white text-[#2D2D2A] border-[#E5E2D9] hover:bg-[#F4F1EA]'
                          }`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Ticket Types Counters */}
                  <div className="bg-[#FFF9F0] border border-[#F3E5D8] rounded-3xl p-4 space-y-3">
                    <h4 className="font-bold text-xs text-[#C2410C] uppercase tracking-wider">
                      Visitor Ticket Breakdown:
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      {/* Adult */}
                      <div className="bg-white p-3 rounded-2xl border border-[#F3E5D8] flex items-center justify-between">
                        <div>
                          <span className="font-bold text-[#2D2D2A] block">Adult (General)</span>
                          <span className="text-[#8B8B6B] text-[11px]">
                            {place?.ticket.isFree ? 'FREE' : `${place?.ticket.currency}${place?.ticket.generalPrice}`}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setAttractionAdults(Math.max(1, attractionAdults - 1))}
                            className="w-7 h-7 rounded-lg bg-[#F4F1EA] font-bold"
                          >
                            -
                          </button>
                          <span className="font-bold w-4 text-center">{attractionAdults}</span>
                          <button
                            type="button"
                            onClick={() => setAttractionAdults(attractionAdults + 1)}
                            className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white font-bold"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Child */}
                      <div className="bg-white p-3 rounded-2xl border border-[#F3E5D8] flex items-center justify-between">
                        <div>
                          <span className="font-bold text-[#2D2D2A] block">Child (&lt;12 Years)</span>
                          <span className="text-[#8B8B6B] text-[11px]">
                            {place?.ticket.childPrice ? `${place.ticket.currency}${place.ticket.childPrice}` : '50% Off / Free'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setAttractionChildren(Math.max(0, attractionChildren - 1))}
                            className="w-7 h-7 rounded-lg bg-[#F4F1EA] font-bold"
                          >
                            -
                          </button>
                          <span className="font-bold w-4 text-center">{attractionChildren}</span>
                          <button
                            type="button"
                            onClick={() => setAttractionChildren(attractionChildren + 1)}
                            className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white font-bold"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Foreign Tourist */}
                      <div className="bg-white p-3 rounded-2xl border border-[#F3E5D8] flex items-center justify-between">
                        <div>
                          <span className="font-bold text-[#2D2D2A] block">International Visitor</span>
                          <span className="text-[#8B8B6B] text-[11px]">
                            {place?.ticket.foreignTouristPrice ? `${place.ticket.currency}${place.ticket.foreignTouristPrice}` : 'Standard Foreign Pass'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setAttractionForeigners(Math.max(0, attractionForeigners - 1))}
                            className="w-7 h-7 rounded-lg bg-[#F4F1EA] font-bold"
                          >
                            -
                          </button>
                          <span className="font-bold w-4 text-center">{attractionForeigners}</span>
                          <button
                            type="button"
                            onClick={() => setAttractionForeigners(attractionForeigners + 1)}
                            className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white font-bold"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Audio Guide */}
                      <div className="bg-white p-3 rounded-2xl border border-[#F3E5D8] flex items-center justify-between">
                        <div>
                          <span className="font-bold text-[#2D2D2A] block">Smart Audio Headset</span>
                          <span className="text-[#8B8B6B] text-[11px]">₹150 / 8 languages</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setAudioGuides(Math.max(0, audioGuides - 1))}
                            className="w-7 h-7 rounded-lg bg-[#F4F1EA] font-bold"
                          >
                            -
                          </button>
                          <span className="font-bold w-4 text-center">{audioGuides}</span>
                          <button
                            type="button"
                            onClick={() => setAudioGuides(audioGuides + 1)}
                            className="w-7 h-7 rounded-lg bg-[#5A5A40] text-white font-bold"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 5. EVENT BOOKING CONTROLS */}
              {resolvedCategory === 'event' && (
                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40]">
                      Select Ticket Category / Tier:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        { tier: 'General Admission Pass', price: event?.isFree ? 'FREE' : `${currency}${event?.ticketPrice || 350}`, desc: 'Access to main grounds and live stage' },
                        { tier: 'VIP Front Lounge & Reserved Seating', price: `${currency}${((typeof event?.ticketPrice === 'number' ? event.ticketPrice : 350) * 2.5) || 999}`, desc: 'Dedicated fast entry, complimentary drinks & prime viewing' },
                      ].map((t) => (
                        <button
                          key={t.tier}
                          type="button"
                          onClick={() => setEventTier(t.tier)}
                          className={`p-3.5 rounded-2xl border text-left transition-all ${
                            eventTier === t.tier
                              ? 'bg-[#F4F1EA] border-[#5A5A40] ring-1 ring-[#5A5A40] shadow-xs'
                              : 'bg-white border-[#E5E2D9] hover:bg-[#F9F7F2]'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-xs text-[#2D2D2A]">{t.tier}</span>
                            <span className="font-bold text-xs text-[#C2410C]">{t.price}</span>
                          </div>
                          <p className="text-[11px] text-[#8B8B6B] mt-1">{t.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-xs text-[#2D2D2A] block">Number of Attendees:</span>
                      <span className="text-[11px] text-[#8B8B6B]">Max 10 passes per transaction</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setEventTicketsCount(Math.max(1, eventTicketsCount - 1))}
                        className="w-8 h-8 rounded-xl bg-white border border-[#DEDACF] font-bold text-sm"
                      >
                        -
                      </button>
                      <span className="font-bold text-sm w-6 text-center">{eventTicketsCount}</span>
                      <button
                        type="button"
                        onClick={() => setEventTicketsCount(Math.min(10, eventTicketsCount + 1))}
                        className="w-8 h-8 rounded-xl bg-[#5A5A40] text-white font-bold text-sm"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 2: CONTACT & INSTANT PAYMENT */}
          {step === 2 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-200">
              {/* Order Summary Recap Box */}
              <div className="bg-[#2D2D2A] text-white rounded-3xl p-4 sm:p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <span className="font-serif font-bold text-sm text-white">Booking Summary</span>
                  <span className="text-xs text-amber-300 font-bold">{selectedDate}</span>
                </div>

                <div className="space-y-1.5 text-xs text-stone-300">
                  <div className="flex justify-between">
                    <span>Item:</span>
                    <strong className="text-white">{itemTitle}</strong>
                  </div>

                  {resolvedCategory === 'theatre' && (
                    <>
                      <div className="flex justify-between">
                        <span>Movie & Format:</span>
                        <span className="text-white">{selectedMovie?.title} ({selectedShowtime.screenType})</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Seats ({selectedSeats.length}):</span>
                        <span className="font-bold text-emerald-300">{selectedSeats.join(', ')}</span>
                      </div>
                      {selectedSnacks.filter(s => s.quantity > 0).length > 0 && (
                        <div className="flex justify-between text-[11px] text-stone-400">
                          <span>Snacks:</span>
                          <span>{selectedSnacks.filter(s => s.quantity > 0).map(s => `${s.quantity}x ${s.name.split('(')[0]}`).join(', ')}</span>
                        </div>
                      )}
                    </>
                  )}

                  {resolvedCategory === 'temple' && (
                    <>
                      <div className="flex justify-between">
                        <span>Darshan Seva:</span>
                        <span className="text-white">{selectedDarshan}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Devotees:</span>
                        <span className="text-white">{templeDevoteeCount} Devotee(s)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aarti Slot:</span>
                        <span className="text-amber-300 font-medium">{templeSlot}</span>
                      </div>
                    </>
                  )}

                  {resolvedCategory === 'restaurant' && (
                    <>
                      <div className="flex justify-between">
                        <span>Party Size & Area:</span>
                        <span className="text-white">{partySize} Guests · {seatingArea}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Time:</span>
                        <span className="text-amber-300">{diningTime} ({mealSlot})</span>
                      </div>
                    </>
                  )}

                  {resolvedCategory === 'attraction' && (
                    <div className="flex justify-between">
                      <span>Visitors:</span>
                      <span className="text-white">
                        {attractionAdults} Adults{attractionChildren > 0 ? `, ${attractionChildren} Kids` : ''}{attractionForeigners > 0 ? `, ${attractionForeigners} Foreigners` : ''}
                      </span>
                    </div>
                  )}

                  {resolvedCategory === 'event' && (
                    <div className="flex justify-between">
                      <span>Passes:</span>
                      <span className="text-white">{eventTicketsCount}x {eventTier}</span>
                    </div>
                  )}

                  <div className="flex justify-between pt-2 border-t border-white/10 text-sm font-bold text-white">
                    <span>Total Amount Payable:</span>
                    <span className="text-amber-300 text-base">
                      {totalAmount === 0 ? 'FREE ADMISSION' : `${currency}${totalAmount}`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Guest Information */}
              <div className="bg-[#F4F1EA] border border-[#DEDACF] rounded-3xl p-4 sm:p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-serif font-bold text-sm text-[#2D2D2A] flex items-center gap-2">
                    <User className="w-4 h-4 text-[#5A5A40]" />
                    <span>Primary Guest & E-Ticket Delivery Details</span>
                  </h4>

                  {currentUser && (
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Autofilled from {currentUser.name}</span>
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                  {/* Name field with quick edit trigger */}
                  <div className="space-y-1.5 bg-white p-3 rounded-2xl border border-[#DEDACF]">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-[#2D2D2A] flex items-center gap-1">
                        <span>Full Name:</span>
                        <span className="text-[#C2410C]">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsEditingName(!isEditingName)}
                        className="text-[11px] font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1 px-2 py-0.5 rounded-md hover:bg-[#F4F1EA] transition-colors"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>{isEditingName ? 'Done Editing' : 'Edit Name'}</span>
                      </button>
                    </div>

                    <input
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className={`w-full p-2.5 rounded-xl text-xs transition-all ${
                        isEditingName
                          ? 'bg-amber-50 border-2 border-amber-400 font-bold text-[#2D2D2A] ring-2 ring-amber-200'
                          : 'bg-[#FDFCF8] border border-[#DEDACF] text-[#2D2D2A]'
                      }`}
                    />
                    {isEditingName && (
                      <p className="text-[10px] text-amber-700 font-medium">
                        ✎ You are customizing the ticket name for this specific booking.
                      </p>
                    )}
                  </div>

                  {/* Phone field with quick edit trigger */}
                  <div className="space-y-1.5 bg-white p-3 rounded-2xl border border-[#DEDACF]">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-[#2D2D2A] flex items-center gap-1">
                        <span>Mobile Phone:</span>
                        <span className="text-[#C2410C]">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsEditingPhone(!isEditingPhone)}
                        className="text-[11px] font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1 px-2 py-0.5 rounded-md hover:bg-[#F4F1EA] transition-colors"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>{isEditingPhone ? 'Done Editing' : 'Edit Phone'}</span>
                      </button>
                    </div>

                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className={`w-full p-2.5 rounded-xl text-xs transition-all ${
                        isEditingPhone
                          ? 'bg-amber-50 border-2 border-amber-400 font-bold text-[#2D2D2A] ring-2 ring-amber-200'
                          : 'bg-[#FDFCF8] border border-[#DEDACF] text-[#2D2D2A]'
                      }`}
                    />
                    <p className="text-[10px] text-[#8B8B6B]">
                      Used for sending instant SMS booking confirmation & QR pass link.
                    </p>
                  </div>

                  {/* Email field with quick edit trigger */}
                  <div className="sm:col-span-2 space-y-1.5 bg-white p-3 rounded-2xl border border-[#DEDACF]">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-[#2D2D2A] flex items-center gap-1">
                        <span>Email Address:</span>
                        <span className="text-[#C2410C]">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsEditingEmail(!isEditingEmail)}
                        className="text-[11px] font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1 px-2 py-0.5 rounded-md hover:bg-[#F4F1EA] transition-colors"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>{isEditingEmail ? 'Done Editing' : 'Edit Email'}</span>
                      </button>
                    </div>

                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="alex.johnson@traveler.com"
                      className={`w-full p-2.5 rounded-xl text-xs transition-all ${
                        isEditingEmail
                          ? 'bg-amber-50 border-2 border-amber-400 font-bold text-[#2D2D2A] ring-2 ring-amber-200'
                          : 'bg-[#FDFCF8] border border-[#DEDACF] text-[#2D2D2A]'
                      }`}
                    />
                    <p className="text-[10px] text-[#8B8B6B]">
                      Official PDF invoice, seat vouchers, and calendar invites are sent here.
                    </p>
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-3">
                <label className="font-bold text-xs uppercase tracking-wider text-[#5A5A40] flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Select Instant Payment Mode:</span>
                </label>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  {[
                    { id: 'UPI', label: 'Instant UPI (GPay / PhonePe / Paytm)', badge: 'Fastest ⚡' },
                    { id: 'Card', label: 'Credit / Debit Card (Visa/Mastercard)', badge: 'Secure' },
                    { id: 'ApplePay', label: 'Apple Pay / Google Pay', badge: '1-Tap' },
                    { id: 'NetBanking', label: 'Net Banking (All Major Banks)', badge: 'Instant' },
                    { id: 'PayAtCounter', label: 'Pay at Box Office / Counter', badge: 'Flexible' },
                  ].map((pm) => {
                    const isSel = paymentMethod === pm.id;
                    return (
                      <button
                        key={pm.id}
                        type="button"
                        onClick={() => setPaymentMethod(pm.id as any)}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          isSel
                            ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                            : 'bg-white text-[#2D2D2A] border-[#E5E2D9] hover:bg-[#F4F1EA]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs">{pm.id}</span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-md ${
                            isSel ? 'bg-amber-300 text-[#2D2D2A]' : 'bg-[#F4F1EA] text-[#5A5A40]'
                          }`}>
                            {pm.badge}
                          </span>
                        </div>
                        <p className="text-[10px] opacity-85 mt-1 leading-tight">{pm.label}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
                <span>Instant Confirmation Guarantee with Official Gate Scanning & 100% Verified Entry.</span>
              </div>
            </div>
          )}

          {/* STEP 3: INSTANT CONFIRMED DIGITAL E-TICKET PASS */}
          {step === 3 && confirmedBooking && (
            <div className="space-y-6 animate-in zoom-in-95 duration-300">
              {/* Confirmed Banner */}
              <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center gap-3">
                <CheckCircle2 className="w-7 h-7 text-emerald-600 shrink-0" />
                <div>
                  <h3 className="font-serif font-bold text-base text-emerald-950">
                    Booking Confirmed & E-Ticket Generated!
                  </h3>
                  <p className="text-xs text-emerald-800">
                    Your official digital pass has been issued and stored in your My Bookings wallet.
                  </p>
                </div>
              </div>

              {/* Digital Boarding Pass Ticket Component */}
              <div className="bg-[#2D2D2A] text-white rounded-3xl overflow-hidden shadow-xl border border-[#5A5A40]/40">
                {/* Top Section */}
                <div className="p-5 sm:p-6 bg-gradient-to-br from-[#2D2D2A] via-[#3A3A35] to-[#2D2D2A] space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-xl bg-amber-400 text-[#2D2D2A] flex items-center justify-center font-bold text-sm">
                        {confirmedBooking.category === 'theatre' && '🎬'}
                        {confirmedBooking.category === 'temple' && '🛕'}
                        {confirmedBooking.category === 'restaurant' && '🍽️'}
                        {confirmedBooking.category === 'attraction' && '🏛️'}
                        {confirmedBooking.category === 'event' && '🎉'}
                      </span>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-amber-300 tracking-wider block">Official Digital Pass</span>
                        <h4 className="font-serif font-bold text-lg text-white">{confirmedBooking.itemTitle}</h4>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-400 text-emerald-300 rounded-full text-xs font-bold">
                      ● {confirmedBooking.paymentStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-white/10 text-xs">
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase">Booking Ref:</span>
                      <span className="font-mono font-bold text-amber-300 text-sm">{confirmedBooking.bookingRef}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase">Date of Visit:</span>
                      <span className="font-bold text-white text-sm">{confirmedBooking.serviceDate}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase">Time / Slot:</span>
                      <span className="font-bold text-white text-sm">{confirmedBooking.serviceTime}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px] uppercase">Guest Name:</span>
                      <span className="font-bold text-white text-sm truncate block">{confirmedBooking.customerName}</span>
                    </div>
                  </div>
                </div>

                {/* Dashed Separator Line with Semi-Circle Cutouts */}
                <div className="relative flex items-center">
                  <div className="w-4 h-8 bg-[#FDFCF8] rounded-r-full -ml-1 border-r border-[#E5E2D9]" />
                  <div className="flex-1 border-b-2 border-dashed border-white/20 mx-2" />
                  <div className="w-4 h-8 bg-[#FDFCF8] rounded-l-full -mr-1 border-l border-[#E5E2D9]" />
                </div>

                {/* Bottom QR & Barcode Section */}
                <div className="p-5 sm:p-6 bg-[#252522] flex flex-col sm:flex-row items-center justify-between gap-5">
                  <div className="space-y-2 text-xs text-stone-300 text-center sm:text-left">
                    <p className="font-bold text-white text-sm">Present this QR at Entrance Gate / Turnstile</p>
                    <p className="text-[11px] text-stone-400 max-w-xs">
                      Venue Address: {confirmedBooking.itemAddress}
                    </p>
                    {confirmedBooking.details.selectedSeats && (
                      <p className="text-emerald-300 font-bold text-xs">
                        Assigned Seats: {confirmedBooking.details.selectedSeats.join(', ')}
                      </p>
                    )}
                    <p className="text-[10px] text-stone-400">
                      Payment Mode: {confirmedBooking.paymentMethod} · Total: {confirmedBooking.currency}{confirmedBooking.totalAmount}
                    </p>
                  </div>

                  {/* Scannable Visual QR Code Box */}
                  <div className="bg-white p-3 rounded-2xl flex flex-col items-center shrink-0 shadow-md">
                    <QrCode className="w-24 h-24 text-[#2D2D2A]" />
                    <span className="font-mono text-[9px] text-[#2D2D2A] font-bold mt-1 tracking-widest">
                      {confirmedBooking.bookingRef}
                    </span>
                  </div>
                </div>

                {/* Mobile Ticket Saved Banner */}
                <div className="p-3 bg-emerald-50/90 border border-emerald-200/80 rounded-xl flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 text-emerald-900 font-medium">
                    <Smartphone className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>PDF Ticket automatically downloaded & ready on your device.</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-200/60 text-emerald-900 text-[10px] font-bold uppercase tracking-wider">
                    OFFLINE READY
                  </span>
                </div>
              </div>

              {/* Action Buttons for Confirmed Pass */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                <button
                  type="button"
                  onClick={() => downloadTicketPDF(confirmedBooking, cityName, false)}
                  className="py-3 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  <Download className="w-4 h-4 text-emerald-200" />
                  <span>Save PDF to Mobile</span>
                </button>

                <button
                  type="button"
                  onClick={() => downloadTicketPDF(confirmedBooking, cityName, true)}
                  className="py-3 px-3 bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] border border-[#DEDACF] rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <Share2 className="w-4 h-4 text-[#D28E5D]" />
                  <span>Share / Send Pass</span>
                </button>

                {onAddToItinerary && (
                  <button
                    type="button"
                    onClick={() => {
                      onAddToItinerary(confirmedBooking);
                      onClose();
                    }}
                    className="py-3 px-3 bg-[#5A5A40] hover:bg-[#484832] text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
                  >
                    <CalendarPlus className="w-4 h-4 text-amber-300" />
                    <span>Add to Itinerary</span>
                  </button>
                )}

                {onOpenMyBookings && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenMyBookings();
                    }}
                    className="py-3 px-3 bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
                  >
                    <Receipt className="w-4 h-4 text-emerald-400" />
                    <span>My Bookings</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        {step !== 3 && (
          <div className="p-4 sm:p-5 bg-[#F4F1EA] border-t border-[#DEDACF] flex items-center justify-between gap-3 shrink-0">
            {step === 1 ? (
              <>
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#8B8B6B] block">Total Estimated Cost:</span>
                  <span className="font-serif font-bold text-lg text-[#2D2D2A]">
                    {totalAmount === 0 ? 'FREE' : `${currency}${totalAmount}`}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-2.5 px-4 bg-white hover:bg-[#EAE7DC] text-[#5A5A40] border border-[#DEDACF] rounded-xl font-bold text-xs transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="py-2.5 px-5 bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md"
                  >
                    <span>Proceed to Guest & Pay</span>
                    <ChevronRight className="w-4 h-4 text-amber-300" />
                  </button>
                </div>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="py-2.5 px-4 bg-white hover:bg-[#EAE7DC] text-[#5A5A40] border border-[#DEDACF] rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Slots & Seats</span>
                </button>

                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmAndPay}
                  className="py-2.5 px-6 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl font-bold text-xs flex items-center gap-2 transition-all shadow-md"
                >
                  {isProcessing ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Processing Official Booking...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-amber-300" />
                      <span>
                        {paymentMethod === 'PayAtCounter' ? 'Confirm Reservation' : `Pay ${currency}${totalAmount} & Confirm`}
                      </span>
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
