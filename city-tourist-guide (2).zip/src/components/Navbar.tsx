import React from 'react';
import { City, PlaceCategory, UserAccount } from '../types';
import { 
  Compass, 
  MapPin, 
  Film, 
  Sparkles, 
  UtensilsCrossed, 
  Landmark, 
  Map as MapIcon, 
  Ticket, 
  Bot, 
  Plus, 
  ChevronDown,
  Calendar,
  PartyPopper,
  Shield,
  User,
  LogIn,
  LogOut
} from 'lucide-react';

export type AppViewMode = 'all' | 'theatre' | 'temple' | 'restaurant' | 'attraction' | 'events' | 'itinerary' | 'map';

interface NavbarProps {
  cities: City[];
  activeCity: City;
  onSelectCity: (city: City) => void;
  activeView: AppViewMode;
  onSelectView: (view: AppViewMode) => void;
  itineraryItemCount: number;
  eventsCount: number;
  bookingsCount?: number;
  onOpenAIModal: () => void;
  onOpenExploreModal: () => void;
  onOpenMyBookings?: () => void;
  onOpenSplashThumbnail?: () => void;
  currentUser?: UserAccount | null;
  onOpenUserAuth?: () => void;
  onOpenAdminPortal?: () => void;
  onOpenIndiaJoyModal?: () => void;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cities,
  activeCity,
  onSelectCity,
  activeView,
  onSelectView,
  itineraryItemCount,
  eventsCount,
  bookingsCount = 0,
  onOpenAIModal,
  onOpenExploreModal,
  onOpenMyBookings,
  onOpenSplashThumbnail,
  currentUser,
  onOpenUserAuth,
  onOpenAdminPortal,
  onOpenIndiaJoyModal,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FDFCF8]/95 backdrop-blur-md border-b border-[#E5E2D9] shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Top Navbar Row */}
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Brand */}
          <div 
            onClick={() => onSelectView('all')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-2xl bg-[#5A5A40] text-white flex items-center justify-center font-serif font-extrabold shadow-sm group-hover:scale-105 transition-transform">
              <Compass className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif font-bold text-base tracking-tight text-[#2D2D2A] block leading-tight">
                  City Tourist Guide
                </span>
                {onOpenSplashThumbnail && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenSplashThumbnail();
                    }}
                    className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[10px] text-[#5A5A40] border border-[#DEDACF] transition-colors"
                    title="View App Thumbnail Card"
                  >
                    Intro
                  </button>
                )}
              </div>
              <span className="text-[11px] text-[#8B8B6B] font-medium block">
                created by jeevan m k
              </span>
            </div>
          </div>

          {/* City Selector Dropdown in Natural Tones */}
          <div className="flex items-center gap-2">
            <div className="relative group">
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl border border-[#DEDACF] bg-[#F4F1EA] hover:bg-[#EAE7DC] cursor-pointer text-xs font-bold text-[#2D2D2A] transition-colors shadow-2xs">
                <MapPin className="w-4 h-4 text-[#D28E5D] shrink-0" />
                <span>{activeCity.name}</span>
                <ChevronDown className="w-3.5 h-3.5 text-[#8B8B6B]" />
              </div>

              {/* Dropdown Menu */}
              <div className="absolute top-full left-0 mt-1 w-64 bg-[#FDFCF8] border border-[#DEDACF] rounded-2xl shadow-xl p-1.5 hidden group-hover:block z-50 animate-in fade-in slide-in-from-top-1">
                {onOpenIndiaJoyModal && (
                  <div className="p-1 mb-1 border-b border-[#E5E2D9]">
                    <button
                      onClick={onOpenIndiaJoyModal}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300/70 flex items-center justify-between transition-colors shadow-2xs"
                    >
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                        <span>🇮🇳 All 28 Indian States</span>
                      </div>
                      <span className="text-[10px] bg-amber-200/80 text-amber-900 px-1.5 py-0.2 rounded-md font-bold">Joy</span>
                    </button>
                  </div>
                )}

                <div className="text-[10px] font-bold text-[#8B8B6B] px-3 py-1 uppercase tracking-wider">
                  Featured Cities
                </div>
                {cities.map((city) => (
                  <button
                    key={city.id}
                    onClick={() => onSelectCity(city)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                      activeCity.id === city.id
                        ? 'bg-[#F4F1EA] text-[#5A5A40] font-bold'
                        : 'text-[#3D3D3D] hover:bg-[#F9F7F2]'
                    }`}
                  >
                    <div>
                      <span className="block font-semibold">{city.name}</span>
                      <span className="text-[10px] text-[#8B8B6B] font-normal">{city.country}</span>
                    </div>
                    {activeCity.id === city.id && (
                      <span className="w-2 h-2 rounded-full bg-[#5A5A40]" />
                    )}
                  </button>
                ))}

                <div className="border-t border-[#E5E2D9] mt-1 pt-1 space-y-1">
                  {onOpenIndiaJoyModal && (
                    <button
                      onClick={onOpenIndiaJoyModal}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-[#5A5A40] hover:bg-[#F4F1EA] flex items-center gap-1.5 transition-colors"
                    >
                      <Landmark className="w-3.5 h-3.5 text-[#5A5A40]" />
                      <span>Browse Every District in India...</span>
                    </button>
                  )}
                  <button
                    onClick={onOpenExploreModal}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-[#C2410C] hover:bg-[#FFF9F0] flex items-center gap-1.5 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Explore World City (AI)...</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Direct India States & Districts Explorer Quick Button */}
            {onOpenIndiaJoyModal && (
              <button
                type="button"
                onClick={onOpenIndiaJoyModal}
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-2xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all shadow-2xs"
                title="Explore every state & district in India"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>All India Districts</span>
              </button>
            )}
          </div>

          {/* Right Action Tools */}
          <div className="flex items-center gap-2">
            {/* User Auth / Profile Button */}
            {onOpenUserAuth && (
              <button
                id="nav-btn-user-auth"
                onClick={onOpenUserAuth}
                className="flex items-center gap-1.5 px-3 py-2 rounded-2xl border border-[#DEDACF] bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-xs font-bold transition-all shadow-2xs"
                title={currentUser ? `Logged in as ${currentUser.name}` : "User Sign In / Register"}
              >
                {currentUser ? (
                  <>
                    <div className="w-4 h-4 rounded-full bg-[#5A5A40] text-white flex items-center justify-center text-[10px] font-bold">
                      {currentUser.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="max-w-[80px] sm:max-w-[110px] truncate">{currentUser.name}</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-3.5 h-3.5 text-[#5A5A40]" />
                    <span className="hidden sm:inline">Sign In</span>
                  </>
                )}
              </button>
            )}

            {/* Separate Admin Portal Button (Locked for Jeevan M K) */}
            {onOpenAdminPortal && (
              <button
                id="nav-btn-admin-portal"
                onClick={onOpenAdminPortal}
                className="flex items-center gap-1.5 px-3 py-2 rounded-2xl border border-amber-600/30 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all shadow-2xs"
                title="Admin Command Portal (Password Protected: jeevan m k)"
              >
                <Shield className="w-3.5 h-3.5 text-amber-600" />
                <span className="hidden md:inline">Admin Portal</span>
                <span className="text-[10px] bg-amber-200/80 text-amber-900 px-1 py-0.2 rounded-md font-mono font-bold hidden lg:inline">
                  jeevan m k
                </span>
              </button>
            )}

            {/* My Bookings Wallet Button */}
            {onOpenMyBookings && (
              <button
                id="nav-btn-bookings"
                onClick={onOpenMyBookings}
                className="relative flex items-center gap-1.5 px-3 py-2 rounded-2xl border border-[#DEDACF] bg-[#FFF9F0] hover:bg-[#FBE8D6] text-[#C2410C] text-xs font-bold transition-all shadow-2xs"
                title="My Bookings & Passes"
              >
                <Ticket className="w-4 h-4 text-[#C2410C]" />
                <span className="hidden sm:inline">My Bookings</span>
                {bookingsCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-[#C2410C] text-white">
                    {bookingsCount}
                  </span>
                )}
              </button>
            )}

            {/* Itinerary Planner Button */}
            <button
              id="nav-btn-itinerary"
              onClick={() => onSelectView('itinerary')}
              className={`relative flex items-center gap-1.5 px-3 py-2 rounded-2xl border text-xs font-bold transition-all shadow-2xs ${
                activeView === 'itinerary'
                  ? 'bg-[#5A5A40] text-white border-[#5A5A40]'
                  : 'border-[#DEDACF] bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A]'
              }`}
              title="Personalized Itinerary Planner"
            >
              <Calendar className={`w-4 h-4 ${activeView === 'itinerary' ? 'text-amber-300' : 'text-[#5A5A40]'}`} />
              <span className="hidden sm:inline">My Itinerary</span>
              {itineraryItemCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-[#5A5A40] text-white">
                  {itineraryItemCount}
                </span>
              )}
            </button>

            {/* AI Tourist Concierge */}
            <button
              id="nav-btn-ai"
              onClick={onOpenAIModal}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white text-xs font-bold transition-colors shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Ask AI</span>
            </button>

            {/* Exit App / Return to Login Button */}
            {onLogout && (
              <button
                id="nav-btn-exit-app"
                onClick={onLogout}
                className="flex items-center gap-1.5 px-3 py-2 rounded-2xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-bold transition-all shadow-2xs cursor-pointer"
                title="Exit App & Return to Login Screen"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-600" />
                <span className="hidden sm:inline">Exit App</span>
              </button>
            )}
          </div>
        </div>

        {/* Category Navigation Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-2 border-t border-[#E5E2D9] text-xs scrollbar-none">
          <button
            id="tab-all"
            onClick={() => onSelectView('all')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'all'
                ? 'bg-[#2D2D2A] text-white shadow-xs'
                : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>All Directory</span>
          </button>

          <button
            id="tab-events"
            onClick={() => onSelectView('events')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'events'
                ? 'bg-[#C2410C] text-white shadow-xs'
                : 'text-[#C2410C] bg-[#FFF9F0] hover:bg-[#FBE8D6] border border-[#F3E5D8]'
            }`}
          >
            <PartyPopper className="w-3.5 h-3.5" />
            <span>Events Near Me</span>
            {eventsCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-extrabold ${activeView === 'events' ? 'bg-white text-[#C2410C]' : 'bg-[#C2410C] text-white'}`}>
                {eventsCount}
              </span>
            )}
          </button>

          <button
            id="tab-itinerary"
            onClick={() => onSelectView('itinerary')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'itinerary'
                ? 'bg-[#5A5A40] text-white shadow-xs'
                : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5 text-[#8B8B6B]" />
            <span>Personalized Itinerary Planner</span>
          </button>

          <button
            id="tab-theatres"
            onClick={() => onSelectView('theatre')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'theatre'
                ? 'bg-[#5A5A40] text-white shadow-xs'
                : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <Film className="w-3.5 h-3.5 text-[#8B8B6B]" />
            <span>Nearby Theatres & Movies</span>
          </button>

          <button
            id="tab-temples"
            onClick={() => onSelectView('temple')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'temple'
                ? 'bg-[#8B8B6B] text-white shadow-xs'
                : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#8B8B6B]" />
            <span>Temples & Crowd Radar</span>
          </button>

          <button
            id="tab-restaurants"
            onClick={() => onSelectView('restaurant')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'restaurant'
                ? 'bg-[#4A6741] text-white shadow-xs'
                : 'text-[#4A6741] hover:bg-[#E9F2E9]'
            }`}
          >
            <UtensilsCrossed className="w-3.5 h-3.5 text-[#4A6741]" />
            <span>Restaurants & Rated Food</span>
          </button>

          <button
            id="tab-attractions"
            onClick={() => onSelectView('attraction')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'attraction'
                ? 'bg-[#C2410C] text-white shadow-xs'
                : 'text-[#C2410C] hover:bg-[#FFF9F0]'
            }`}
          >
            <Landmark className="w-3.5 h-3.5 text-[#C2410C]" />
            <span>Attractions & Entry Tickets</span>
          </button>

          <button
            id="tab-map"
            onClick={() => onSelectView('map')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeView === 'map'
                ? 'bg-[#2D2D2A] text-white shadow-xs'
                : 'text-[#5A5A40] hover:bg-[#F4F1EA]'
            }`}
          >
            <MapIcon className="w-3.5 h-3.5" />
            <span>Interactive Map & Routes</span>
          </button>
        </div>
      </div>
    </header>
  );
};
