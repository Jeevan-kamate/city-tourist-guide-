import React, { useState } from 'react';
import { Place, Review } from '../types';
import { 
  X, 
  Star, 
  MapPin, 
  Clock, 
  Ticket, 
  Users, 
  Film, 
  UtensilsCrossed, 
  Landmark, 
  Sparkles, 
  Phone, 
  Globe, 
  Share2, 
  ThumbsUp, 
  MessageSquarePlus, 
  ShieldCheck, 
  Flame, 
  Check, 
  Info,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { CrowdVisualizer } from './CrowdVisualizer';
import { WriteReviewModal } from './WriteReviewModal';

interface PlaceDetailModalProps {
  place: Place | null;
  isOpen: boolean;
  onClose: () => void;
  onShowOnMap: (place: Place) => void;
  onToggleBudget?: (place: Place) => void;
  isSavedInBudget?: boolean;
  onAddToItinerary?: (place: Place) => void;
  isSavedInItinerary?: boolean;
  onAddReview: (placeId: string, review: Review) => void;
  onBookDirectly?: (target: { place: Place; category: any; movie?: any; showtime?: any }) => void;
}

export const PlaceDetailModal: React.FC<PlaceDetailModalProps> = ({
  place,
  isOpen,
  onClose,
  onShowOnMap,
  onToggleBudget,
  isSavedInBudget = false,
  onAddToItinerary,
  isSavedInItinerary = false,
  onAddReview,
  onBookDirectly,
}) => {
  const [isWriteReviewOpen, setIsWriteReviewOpen] = useState(false);
  const [helpfulReviews, setHelpfulReviews] = useState<{ [id: string]: boolean }>({});
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen || !place) return null;

  const toggleHelpful = (reviewId: string) => {
    setHelpfulReviews((prev) => ({ ...prev, [reviewId]: !prev[reviewId] }));
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
        <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col my-auto text-[#3D3D3D]">
          {/* Header Image Gallery */}
          <div className="relative h-64 sm:h-80 w-full shrink-0 bg-[#EAE7DC]">
            <img
              src={place.image}
              alt={place.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2D2D2A]/85 via-[#2D2D2A]/30 to-transparent" />

            {/* Close & Share Buttons */}
            <div className="absolute top-4 right-4 flex items-center gap-2">
              <button
                onClick={handleShare}
                className="p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-md transition-colors"
                title="Share place link"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>
              <button
                onClick={onClose}
                className="p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-md transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Category Tag */}
            <div className="absolute top-4 left-4">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#5A5A40] text-white shadow-md uppercase tracking-wider">
                {place.category}
              </span>
            </div>

            {/* Bottom Title Details */}
            <div className="absolute bottom-4 left-4 right-4 text-white space-y-1">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-amber-400 text-[#2D2D2A] px-2 py-0.5 rounded-md font-bold text-xs">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>{place.rating}</span>
                </div>
                <span className="text-xs text-stone-300">
                  ({place.reviewCount.toLocaleString()} Tourist Reviews)
                </span>
                <span className="text-stone-400 text-xs">•</span>
                <span className="text-xs text-emerald-300 font-semibold">
                  {place.timings.currentStatus || 'Open Now'}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold leading-tight drop-shadow-sm">
                {place.name}
              </h2>
              <p className="text-xs sm:text-sm text-stone-200 line-clamp-1">
                {place.tagline}
              </p>
            </div>
          </div>

          {/* Modal Main Content */}
          <div className="p-5 sm:p-7 space-y-6">
            {/* Quick Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-[#F4F1EA] border border-[#DEDACF] rounded-2xl text-xs">
              <div className="flex items-center gap-2 text-[#5A5A40]">
                <MapPin className="w-4 h-4 text-[#D28E5D] shrink-0" />
                <span className="font-medium">{place.address}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    onClose();
                    onShowOnMap(place);
                  }}
                  className="px-3 py-1.5 bg-white hover:bg-[#F9F7F2] text-[#5A5A40] border border-[#DEDACF] font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-2xs"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#D28E5D]" />
                  <span>Show on Map</span>
                </button>

                {onBookDirectly && (
                  <button
                    onClick={() => onBookDirectly({ place, category: place.category })}
                    className="px-4 py-1.5 font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white"
                  >
                    <Ticket className="w-3.5 h-3.5 text-amber-400" />
                    <span>Instant Direct Booking</span>
                  </button>
                )}

                {onAddToItinerary && (
                  <button
                    onClick={() => onAddToItinerary(place)}
                    className={`px-4 py-1.5 font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs ${
                      isSavedInItinerary
                        ? 'bg-[#E9F2E9] text-[#4A6741] border border-[#D0E2CF]'
                        : 'bg-[#5A5A40] hover:bg-[#454530] text-white'
                    }`}
                  >
                    {isSavedInItinerary ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>In Itinerary</span>
                      </>
                    ) : (
                      <>
                        <Calendar className="w-3.5 h-3.5 text-amber-300" />
                        <span>+ Add to Daily Schedule</span>
                      </>
                    )}
                  </button>
                )}

                {onToggleBudget && (
                  <button
                    onClick={() => onToggleBudget(place)}
                    className={`px-3 py-1.5 font-semibold rounded-xl flex items-center gap-1.5 transition-colors ${
                      isSavedInBudget
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : 'bg-stone-900 text-white hover:bg-stone-800'
                    }`}
                  >
                    {isSavedInBudget ? <Check className="w-3.5 h-3.5" /> : <Ticket className="w-3.5 h-3.5" />}
                    <span>{isSavedInBudget ? 'In Ticket Calculator' : 'Add to Ticket Planner'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Description & Overview */}
            <div className="space-y-2">
              <h3 className="font-bold text-base text-stone-900">About this Place</h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                {place.description}
              </p>
            </div>

            {/* Present Entry Ticket Pricing Box */}
            <div className="bg-rose-50/60 border border-rose-100 rounded-2xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm sm:text-base text-rose-950 flex items-center gap-2">
                  <Ticket className="w-4 h-4 text-rose-600" />
                  <span>Present Entry Ticket & Pricing Table</span>
                </h3>
                {onBookDirectly && (
                  <button
                    onClick={() => onBookDirectly({ place, category: place.category })}
                    className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 transition-colors shadow-2xs"
                  >
                    <Ticket className="w-3 h-3" />
                    <span>Book Passes Online</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="bg-white p-3 rounded-xl border border-rose-100">
                  <span className="text-[10px] text-stone-500 uppercase font-semibold block">General / Adult</span>
                  <span className="font-extrabold text-stone-900 text-base">
                    {place.ticket.isFree ? 'FREE' : `${place.ticket.currency}${place.ticket.generalPrice}`}
                  </span>
                </div>

                {place.ticket.vipPrice !== undefined && (
                  <div className="bg-white p-3 rounded-xl border border-rose-100">
                    <span className="text-[10px] text-amber-700 uppercase font-semibold block">VIP / Fast-Track</span>
                    <span className="font-extrabold text-amber-900 text-base">
                      {place.ticket.currency}{place.ticket.vipPrice}
                    </span>
                  </div>
                )}

                {place.ticket.foreignTouristPrice !== undefined && (
                  <div className="bg-white p-3 rounded-xl border border-rose-100">
                    <span className="text-[10px] text-stone-500 uppercase font-semibold block">Foreign Tourist</span>
                    <span className="font-extrabold text-rose-900 text-base">
                      {place.ticket.currency}{place.ticket.foreignTouristPrice}
                    </span>
                  </div>
                )}

                {place.ticket.childPrice !== undefined && (
                  <div className="bg-white p-3 rounded-xl border border-rose-100">
                    <span className="text-[10px] text-stone-500 uppercase font-semibold block">Child (Under 12)</span>
                    <span className="font-extrabold text-emerald-700 text-base">
                      {place.ticket.childPrice === 0 ? 'FREE' : `${place.ticket.currency}${place.ticket.childPrice}`}
                    </span>
                  </div>
                )}
              </div>

              <p className="text-xs text-stone-600">
                {place.ticket.ticketNotes || 'Tickets can be purchased at official ticketing counters or certified kiosks.'}
              </p>
            </div>

            {/* Timings & Working Days Strip */}
            <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-stone-700">
                <Clock className="w-4 h-4 text-stone-500" />
                <span className="font-semibold text-stone-900">Visiting Hours:</span>
                <span>{place.timings.open} to {place.timings.close}</span>
                {place.timings.breakTime && (
                  <span className="text-stone-500">(Break: {place.timings.breakTime})</span>
                )}
              </div>
              <div className="text-stone-600">
                <span>Days: <strong>{place.timings.days}</strong></span>
              </div>
            </div>

            {/* Category Specific Sections */}
            {/* Theatres: Current Movies */}
            {place.category === 'theatre' && place.movies && (
              <div className="space-y-4">
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <Film className="w-5 h-5 text-indigo-600" />
                  <span>Currently Playing Movie Schedules ({place.movies.length})</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {place.movies.map((m) => (
                    <div key={m.id} className="bg-indigo-50/40 border border-indigo-100 rounded-2xl p-4 space-y-3">
                      <div className="flex gap-3">
                        <img src={m.poster} alt={m.title} className="w-16 h-22 rounded-lg object-cover shrink-0" />
                        <div>
                          <h4 className="font-bold text-sm text-stone-900">{m.title}</h4>
                          <span className="text-xs text-indigo-700 font-semibold">{m.format} · {m.certification}</span>
                          <p className="text-[11px] text-stone-500 mt-1 line-clamp-2">{m.synopsis}</p>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[11px] font-bold text-stone-700 block">Showtimes & Tickets:</span>
                        <div className="grid grid-cols-2 gap-1.5">
                          {m.showtimes.map((st, sIdx) => (
                            <button
                              key={sIdx}
                              onClick={() => {
                                if (onBookDirectly) {
                                  onBookDirectly({
                                    place,
                                    category: 'theatre',
                                    movie: m,
                                    showtime: st,
                                  });
                                }
                              }}
                              className="bg-white hover:bg-indigo-100/80 p-2 rounded-lg border border-indigo-100 hover:border-indigo-300 flex items-center justify-between text-xs transition-colors text-left group"
                            >
                              <div>
                                <span className="font-bold text-stone-900 group-hover:text-indigo-950 block">{st.time}</span>
                                <span className="text-[10px] text-stone-500">{st.screenType}</span>
                              </div>
                              <div className="text-right">
                                <span className="font-bold text-indigo-700 block">{st.currency}{st.price}</span>
                                <span className="text-[9px] text-emerald-600 font-semibold">Book</span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Temples: Full 24-hr Crowd Graph & Aarti Schedule */}
            {place.category === 'temple' && place.crowd && (
              <CrowdVisualizer crowd={place.crowd} placeName={place.name} isCompact={false} />
            )}

            {/* Restaurants: Most Rated Dishes */}
            {place.category === 'restaurant' && place.topDishes && (
              <div className="space-y-4">
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <Flame className="w-5 h-5 text-orange-500" />
                  <span>Most-Rated Food Items & Signature Delicacies</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  {place.topDishes.map((dish, idx) => (
                    <div key={idx} className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-3.5 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-stone-900">{dish.name}</span>
                          {dish.badge && (
                            <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-1.5 py-0.2 rounded">
                              {dish.badge}
                            </span>
                          )}
                        </div>
                        <span className="font-bold text-emerald-800 text-sm">{dish.price}</span>
                      </div>
                      <p className="text-xs text-stone-600">{dish.description}</p>
                      <div className="flex items-center gap-1 text-[11px] text-stone-500 pt-1">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                        <span className="font-bold text-stone-800">{dish.rating}</span>
                        <span>({dish.reviewCount.toLocaleString()} votes)</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Facilities Chips */}
            {place.facilities && (
              <div className="space-y-2">
                <h4 className="font-bold text-xs text-stone-800">Visitor Amenities & Facilities:</h4>
                <div className="flex flex-wrap gap-1.5">
                  {place.facilities.map((fac, idx) => (
                    <span key={idx} className="px-2.5 py-1 bg-stone-100 text-stone-700 rounded-lg text-xs font-medium">
                      ✓ {fac}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Peoples Reviews Section */}
            <div className="space-y-4 pt-4 border-t border-stone-200">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                    <span>Peoples Reviews & Visitor Experiences</span>
                    <span className="text-xs bg-stone-100 text-stone-700 px-2 py-0.5 rounded-full font-bold">
                      {place.reviews.length} Verified
                    </span>
                  </h3>
                  <p className="text-xs text-stone-500">
                    Real traveler feedback on queues, tickets, cleanliness, and food
                  </p>
                </div>

                <button
                  onClick={() => setIsWriteReviewOpen(true)}
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <MessageSquarePlus className="w-4 h-4" />
                  <span>Write a Review</span>
                </button>
              </div>

              {/* Review Cards List */}
              <div className="space-y-3">
                {place.reviews.map((rev) => {
                  const isUpvoted = helpfulReviews[rev.id];
                  return (
                    <div
                      key={rev.id}
                      className="bg-stone-50/70 border border-stone-200 rounded-2xl p-4 space-y-2.5 text-xs"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-stone-900">{rev.userName}</span>
                            <span className="text-stone-400">•</span>
                            <span className="text-stone-500">{rev.userLocation}</span>
                            {rev.userType && (
                              <span className="text-[10px] bg-stone-200 text-stone-700 px-2 py-0.5 rounded-md font-medium">
                                {rev.userType}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-stone-500 text-[11px] mt-0.5">
                            <div className="flex items-center text-amber-500">
                              {Array.from({ length: rev.rating }).map((_, s) => (
                                <Star key={s} className="w-3 h-3 fill-current" />
                              ))}
                            </div>
                            <span>Visited {rev.date}</span>
                          </div>
                        </div>

                        {rev.crowdExperience && (
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            rev.crowdExperience === 'Low'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : rev.crowdExperience === 'Peak'
                              ? 'bg-rose-50 text-rose-800 border-rose-200'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}>
                            {rev.crowdExperience} Crowd Experience
                          </span>
                        )}
                      </div>

                      <p className="text-stone-700 leading-relaxed">
                        "{rev.comment}"
                      </p>

                      {rev.recommendedItem && (
                        <div className="bg-amber-50/80 border border-amber-200/80 rounded-lg p-2 text-[11px] text-amber-900 font-medium flex items-center gap-1.5">
                          <Flame className="w-3.5 h-3.5 text-amber-600" />
                          <span><strong>Highlight / Recommended:</strong> {rev.recommendedItem}</span>
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-1 text-[11px] text-stone-500">
                        <span>Verified Tourist Visit</span>
                        <button
                          onClick={() => toggleHelpful(rev.id)}
                          className={`flex items-center gap-1 px-2 py-1 rounded-md transition-colors ${
                            isUpvoted ? 'bg-amber-100 text-amber-900 font-bold' : 'hover:bg-stone-200/70 text-stone-600'
                          }`}
                        >
                          <ThumbsUp className="w-3 h-3" />
                          <span>Helpful ({(rev.helpfulCount || 0) + (isUpvoted ? 1 : 0)})</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Write Review Modal */}
      <WriteReviewModal
        place={place}
        isOpen={isWriteReviewOpen}
        onClose={() => setIsWriteReviewOpen(false)}
        onSubmitReview={onAddReview}
      />
    </>
  );
};
