import React, { useState } from 'react';
import { Booking, BookingCategory } from '../types';
import { 
  X, 
  Ticket, 
  Calendar, 
  Clock, 
  MapPin, 
  QrCode, 
  Printer, 
  Trash2, 
  Plus, 
  CheckCircle2, 
  CalendarPlus, 
  Film, 
  Sparkles, 
  UtensilsCrossed, 
  Landmark, 
  PartyPopper,
  ExternalLink,
  CreditCard,
  AlertCircle,
  Download,
  Share2,
  Smartphone
} from 'lucide-react';
import { downloadTicketPDF } from '../utils/pdfTicketGenerator';

interface MyBookingsModalProps {
  isOpen: boolean;
  bookings: Booking[];
  onClose: () => void;
  onCancelBooking: (bookingId: string) => void;
  onAddToItinerary?: (booking: Booking) => void;
  onOpenExplore?: (category?: BookingCategory) => void;
  onViewOnMap?: (booking: Booking) => void;
}

export const MyBookingsModal: React.FC<MyBookingsModalProps> = ({
  isOpen,
  bookings,
  onClose,
  onCancelBooking,
  onAddToItinerary,
  onOpenExplore,
  onViewOnMap,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [expandedQrId, setExpandedQrId] = useState<string | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredBookings = bookings.filter((b) => {
    if (filterCategory === 'all') return true;
    return b.category === filterCategory;
  });

  const getCategoryIcon = (category: BookingCategory) => {
    switch (category) {
      case 'theatre': return Film;
      case 'temple': return Sparkles;
      case 'restaurant': return UtensilsCrossed;
      case 'attraction': return Landmark;
      case 'event': return PartyPopper;
      default: return Ticket;
    }
  };

  const getCategoryBadgeClass = (category: BookingCategory) => {
    switch (category) {
      case 'theatre': return 'bg-indigo-50 text-indigo-800 border-indigo-200';
      case 'temple': return 'bg-amber-50 text-amber-900 border-amber-200';
      case 'restaurant': return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'attraction': return 'bg-rose-50 text-rose-800 border-rose-200';
      case 'event': return 'bg-orange-50 text-orange-800 border-orange-200';
      default: return 'bg-[#F4F1EA] text-[#5A5A40] border-[#DEDACF]';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col justify-between text-[#2D2D2A]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-[#2D2D2A] text-white p-5 sm:p-6 shrink-0 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-amber-400 text-[#2D2D2A] flex items-center justify-center font-bold shadow-md">
              <Ticket className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-white/20 text-amber-300">
                  Wallet & Digital Passes
                </span>
                <span className="text-xs text-stone-300 font-bold">
                  {bookings.length} Total Passes
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-white">
                My Bookings & Confirmed E-Tickets
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-colors"
            aria-label="Close my bookings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Filters Bar */}
        <div className="p-4 bg-[#F4F1EA] border-b border-[#DEDACF] flex items-center gap-2 overflow-x-auto text-xs shrink-0">
          {[
            { id: 'all', label: `All Passes (${bookings.length})` },
            { id: 'theatre', label: `Movies (${bookings.filter(b => b.category === 'theatre').length})` },
            { id: 'temple', label: `Temples (${bookings.filter(b => b.category === 'temple').length})` },
            { id: 'restaurant', label: `Dining (${bookings.filter(b => b.category === 'restaurant').length})` },
            { id: 'attraction', label: `Monuments (${bookings.filter(b => b.category === 'attraction').length})` },
            { id: 'event', label: `Events (${bookings.filter(b => b.category === 'event').length})` },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilterCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                filterCategory === cat.id
                  ? 'bg-[#2D2D2A] text-white shadow-xs'
                  : 'bg-white text-[#5A5A40] border border-[#DEDACF] hover:bg-[#EAE7DC]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {filteredBookings.length === 0 ? (
            <div className="text-center py-12 px-4 bg-[#F4F1EA] border border-[#DEDACF] rounded-3xl space-y-4">
              <Ticket className="w-12 h-12 text-[#8B8B6B] mx-auto opacity-50" />
              <div className="space-y-1">
                <h3 className="font-serif font-bold text-lg text-[#2D2D2A]">
                  No Bookings Found in this Category
                </h3>
                <p className="text-xs text-[#8B8B6B] max-w-sm mx-auto">
                  You haven't made any bookings in this section yet. You can book movies, VIP temple darshan, dining tables, monument tickets, and events directly from the app.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenExplore) onOpenExplore('theatre');
                  }}
                  className="px-4 py-2 bg-[#5A5A40] hover:bg-[#484832] text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Book Movie Tickets
                </button>
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenExplore) onOpenExplore('temple');
                  }}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Book Temple VIP Darshan
                </button>
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenExplore) onOpenExplore('restaurant');
                  }}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Reserve Dining Table
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              {filteredBookings.map((b) => {
                const IconComponent = getCategoryIcon(b.category);
                const badgeClass = getCategoryBadgeClass(b.category);
                const isQrOpen = expandedQrId === b.id;

                return (
                  <div
                    key={b.id}
                    className="bg-white border border-[#E5E2D9] rounded-3xl overflow-hidden shadow-xs hover:shadow-md transition-all space-y-0"
                  >
                    {/* Top Pass Strip */}
                    <div className="p-4 sm:p-5 bg-gradient-to-r from-[#FAF9F5] to-white border-b border-[#E5E2D9] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <span className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 border ${badgeClass}`}>
                          <IconComponent className="w-5 h-5" />
                        </span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border uppercase tracking-wider ${badgeClass}`}>
                              {b.category}
                            </span>
                            <span className="text-[11px] font-mono font-bold text-[#5A5A40] bg-[#F4F1EA] px-2 py-0.5 rounded-md">
                              {b.bookingRef}
                            </span>
                          </div>
                          <h3 className="font-serif font-bold text-base text-[#2D2D2A] mt-1 leading-snug">
                            {b.itemTitle}
                          </h3>
                          <p className="text-xs text-[#8B8B6B] flex items-center gap-1 mt-0.5">
                            <MapPin className="w-3 h-3 text-[#D28E5D] shrink-0" />
                            <span className="truncate">{b.itemAddress}</span>
                          </p>
                        </div>
                      </div>

                      <div className="text-left sm:text-right shrink-0">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{b.bookingStatus}</span>
                        </span>
                        <div className="font-bold text-sm text-[#2D2D2A] mt-1">
                          {b.totalAmount === 0 ? 'FREE PASS' : `${b.currency}${b.totalAmount}`}
                        </div>
                        <span className="text-[10px] text-[#8B8B6B] block">{b.paymentStatus}</span>
                      </div>
                    </div>

                    {/* Middle Details Grid */}
                    <div className="p-4 sm:p-5 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white text-xs border-b border-[#E5E2D9]">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#8B8B6B] block">Date of Visit</span>
                        <span className="font-bold text-[#2D2D2A] flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3.5 h-3.5 text-[#5A5A40]" />
                          {b.serviceDate}
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#8B8B6B] block">Time / Slot</span>
                        <span className="font-bold text-[#2D2D2A] flex items-center gap-1 mt-0.5 truncate">
                          <Clock className="w-3.5 h-3.5 text-[#5A5A40] shrink-0" />
                          <span className="truncate">{b.serviceTime}</span>
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#8B8B6B] block">Guest Name</span>
                        <span className="font-bold text-[#2D2D2A] block mt-0.5 truncate">
                          {b.customerName}
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#8B8B6B] block">Specifics</span>
                        <span className="font-bold text-[#5A5A40] block mt-0.5 truncate">
                          {b.details.selectedSeats?.length ? `${b.details.selectedSeats.join(', ')} Seats` : ''}
                          {b.details.darshanType ? b.details.darshanType : ''}
                          {b.details.partySize ? `${b.details.partySize} Guests Table` : ''}
                          {b.details.eventTier ? b.details.eventTier : ''}
                        </span>
                      </div>
                    </div>

                    {/* Expandable QR Code Scanner Box */}
                    {isQrOpen && (
                      <div className="p-5 bg-[#2D2D2A] text-white flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-white/10 animate-in fade-in duration-200">
                        <div className="space-y-1 text-center sm:text-left text-xs">
                          <span className="text-[10px] font-bold uppercase text-amber-300 tracking-wider block">
                            Official Digital Entry Turnstile Code
                          </span>
                          <h4 className="font-bold text-sm text-white">{b.itemTitle}</h4>
                          <p className="text-stone-300 text-xs">Present this scannable QR directly to the gate steward or cinema turnstile.</p>
                          <p className="text-[11px] text-emerald-400 font-mono font-bold">Booking ID: {b.bookingRef}</p>
                        </div>

                        <div className="bg-white p-3 rounded-2xl flex flex-col items-center shadow-md shrink-0">
                          <QrCode className="w-24 h-24 text-[#2D2D2A]" />
                          <span className="font-mono text-[9px] text-[#2D2D2A] font-bold mt-1 tracking-wider">
                            SCAN AT VENUE
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Bottom Action Footer */}
                    <div className="p-3 sm:p-4 bg-[#FAF9F5] flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setExpandedQrId(isQrOpen ? null : b.id)}
                          className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors ${
                            isQrOpen
                              ? 'bg-[#2D2D2A] text-white'
                              : 'bg-white border border-[#DEDACF] text-[#5A5A40] hover:bg-[#F4F1EA]'
                          }`}
                        >
                          <QrCode className="w-3.5 h-3.5 text-[#D28E5D]" />
                          <span>{isQrOpen ? 'Hide Entry QR' : 'Show Entry QR Code'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => downloadTicketPDF(b, b.cityName || 'City', false)}
                          className="px-3 py-1.5 rounded-xl font-bold bg-emerald-50 border border-emerald-300 text-emerald-800 hover:bg-emerald-100 flex items-center gap-1.5 transition-colors"
                          title="Download & Save PDF Ticket directly to mobile/desktop"
                        >
                          <Download className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Save PDF</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => downloadTicketPDF(b, b.cityName || 'City', true)}
                          className="px-2.5 py-1.5 rounded-xl font-bold bg-white border border-[#DEDACF] text-[#5A5A40] hover:bg-[#F4F1EA] flex items-center gap-1.5 transition-colors"
                          title="Share Ticket / Send to Mobile"
                        >
                          <Share2 className="w-3.5 h-3.5 text-[#D28E5D]" />
                          <span className="hidden sm:inline">Share</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => window.print()}
                          className="px-2.5 py-1.5 rounded-xl font-bold bg-white border border-[#DEDACF] text-[#5A5A40] hover:bg-[#F4F1EA] flex items-center gap-1.5 transition-colors"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Print</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        {onAddToItinerary && (
                          <button
                            type="button"
                            onClick={() => {
                              onAddToItinerary(b);
                            }}
                            className="px-3 py-1.5 rounded-xl font-bold bg-[#5A5A40] hover:bg-[#484832] text-white flex items-center gap-1.5 transition-colors shadow-2xs"
                          >
                            <CalendarPlus className="w-3.5 h-3.5 text-amber-300" />
                            <span>Add to Schedule</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`Are you sure you want to cancel booking ${b.bookingRef} for "${b.itemTitle}"? Full refund will be processed to original payment method.`)) {
                              onCancelBooking(b.id);
                            }
                          }}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors border border-transparent hover:border-rose-200"
                          title="Cancel Reservation"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-[#F4F1EA] border-t border-[#DEDACF] flex items-center justify-between text-xs text-[#5A5A40] shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
            <span>Digital Passes Auto-Synced to Device & Instant QR Turnstile</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white font-bold rounded-xl transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
