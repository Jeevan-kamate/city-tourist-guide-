import React from 'react';
import { City, Place, CityEvent } from '../types';
import { 
  Search, 
  MapPin, 
  Sun, 
  Coins, 
  Globe, 
  PhoneCall, 
  Sparkles, 
  Film, 
  UtensilsCrossed, 
  Landmark, 
  Users, 
  Ticket, 
  Flame, 
  Check,
  PartyPopper,
  Calendar
} from 'lucide-react';

interface CityHeroProps {
  city: City;
  places: Place[];
  events?: CityEvent[];
  searchQuery: string;
  onSearchChange: (q: string) => void;
  activeQuickFilter: string;
  onQuickFilterChange: (filter: string) => void;
  onOpenExploreModal: () => void;
  onNavigateToEvents?: () => void;
  onNavigateToItinerary?: () => void;
  onSelectCategory?: (cat: 'theatre' | 'temple' | 'restaurant' | 'attraction') => void;
}

export const CityHero: React.FC<CityHeroProps> = ({
  city,
  places,
  events = [],
  searchQuery,
  onSearchChange,
  activeQuickFilter,
  onQuickFilterChange,
  onOpenExploreModal,
  onNavigateToEvents,
  onNavigateToItinerary,
  onSelectCategory,
}) => {
  const theatreCount = places.filter((p) => p.category === 'theatre').length;
  const templeCount = places.filter((p) => p.category === 'temple').length;
  const restaurantCount = places.filter((p) => p.category === 'restaurant').length;
  const attractionCount = places.filter((p) => p.category === 'attraction').length;

  const quickFilters = [
    { id: 'all', label: 'All Places' },
    { id: 'open_now', label: '🟢 Open Now' },
    { id: 'free_entry', label: '🎟️ Free Entry' },
    { id: 'low_crowd', label: '✨ Low Crowd Temples' },
    { id: 'has_movies', label: '🎬 Current Movies' },
    { id: 'top_food', label: '🔥 Top Rated Food' },
  ];

  return (
    <div id="city-hero-section" className="space-y-4">
      {/* Hero Banner Card in Natural Tones */}
      <div className="relative rounded-3xl overflow-hidden shadow-md bg-[#2D2D2A] border border-[#DEDACF] min-h-[320px] flex flex-col justify-between">
        <img
          src={city.coverImage}
          alt={city.name}
          className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-luminosity"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#2D2D2A] via-[#2D2D2A]/70 to-transparent" />

        {/* Top Badges */}
        <div className="relative z-10 p-5 sm:p-7 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#FDFCF8] text-[#2D2D2A] backdrop-blur-md shadow-xs flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#D28E5D]" />
              <span>{city.name}, {city.state || city.country}</span>
            </span>

            <button
              onClick={onOpenExploreModal}
              className="px-3 py-1 rounded-full text-xs font-bold bg-[#5A5A40]/40 hover:bg-[#5A5A40]/60 text-amber-200 border border-amber-300/30 backdrop-blur-md transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Switch / Discover Another City</span>
            </button>
          </div>

          {/* Quick metadata strip */}
          <div className="hidden sm:flex items-center gap-4 text-stone-200 text-xs bg-black/40 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/10">
            <span className="flex items-center gap-1">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>Season: <strong>{city.bestSeason}</strong></span>
            </span>
            <span className="text-white/20">•</span>
            <span className="flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-emerald-400" />
              <span>Currency: <strong>{city.localCurrency}</strong></span>
            </span>
            {city.emergencyContact && (
              <>
                <span className="text-white/20">•</span>
                <span className="flex items-center gap-1">
                  <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                  <span>SOS: <strong>{city.emergencyContact}</strong></span>
                </span>
              </>
            )}
          </div>
        </div>

        {/* Hero Bottom Info & Search */}
        <div className="relative z-10 p-5 sm:p-7 space-y-4 text-white">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="max-w-2xl space-y-1">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold leading-tight tracking-tight">
                {city.name} Tourist Companion
              </h1>
              <p className="text-sm sm:text-base text-stone-300 font-sans">
                {city.tagline} — {city.description}
              </p>
            </div>

            {/* Quick Feature Shortcut Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              {onNavigateToEvents && (
                <button
                  onClick={onNavigateToEvents}
                  className="px-3.5 py-2 rounded-2xl text-xs font-bold bg-[#C2410C] hover:bg-[#A33408] text-white flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <PartyPopper className="w-4 h-4" />
                  <span>{events.length} City Events</span>
                </button>
              )}

              {onNavigateToItinerary && (
                <button
                  onClick={onNavigateToItinerary}
                  className="px-3.5 py-2 rounded-2xl text-xs font-bold bg-[#5A5A40] hover:bg-[#484832] text-white border border-[#8B8B6B]/40 flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Calendar className="w-4 h-4 text-amber-300" />
                  <span>Daily Planner</span>
                </button>
              )}
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative max-w-xl">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={`Search theatres, movies, temples, most-rated food or sights in ${city.name}...`}
              className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-[#FDFCF8] text-[#2D2D2A] placeholder:text-[#8B8B6B] font-medium text-xs sm:text-sm focus:outline-hidden focus:ring-4 focus:ring-[#8B8B6B]/40 shadow-xl"
            />
            <Search className="w-5 h-5 text-[#8B8B6B] absolute left-3.5 top-3.5" />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3.5 top-3.5 text-[#8B8B6B] hover:text-[#2D2D2A] text-xs font-bold"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick 4 Options Selector Chips in Natural Tones */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-xs">
            <button
              type="button"
              onClick={() => onSelectCategory && onSelectCategory('theatre')}
              className="bg-white/10 hover:bg-white/20 transition-all p-2.5 rounded-2xl border border-white/15 flex items-center gap-2 text-left cursor-pointer group"
              title={`View ${theatreCount} Theatres in ${city.name}`}
            >
              <Film className="w-4 h-4 text-indigo-300 shrink-0 group-hover:scale-110 transition-transform" />
              <div className="min-w-0">
                <span className="font-bold text-white block truncate">{theatreCount} Theatres</span>
                <span className="text-[10px] text-stone-300 block">4K Movies & Shows →</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory && onSelectCategory('temple')}
              className="bg-white/10 hover:bg-white/20 transition-all p-2.5 rounded-2xl border border-white/15 flex items-center gap-2 text-left cursor-pointer group"
              title={`View ${templeCount} Temples in ${city.name}`}
            >
              <Sparkles className="w-4 h-4 text-amber-300 shrink-0 group-hover:scale-110 transition-transform" />
              <div className="min-w-0">
                <span className="font-bold text-white block truncate">{templeCount} Temples</span>
                <span className="text-[10px] text-stone-300 block">Darshan & Crowd →</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory && onSelectCategory('restaurant')}
              className="bg-white/10 hover:bg-white/20 transition-all p-2.5 rounded-2xl border border-white/15 flex items-center gap-2 text-left cursor-pointer group"
              title={`View ${restaurantCount} Restaurants in ${city.name}`}
            >
              <UtensilsCrossed className="w-4 h-4 text-emerald-300 shrink-0 group-hover:scale-110 transition-transform" />
              <div className="min-w-0">
                <span className="font-bold text-white block truncate">{restaurantCount} Restaurants</span>
                <span className="text-[10px] text-stone-300 block">Food & Sweets →</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory && onSelectCategory('attraction')}
              className="bg-white/10 hover:bg-white/20 transition-all p-2.5 rounded-2xl border border-white/15 flex items-center gap-2 text-left cursor-pointer group"
              title={`View ${attractionCount} Tourist Spots in ${city.name}`}
            >
              <Landmark className="w-4 h-4 text-rose-300 shrink-0 group-hover:scale-110 transition-transform" />
              <div className="min-w-0">
                <span className="font-bold text-white block truncate">{attractionCount} Tourist Spots</span>
                <span className="text-[10px] text-stone-300 block">Forts & Sights →</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Filter Buttons Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-[#8B8B6B] font-bold text-xs whitespace-nowrap pl-1 pr-2">
          Filters:
        </span>
        {quickFilters.map((qf) => (
          <button
            key={qf.id}
            onClick={() => onQuickFilterChange(qf.id)}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeQuickFilter === qf.id
                ? 'bg-[#2D2D2A] text-white shadow-xs'
                : 'bg-[#FDFCF8] hover:bg-[#F4F1EA] border border-[#E5E2D9] text-[#5A5A40]'
            }`}
          >
            {qf.label}
          </button>
        ))}
      </div>
    </div>
  );
};
