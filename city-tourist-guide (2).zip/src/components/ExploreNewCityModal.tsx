import React, { useState } from 'react';
import { City, Place } from '../types';
import { Sparkles, Search, Globe, X, Loader2, Compass, CheckCircle2 } from 'lucide-react';

interface ExploreNewCityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCityGenerated: (newCity: City, newPlaces: Place[]) => void;
}

export const ExploreNewCityModal: React.FC<ExploreNewCityModalProps> = ({
  isOpen,
  onClose,
  onCityGenerated,
}) => {
  const [cityName, setCityName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const popularSuggestions = [
    'Jaipur, India',
    'Tokyo, Japan',
    'Paris, France',
    'Cairo, Egypt',
    'London, UK',
    'Bangkok, Thailand',
    'New York, USA',
    'Istanbul, Turkey',
  ];

  const handleGenerate = async (targetCity?: string) => {
    const query = targetCity || cityName;
    if (!query.trim() || isLoading) return;

    setIsLoading(true);
    setErrorMessage('');

    try {
      const response = await fetch('/api/gemini/explore-city', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cityName: query }),
      });

      if (!response.ok) {
        throw new Error('Could not generate city data. Please try another city name.');
      }

      const data = await response.json();
      if (data.city && Array.isArray(data.places)) {
        onCityGenerated(data.city, data.places);
        onClose();
      } else {
        throw new Error('Invalid city data response format');
      }
    } catch (err: any) {
      console.error('Explore city error:', err);
      setErrorMessage(err.message || 'Failed to explore new city. Please verify your connection.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white border border-stone-200 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl space-y-4 my-auto text-stone-900">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-900 to-amber-950 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 border border-amber-400/30 rounded-xl">
              <Globe className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="font-bold text-base font-display">Explore Any City in the World</h3>
              <p className="text-xs text-amber-200">
                Generate real-time theatres, crowd timings, food & ticket databases
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 pt-0 space-y-4 text-xs">
          <p className="text-stone-600 leading-relaxed">
            Type any destination worldwide. Gemini AI will synthesize complete local datasets including current movie screenings, sacred shrines with 24-hr crowd curves, top-rated dishes, and verified entry ticket pricing.
          </p>

          {/* Search Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleGenerate();
            }}
            className="space-y-2"
          >
            <div className="relative">
              <input
                type="text"
                value={cityName}
                onChange={(e) => setCityName(e.target.value)}
                placeholder="e.g. Dubai, Jaipur, Florence, Singapore, Athens..."
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-stone-200 bg-stone-50 focus:bg-white focus:border-stone-900 focus:outline-hidden text-xs transition-colors font-medium"
              />
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
            </div>

            {errorMessage && (
              <p className="text-rose-600 text-xs font-medium">{errorMessage}</p>
            )}

            <button
              type="submit"
              disabled={isLoading || !cityName.trim()}
              className="w-full py-3 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-xs"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                  <span>Synthesizing City Database & Crowd Schedules...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Generate City Guide</span>
                </>
              )}
            </button>
          </form>

          {/* Popular City Chips */}
          <div className="space-y-2 pt-2 border-t border-stone-100">
            <span className="text-[11px] font-semibold text-stone-500 block">
              Quick Suggestions:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {popularSuggestions.map((item) => (
                <button
                  key={item}
                  onClick={() => {
                    setCityName(item);
                    handleGenerate(item);
                  }}
                  disabled={isLoading}
                  className="px-2.5 py-1.5 rounded-lg bg-stone-100 hover:bg-amber-50 hover:text-amber-900 border border-stone-200 text-stone-700 text-[11px] font-medium transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
