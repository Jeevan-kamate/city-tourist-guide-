import React, { useState, useEffect } from 'react';
import { Place, CityEvent, ItineraryPlan, ItineraryScheduleItem } from '../types';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  Plus, 
  Check, 
  AlertTriangle, 
  Navigation, 
  Car, 
  Footprints, 
  Train, 
  Bus 
} from 'lucide-react';

interface AddToItineraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetItem: {
    type: 'place' | 'event';
    item: Place | CityEvent;
  } | null;
  activePlan: ItineraryPlan;
  onSaveItem: (dayNumber: number, item: ItineraryScheduleItem) => void;
  onAddNewDay: () => void;
}

export const AddToItineraryModal: React.FC<AddToItineraryModalProps> = ({
  isOpen,
  onClose,
  targetItem,
  activePlan,
  onSaveItem,
  onAddNewDay,
}) => {
  const [selectedDayNumber, setSelectedDayNumber] = useState<number>(1);
  const [startTime, setStartTime] = useState<string>('09:30');
  const [endTime, setEndTime] = useState<string>('11:30');
  const [transportMode, setTransportMode] = useState<'walk' | 'taxi' | 'metro' | 'auto'>('walk');
  const [notes, setNotes] = useState<string>('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  // Initialize defaults based on target item
  useEffect(() => {
    if (targetItem) {
      if (targetItem.type === 'event') {
        const ev = targetItem.item as CityEvent;
        // Parse time if possible or default evening
        if (ev.timing.includes('18:00') || ev.timing.includes('18:30') || ev.timing.includes('19:00')) {
          setStartTime('18:30');
          setEndTime('21:00');
        } else if (ev.timing.includes('05:00')) {
          setStartTime('05:30');
          setEndTime('07:30');
        } else {
          setStartTime('10:00');
          setEndTime('12:30');
        }
      } else {
        const pl = targetItem.item as Place;
        if (pl.category === 'theatre') {
          setStartTime('17:30');
          setEndTime('20:30');
        } else if (pl.category === 'restaurant') {
          setStartTime('13:00');
          setEndTime('14:30');
        } else if (pl.category === 'temple') {
          setStartTime('08:00');
          setEndTime('10:00');
        } else {
          setStartTime('10:00');
          setEndTime('12:30');
        }
      }
    }
  }, [targetItem]);

  if (!isOpen || !targetItem) return null;

  const currentDay = activePlan.days.find((d) => d.dayNumber === selectedDayNumber) || activePlan.days[0];

  // Check for time overlap
  const hasTimeOverlap = currentDay?.items.some((it) => {
    // Basic overlap check
    return (startTime >= it.startTime && startTime < it.endTime) ||
           (endTime > it.startTime && endTime <= it.endTime) ||
           (startTime <= it.startTime && endTime >= it.endTime);
  });

  const handleSave = () => {
    const isPlace = targetItem.type === 'place';
    const place = isPlace ? (targetItem.item as Place) : undefined;
    const event = !isPlace ? (targetItem.item as CityEvent) : undefined;

    let estimatedCost = 0;
    if (place) {
      if (!place.ticket.isFree && typeof place.ticket.generalPrice === 'number') {
        estimatedCost = place.ticket.generalPrice;
      }
    } else if (event) {
      if (!event.isFree && typeof event.ticketPrice === 'number') {
        estimatedCost = event.ticketPrice;
      }
    }

    const newItem: ItineraryScheduleItem = {
      id: `it-item-${Date.now()}`,
      type: targetItem.type,
      placeId: place?.id,
      place: place,
      eventId: event?.id,
      event: event,
      startTime,
      endTime,
      notes: notes.trim() || undefined,
      estimatedCost,
      currency: place?.ticket.currency || event?.currency || '₹',
      transportMode,
      isCompleted: false,
    };

    onSaveItem(selectedDayNumber, newItem);
    setShowSuccessToast(true);
    setTimeout(() => {
      setShowSuccessToast(false);
      onClose();
    }, 900);
  };

  const timePresets = [
    { label: 'Morning (09:00 - 11:30)', start: '09:00', end: '11:30' },
    { label: 'Afternoon (13:00 - 15:00)', start: '13:00', end: '15:00' },
    { label: 'Evening (17:30 - 20:00)', start: '17:30', end: '20:00' },
    { label: 'Night (20:30 - 22:30)', start: '20:30', end: '22:30' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-[#FDFCF8] border border-[#E5E2D9] rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl space-y-0 my-auto text-[#3D3D3D]">
        
        {/* Header */}
        <div className="bg-[#F4F1EA] border-b border-[#DEDACF] p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#5A5A40] text-white rounded-xl">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-[#2D2D2A]">Add to Daily Itinerary</h3>
              <p className="text-xs text-[#8B8B6B]">
                Schedule {targetItem.item.name || (targetItem.item as CityEvent).title}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#EAE7DC] text-[#5A5A40] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-5 text-xs">
          
          {/* Target Item summary card */}
          <div className="p-3 bg-white border border-[#E5E2D9] rounded-2xl flex items-center gap-3">
            <img
              src={targetItem.item.image}
              alt=""
              className="w-14 h-14 rounded-xl object-cover shrink-0"
            />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B8B6B] block">
                {targetItem.type === 'place' ? (targetItem.item as Place).category : (targetItem.item as CityEvent).category}
              </span>
              <h4 className="font-bold text-sm text-[#2D2D2A] truncate">
                {targetItem.item.name || (targetItem.item as CityEvent).title}
              </h4>
              <p className="text-xs text-[#666] truncate flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-[#D28E5D]" />
                <span>{targetItem.item.address || (targetItem.item as CityEvent).locationName}</span>
              </p>
            </div>
          </div>

          {/* Select Day */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-bold text-[#2D2D2A] text-xs">Select Itinerary Day</label>
              <button
                type="button"
                onClick={onAddNewDay}
                className="text-[11px] font-bold text-[#5A5A40] hover:text-[#2D2D2A] flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Day {activePlan.days.length + 1}</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {activePlan.days.map((day) => (
                <button
                  key={day.id}
                  type="button"
                  onClick={() => setSelectedDayNumber(day.dayNumber)}
                  className={`px-3 py-2 rounded-xl font-bold text-xs transition-all ${
                    selectedDayNumber === day.dayNumber
                      ? 'bg-[#5A5A40] text-white shadow-xs'
                      : 'bg-white text-[#5A5A40] border border-[#DEDACF] hover:bg-[#F9F7F2]'
                  }`}
                >
                  Day {day.dayNumber} ({day.items.length} stops)
                </button>
              ))}
            </div>
          </div>

          {/* Time Picker */}
          <div className="space-y-2">
            <label className="font-bold text-[#2D2D2A] text-xs">Preferred Visiting Hours</label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-[#8B8B6B] block mb-1">Start Time</span>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#DEDACF] bg-white font-medium text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                />
              </div>

              <div>
                <span className="text-[10px] text-[#8B8B6B] block mb-1">End Time</span>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#DEDACF] bg-white font-medium text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                />
              </div>
            </div>

            {/* Quick Presets */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {timePresets.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setStartTime(preset.start);
                    setEndTime(preset.end);
                  }}
                  className="px-2 py-1 rounded-lg bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#5A5A40] text-[10px] font-medium transition-colors"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            {hasTimeOverlap && (
              <div className="p-2.5 rounded-xl bg-[#FFF9F0] border border-[#F3E5D8] text-[#C2410C] flex items-center gap-2 text-[11px] font-medium">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Notice: This time slot overlaps with another scheduled stop on Day {selectedDayNumber}.</span>
              </div>
            )}
          </div>

          {/* Transport Mode to Destination */}
          <div className="space-y-1.5">
            <label className="font-bold text-[#2D2D2A] text-xs">Transit Mode to this Stop</label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'walk', label: 'Walking', icon: Footprints },
                { id: 'taxi', label: 'Taxi/Cab', icon: Car },
                { id: 'metro', label: 'Metro', icon: Train },
                { id: 'auto', label: 'Auto/Rickshaw', icon: Bus },
              ].map((mode) => {
                const Icon = mode.icon;
                const isSelected = transportMode === mode.id;
                return (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setTransportMode(mode.id as any)}
                    className={`p-2 rounded-xl border flex flex-col items-center gap-1 text-[10px] font-bold transition-all ${
                      isSelected
                        ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                        : 'bg-white text-[#5A5A40] border-[#DEDACF] hover:bg-[#F9F7F2]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{mode.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Personal Notes */}
          <div className="space-y-1.5">
            <label className="font-bold text-[#2D2D2A] text-xs">Personal Visit Notes (Optional)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Must try signature dish, book VIP pass, bring camera..."
              className="w-full px-3 py-2.5 rounded-xl border border-[#DEDACF] bg-white text-xs font-medium text-[#2D2D2A] placeholder:text-[#8B8B6B] focus:outline-hidden focus:border-[#5A5A40]"
            />
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-[#F9F7F2] border-t border-[#E5E2D9] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-[#5A5A40] hover:text-[#2D2D2A] transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-[#5A5A40] hover:bg-[#454530] text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-colors shadow-xs"
          >
            {showSuccessToast ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Saved to Day {selectedDayNumber}!</span>
              </>
            ) : (
              <>
                <Calendar className="w-4 h-4 text-amber-300" />
                <span>Schedule Visit</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
