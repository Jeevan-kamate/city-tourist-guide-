import React, { useState } from 'react';
import {
  X,
  Shield,
  Lock,
  Eye,
  EyeOff,
  Users,
  Receipt,
  MapPin,
  Search,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Calendar,
  Ticket,
  Film,
  Building2,
  Utensils,
  Landmark,
  Compass,
  ArrowRight,
  LogOut,
  Download,
  Filter,
  RefreshCw,
  Phone,
  Mail,
  Clock,
  Sparkles
} from 'lucide-react';
import { UserAccount, Booking, City, Place } from '../types';
import { downloadTicketPDF } from '../utils/pdfTicketGenerator';

interface AdminPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserAccount[];
  bookings: Booking[];
  cities: City[];
  places: Place[];
}

const ADMIN_NAME = 'jeevan m k';
const ADMIN_PASSWORD = '6867123';

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  isOpen,
  onClose,
  users = [],
  bookings = [],
  cities = [],
  places = [],
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [enteredPassword, setEnteredPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Admin Portal Tab Navigation
  const [activeTab, setActiveTab] = useState<'users' | 'bookings' | 'cities' | 'analytics'>('users');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserAccount | null>(null);
  const [selectedCityId, setSelectedCityId] = useState<string | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  if (!isOpen) return null;

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (enteredPassword.trim() === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setEnteredPassword('');
    } else {
      setAuthError(
        'CAUTION: Permission Denied! This is a restricted Admin Page. Only the system administrator (jeevan m k) can log in on this page with his authorized password.'
      );
    }
  };

  const handleAdminLogout = () => {
    setIsAuthenticated(false);
    setSelectedUser(null);
    setEnteredPassword('');
    setAuthError(null);
  };

  // Analytics Aggregates
  const totalRevenue = bookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);
  const totalTickets = bookings.reduce((sum, b) => {
    if (b.category === 'theatre') return sum + (b.details?.selectedSeats?.length || 1);
    if (b.category === 'temple') return sum + (b.details?.devoteeCount || 1);
    if (b.category === 'attraction') return sum + (b.details?.ticketBreakdown?.adults || 1) + (b.details?.ticketBreakdown?.children || 0);
    return sum + (b.details?.ticketCount || 1);
  }, 0);

  // Filtered Bookings
  const filteredBookings = bookings.filter((b) => {
    const matchesSearch =
      b.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.bookingRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.itemTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.cityName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.customerEmail && b.customerEmail.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (b.customerPhone && b.customerPhone.includes(searchQuery));

    const matchesCategory = categoryFilter === 'all' || b.category === categoryFilter;
    const matchesCity = selectedCityId === 'all' || b.cityName.toLowerCase() === selectedCityId.toLowerCase();

    return matchesSearch && matchesCategory && matchesCity;
  });

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    return (
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.phone && u.phone.includes(searchQuery))
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-6xl bg-[#FDFCF8] rounded-3xl overflow-hidden shadow-2xl border border-[#E5E2D9] my-4 max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Top Header Bar */}
        <div className="p-4 sm:p-5 bg-[#1C1C1A] text-white flex items-center justify-between border-b border-[#333] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif font-bold text-base sm:text-lg text-white">
                  Admin Command Portal
                </span>
                <span className="px-2 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/30 text-amber-300 text-[10px] font-extrabold uppercase tracking-wider">
                  Admin: {ADMIN_NAME}
                </span>
              </div>
              <p className="text-[11px] text-[#A0A090]">
                Restricted access for system administrator {ADMIN_NAME}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                type="button"
                onClick={handleAdminLogout}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-stone-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                title="Lock Admin Panel"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Lock Panel</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* --- PASSWORD AUTHENTICATION SCREEN (When not unlocked) --- */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center text-center space-y-6 flex-1 overflow-y-auto">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600 shadow-inner">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-1.5 max-w-md">
              <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#2D2D2A]">
                Enter Administrator Password
              </h3>
              <p className="text-xs sm:text-sm text-[#8B8B6B]">
                This administrative database is restricted exclusively to administrator{' '}
                <strong className="text-[#2D2D2A]">{ADMIN_NAME}</strong>.
              </p>
            </div>

            {authError && (
              <div className="max-w-md w-full p-4 rounded-2xl bg-rose-50 border-2 border-rose-300 text-rose-900 text-xs font-semibold flex items-start gap-3 text-left shadow-xs">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="font-bold uppercase tracking-wider text-[11px] text-rose-700">Access Restricted</div>
                  <div className="leading-relaxed">{authError}</div>
                </div>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="w-full max-w-sm space-y-4">
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={enteredPassword}
                  onChange={(e) => setEnteredPassword(e.target.value)}
                  placeholder="Enter Administrator Password"
                  className="w-full px-4 py-3 pr-11 bg-white border border-[#DEDACF] rounded-2xl text-sm text-[#2D2D2A] focus:outline-hidden focus:border-amber-600 shadow-inner tracking-widest font-mono text-center"
                  autoFocus
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#8B8B6B] hover:text-[#2D2D2A]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-2xl bg-[#2D2D2A] hover:bg-[#1C1C1A] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.99]"
              >
                <Shield className="w-4 h-4 text-amber-400" />
                <span>Authenticate & Access Databases</span>
              </button>
            </form>

            <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-[11px] text-amber-900 max-w-sm flex items-center justify-center gap-2">
              <Shield className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Restricted administrative portal for <strong className="font-bold">jeevan m k</strong></span>
            </div>
          </div>
        ) : (
          /* --- UNLOCKED ADMIN COMMAND CENTER --- */
          <div className="flex-1 flex flex-col overflow-hidden bg-[#FDFCF8]">
            
            {/* Top KPI Metrics Bar */}
            <div className="p-4 sm:p-5 bg-[#F4F1EA] border-b border-[#E5E2D9] grid grid-cols-2 lg:grid-cols-4 gap-3 shrink-0">
              <div className="p-3 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Registered Users
                  </span>
                  <span className="text-xl font-bold font-serif text-[#2D2D2A]">
                    {users.length}
                  </span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                  <Users className="w-4 h-4" />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Total Bookings
                  </span>
                  <span className="text-xl font-bold font-serif text-emerald-700">
                    {bookings.length}
                  </span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Ticket className="w-4 h-4" />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    Revenue Generated
                  </span>
                  <span className="text-xl font-bold font-serif text-[#5A5A40]">
                    ₹{totalRevenue.toLocaleString()}
                  </span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#E5E2D9] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#8B8B6B] uppercase tracking-wider block">
                    City Database
                  </span>
                  <span className="text-xl font-bold font-serif text-purple-700">
                    {cities.length} Cities ({places.length} Sights)
                  </span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Admin Database Navigation Tabs */}
            <div className="px-4 sm:px-6 pt-3 border-b border-[#E5E2D9] flex flex-wrap items-center justify-between gap-3 shrink-0 bg-[#FDFCF8]">
              <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('users');
                    setSelectedUser(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
                    activeTab === 'users'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-blue-400" />
                  <span>1. User Database ({users.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('bookings');
                    setSelectedUser(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
                    activeTab === 'bookings'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5 text-emerald-400" />
                  <span>2. Bookings & Activity Database ({bookings.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('cities');
                    setSelectedUser(null);
                  }}
                  className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-all ${
                    activeTab === 'cities'
                      ? 'bg-[#2D2D2A] text-white shadow-xs'
                      : 'bg-[#F4F1EA] text-[#5A5A40] hover:bg-[#EAE7DC]'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>3. City Database ({cities.length})</span>
                </button>
              </div>

              {/* Search & Filter bar */}
              <div className="relative pb-2 sm:pb-0 w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-[#8B8B6B] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={`Search ${activeTab}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-[#DEDACF] rounded-xl text-xs text-[#2D2D2A] focus:outline-hidden focus:border-[#5A5A40]"
                />
              </div>
            </div>

            {/* TAB CONTENTS (Scrollable) */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

              {/* === TAB 1: USER DATABASE === */}
              {activeTab === 'users' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#2D2D2A]">
                        Registered Users & Logins
                      </h4>
                      <p className="text-xs text-[#8B8B6B]">
                        All tourists who registered or signed in to City Tourist Guide. Click on any user to inspect their booking history.
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#5A5A40] bg-[#F4F1EA] px-2.5 py-1 rounded-lg border border-[#DEDACF]">
                      {filteredUsers.length} Users Listed
                    </span>
                  </div>

                  {selectedUser ? (
                    /* User Deep Dive Details */
                    <div className="p-5 bg-white rounded-2xl border border-[#E5E2D9] space-y-5 shadow-xs animate-in fade-in">
                      <div className="flex items-center justify-between pb-3 border-b border-[#E5E2D9]">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-[#5A5A40] text-white flex items-center justify-center font-bold text-lg">
                            {selectedUser.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-base text-[#2D2D2A] flex items-center gap-2">
                              <span>{selectedUser.name}</span>
                              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                                Registered User
                              </span>
                            </div>
                            <div className="text-xs text-[#8B8B6B] flex items-center gap-3 mt-0.5">
                              <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {selectedUser.email}</span>
                              <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {selectedUser.phone || 'N/A'}</span>
                              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Joined: {new Date(selectedUser.joinedAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedUser(null)}
                          className="px-3 py-1.5 rounded-xl bg-[#F4F1EA] hover:bg-[#EAE7DC] text-[#2D2D2A] text-xs font-bold transition-colors"
                        >
                          ← Back to User List
                        </button>
                      </div>

                      {/* User's Bookings & Activity Logs */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Bookings */}
                        <div className="space-y-2">
                          <h5 className="font-bold text-xs text-[#5A5A40] flex items-center gap-1.5">
                            <Ticket className="w-4 h-4 text-emerald-600" />
                            <span>Tickets Booked by this User</span>
                          </h5>
                          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                            {bookings.filter((b) => b.customerEmail === selectedUser.email || b.customerName.toLowerCase() === selectedUser.name.toLowerCase()).length > 0 ? (
                              bookings
                                .filter((b) => b.customerEmail === selectedUser.email || b.customerName.toLowerCase() === selectedUser.name.toLowerCase())
                                .map((b) => (
                                  <div key={b.id} className="p-3 rounded-xl bg-[#FDFCF8] border border-[#E5E2D9] space-y-1.5 text-xs">
                                    <div className="flex items-center justify-between">
                                      <span className="font-bold text-[#2D2D2A]">{b.itemTitle}</span>
                                      <span className="font-bold text-emerald-700">{b.currency}{b.totalAmount}</span>
                                    </div>
                                    <div className="text-[11px] text-[#8B8B6B] flex items-center justify-between">
                                      <span>Ref: {b.bookingRef} · {b.serviceDate} ({b.serviceTime || 'Slot'})</span>
                                      <span className="px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[9px] font-bold">CONFIRMED</span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => downloadTicketPDF(b, b.cityName)}
                                      className="text-[10px] font-bold text-emerald-700 hover:underline flex items-center gap-1 pt-1"
                                    >
                                      <Download className="w-3 h-3" /> Download PDF Ticket
                                    </button>
                                  </div>
                                ))
                            ) : (
                              <div className="p-4 rounded-xl bg-[#F4F1EA] text-center text-xs text-[#8B8B6B]">
                                No tickets booked yet by this user.
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Activity Timeline */}
                        <div className="space-y-2">
                          <h5 className="font-bold text-xs text-[#5A5A40] flex items-center gap-1.5">
                            <Clock className="w-4 h-4 text-blue-600" />
                            <span>User Activity Timeline</span>
                          </h5>
                          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                            {selectedUser.activityLogs && selectedUser.activityLogs.length > 0 ? (
                              selectedUser.activityLogs.map((log) => (
                                <div key={log.id} className="p-2.5 rounded-xl bg-[#FDFCF8] border border-[#E5E2D9] text-xs">
                                  <div className="font-medium text-[#2D2D2A]">{log.action}</div>
                                  {log.itemTitle && <div className="text-[11px] text-[#8B8B6B]">{log.itemTitle}</div>}
                                  <div className="text-[10px] text-[#8B8B6B] mt-0.5">
                                    {new Date(log.timestamp).toLocaleString()}
                                  </div>
                                </div>
                              ))
                            ) : (
                              <div className="p-4 rounded-xl bg-[#F4F1EA] text-center text-xs text-[#8B8B6B]">
                                No extra activities logged yet.
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* User Database Table */
                    <div className="bg-white rounded-2xl border border-[#E5E2D9] overflow-hidden shadow-xs">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-[#F4F1EA] text-[#5A5A40] font-bold border-b border-[#E5E2D9] uppercase tracking-wider text-[10px]">
                            <tr>
                              <th className="py-3 px-4">User Name</th>
                              <th className="py-3 px-4">Email</th>
                              <th className="py-3 px-4">Phone</th>
                              <th className="py-3 px-4">Registered Date</th>
                              <th className="py-3 px-4">Bookings</th>
                              <th className="py-3 px-4">Total Spent</th>
                              <th className="py-3 px-4 text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#EAE7DC]">
                            {filteredUsers.map((u) => {
                              const userBookings = bookings.filter(
                                (b) => b.customerEmail === u.email || b.customerName.toLowerCase() === u.name.toLowerCase()
                              );
                              const spent = userBookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);

                              return (
                                <tr key={u.id} className="hover:bg-[#FDFCF8] transition-colors">
                                  <td className="py-3 px-4 font-bold text-[#2D2D2A] flex items-center gap-2">
                                    <div className="w-7 h-7 rounded-full bg-[#5A5A40] text-white flex items-center justify-center font-bold text-xs">
                                      {u.name.charAt(0).toUpperCase()}
                                    </div>
                                    <span>{u.name}</span>
                                  </td>
                                  <td className="py-3 px-4 text-[#5A5A40]">{u.email}</td>
                                  <td className="py-3 px-4 text-[#5A5A40]">{u.phone || 'N/A'}</td>
                                  <td className="py-3 px-4 text-[#8B8B6B]">
                                    {new Date(u.joinedAt).toLocaleDateString()}
                                  </td>
                                  <td className="py-3 px-4 font-bold text-emerald-700">
                                    {userBookings.length} Passes
                                  </td>
                                  <td className="py-3 px-4 font-bold text-[#2D2D2A]">
                                    ₹{spent.toLocaleString()}
                                  </td>
                                  <td className="py-3 px-4 text-right">
                                    <button
                                      type="button"
                                      onClick={() => setSelectedUser(u)}
                                      className="px-2.5 py-1 rounded-lg bg-[#F4F1EA] hover:bg-[#5A5A40] hover:text-white text-[#5A5A40] font-bold text-[11px] transition-colors"
                                    >
                                      View Activity
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* === TAB 2: BOOKINGS & USER ACTIVITY DATABASE === */}
              {activeTab === 'bookings' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#2D2D2A]">
                        Live Ticket Bookings & Reservations
                      </h4>
                      <p className="text-xs text-[#8B8B6B]">
                        Real-time audit log of all tickets booked across cinemas, darshans, tables, sights & events.
                      </p>
                    </div>

                    {/* Category Filter */}
                    <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
                      {['all', 'theatre', 'temple', 'restaurant', 'attraction', 'event'].map((cat) => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setCategoryFilter(cat)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-colors ${
                            categoryFilter === cat
                              ? 'bg-[#5A5A40] text-white'
                              : 'bg-[#F4F1EA] text-[#8B8B6B] hover:text-[#2D2D2A]'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {filteredBookings.length === 0 ? (
                    <div className="p-8 bg-white rounded-2xl border border-[#E5E2D9] text-center space-y-2">
                      <Ticket className="w-8 h-8 text-[#8B8B6B] mx-auto" />
                      <div className="font-bold text-sm text-[#2D2D2A]">No bookings found</div>
                      <p className="text-xs text-[#8B8B6B]">Try changing your search keywords or category filters.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      {filteredBookings.map((b) => (
                        <div
                          key={b.id}
                          className="p-4 rounded-2xl bg-white border border-[#E5E2D9] space-y-3 hover:shadow-md transition-shadow"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                                  b.category === 'theatre' ? 'bg-amber-100 text-amber-800' :
                                  b.category === 'temple' ? 'bg-orange-100 text-orange-800' :
                                  b.category === 'restaurant' ? 'bg-emerald-100 text-emerald-800' :
                                  b.category === 'attraction' ? 'bg-purple-100 text-purple-800' :
                                  'bg-rose-100 text-rose-800'
                                }`}>
                                  {b.category}
                                </span>
                                <span className="text-xs font-bold text-[#8B8B6B]">
                                  {b.cityName}
                                </span>
                              </div>
                              <h5 className="font-bold text-sm text-[#2D2D2A] mt-1 leading-tight">
                                {b.itemTitle}
                              </h5>
                              <div className="text-[11px] text-[#8B8B6B] mt-0.5">
                                Ref PNR: <span className="font-mono font-bold text-[#2D2D2A]">{b.bookingRef}</span>
                              </div>
                            </div>

                            <div className="text-right shrink-0">
                              <span className="text-sm font-bold text-emerald-700 block">
                                {b.currency}{b.totalAmount}
                              </span>
                              <span className="px-1.5 py-0.5 rounded-sm bg-emerald-50 text-emerald-800 text-[9px] font-bold">
                                {b.paymentStatus === 'Paid & Confirmed' ? 'PAID' : 'PAY AT VENUE'}
                              </span>
                            </div>
                          </div>

                          {/* Customer info & reservation specifics */}
                          <div className="p-2.5 rounded-xl bg-[#FDFCF8] border border-[#EAE7DC] text-xs space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[#8B8B6B]">Tourist / Customer:</span>
                              <span className="font-bold text-[#2D2D2A]">{b.customerName}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-[#8B8B6B]">Contact:</span>
                              <span className="text-[#5A5A40]">{b.customerPhone} · {b.customerEmail}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-[#8B8B6B]">Date & Slot:</span>
                              <span className="font-semibold text-[#2D2D2A]">{b.serviceDate} ({b.serviceTime || 'Operating hours'})</span>
                            </div>
                            {b.details?.selectedSeats && (
                              <div className="flex items-center justify-between text-amber-800 font-medium">
                                <span>Seats:</span>
                                <span>{b.details.selectedSeats.join(', ')}</span>
                              </div>
                            )}
                            {b.details?.darshanType && (
                              <div className="flex items-center justify-between text-orange-800 font-medium">
                                <span>Darshan Tier:</span>
                                <span>{b.details.darshanType} ({b.details.devoteeCount} Devotees)</span>
                              </div>
                            )}
                          </div>

                          {/* Footer Action */}
                          <div className="flex items-center justify-between pt-1 border-t border-[#E5E2D9] text-xs">
                            <span className="text-[10px] text-[#8B8B6B]">
                              Booked on {new Date(b.createdAt || b.bookingDate).toLocaleDateString()}
                            </span>
                            <button
                              type="button"
                              onClick={() => downloadTicketPDF(b, b.cityName, false)}
                              className="px-2.5 py-1 rounded-lg bg-[#5A5A40] hover:bg-[#484832] text-white font-bold text-[11px] flex items-center gap-1 transition-colors"
                            >
                              <Download className="w-3 h-3" />
                              <span>Download PDF</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* === TAB 3: CITY DATABASE === */}
              {activeTab === 'cities' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-serif font-bold text-base text-[#2D2D2A]">
                        City Knowledge Database
                      </h4>
                      <p className="text-xs text-[#8B8B6B]">
                        Active tourism hubs, heritage locations, cinema theatres, temples, and culinary database.
                      </p>
                    </div>
                    <span className="text-xs font-bold text-purple-800 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200">
                      {cities.length} Cities Activated
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cities.map((c) => {
                      const cityPlaces = places.filter((p) => p.cityId === c.id);
                      const cityBookings = bookings.filter((b) => b.cityName.toLowerCase() === c.name.toLowerCase());
                      const cityRevenue = cityBookings.reduce((sum, b) => sum + (b.totalAmount || 0), 0);

                      const theatresCount = cityPlaces.filter((p) => p.category === 'theatre').length;
                      const templesCount = cityPlaces.filter((p) => p.category === 'temple').length;
                      const foodCount = cityPlaces.filter((p) => p.category === 'restaurant').length;
                      const sightsCount = cityPlaces.filter((p) => p.category === 'attraction').length;

                      return (
                        <div
                          key={c.id}
                          className="rounded-2xl bg-white border border-[#E5E2D9] overflow-hidden shadow-xs hover:shadow-md transition-shadow"
                        >
                          <div className="relative h-28 w-full overflow-hidden bg-stone-800">
                            <img
                              src={c.coverImage}
                              alt={c.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover brightness-[0.7]"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                            <div className="absolute bottom-2.5 left-3 right-3 text-white">
                              <h5 className="font-serif font-bold text-lg leading-tight">{c.name}</h5>
                              <span className="text-[11px] text-stone-300">{c.state}, {c.country}</span>
                            </div>
                          </div>

                          <div className="p-3.5 space-y-3 text-xs">
                            <p className="text-[#5A5A40] text-[11px] line-clamp-2">
                              {c.tagline || c.description}
                            </p>

                            <div className="grid grid-cols-2 gap-1.5 text-[11px] text-[#5A5A40]">
                              <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                <span>🎬 Theatres:</span>
                                <strong className="text-[#2D2D2A]">{theatresCount}</strong>
                              </div>
                              <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                <span>🛕 Temples:</span>
                                <strong className="text-[#2D2D2A]">{templesCount}</strong>
                              </div>
                              <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                <span>🍽️ Food Hubs:</span>
                                <strong className="text-[#2D2D2A]">{foodCount}</strong>
                              </div>
                              <div className="p-1.5 rounded-lg bg-[#F4F1EA] flex items-center gap-1.5">
                                <span>🏛️ Sights:</span>
                                <strong className="text-[#2D2D2A]">{sightsCount}</strong>
                              </div>
                            </div>

                            <div className="pt-2 border-t border-[#E5E2D9] flex items-center justify-between text-[11px]">
                              <span className="text-[#8B8B6B]">Total Bookings Made:</span>
                              <span className="font-bold text-emerald-700">{cityBookings.length} (₹{cityRevenue.toLocaleString()})</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
