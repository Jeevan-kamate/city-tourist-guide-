import React from 'react';
import { CrowdInfo } from '../types';
import { Users, Clock, AlertCircle, ShieldCheck, Sun, Moon } from 'lucide-react';

interface CrowdVisualizerProps {
  crowd: CrowdInfo;
  placeName: string;
  isCompact?: boolean;
}

export const CrowdVisualizer: React.FC<CrowdVisualizerProps> = ({
  crowd,
  placeName,
  isCompact = false,
}) => {
  const currentHour = new Date().getHours();
  const currentDensity = crowd.hourlyCrowdIndex[currentHour] || 30;

  const getCrowdColor = (density: number) => {
    if (density < 30) return 'bg-emerald-500 text-emerald-700';
    if (density < 60) return 'bg-amber-500 text-amber-700';
    if (density < 85) return 'bg-orange-500 text-orange-700';
    return 'bg-rose-500 text-rose-700';
  };

  const getCrowdBadge = (density: number) => {
    if (density < 30) return { label: 'Low Crowd · Peaceful', bg: 'bg-emerald-50 text-emerald-800 border-emerald-200' };
    if (density < 60) return { label: 'Moderate Crowd', bg: 'bg-amber-50 text-amber-800 border-amber-200' };
    if (density < 85) return { label: 'High Rush · Long Queue', bg: 'bg-orange-50 text-orange-800 border-orange-200' };
    return { label: 'Peak Hour · Heavy Rush', bg: 'bg-rose-50 text-rose-800 border-rose-200' };
  };

  const badge = getCrowdBadge(currentDensity);

  if (isCompact) {
    return (
      <div id={`crowd-compact-${placeName.replace(/\s+/g, '-').toLowerCase()}`} className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-medium text-stone-700">
            <Users className="w-3.5 h-3.5 text-amber-600" />
            <span>Crowd Right Now ({currentHour}:00):</span>
          </div>
          <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold border ${badge.bg}`}>
            {badge.label}
          </span>
        </div>

        {/* 24-hr mini histogram */}
        <div className="flex items-end gap-0.5 h-7 w-full bg-stone-100/80 p-1 rounded-md">
          {crowd.hourlyCrowdIndex.map((density, hr) => {
            const isNow = hr === currentHour;
            const heightPercent = Math.max(12, density);
            let barColor = 'bg-stone-300';
            if (density < 30) barColor = 'bg-emerald-400';
            else if (density < 60) barColor = 'bg-amber-400';
            else if (density < 85) barColor = 'bg-orange-400';
            else barColor = 'bg-rose-500';

            return (
              <div
                key={hr}
                className="group relative flex-1 flex flex-col justify-end h-full cursor-pointer"
                title={`${hr}:00 - Crowd: ${density}%`}
              >
                <div
                  className={`w-full rounded-t-xs transition-all ${barColor} ${
                    isNow ? 'ring-2 ring-stone-900 ring-offset-1 ring-offset-white' : 'opacity-80 group-hover:opacity-100'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                />
              </div>
            );
          })}
        </div>
        <div className="flex justify-between text-[10px] text-stone-500 font-mono">
          <span>00:00</span>
          <span>06:00</span>
          <span>12:00</span>
          <span>18:00</span>
          <span>23:00</span>
        </div>
      </div>
    );
  }

  return (
    <div id={`crowd-full-${placeName.replace(/\s+/g, '-').toLowerCase()}`} className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-4">
      {/* Header with Live Status */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-200">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-600" />
            <h4 className="font-semibold text-stone-900 text-sm md:text-base">
              Live Crowd Analysis & Peak Hours
            </h4>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Based on historical visitor movement, ritual schedules, and local check-ins
          </p>
        </div>

        <div className={`px-3 py-1 rounded-full text-xs font-semibold border ${badge.bg} flex items-center gap-1.5 shadow-xs`}>
          <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
          <span>Now ({currentHour}:00): {badge.label}</span>
        </div>
      </div>

      {/* 24-Hour Crowd Density Curve */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-xs font-medium text-stone-600">
          <span>24-Hour Crowd Density Forecast (0-100% capacity)</span>
          <span className="text-[11px] text-stone-500">Hover over bars for hourly estimates</span>
        </div>

        <div className="h-28 w-full bg-white border border-stone-200/90 rounded-lg p-2.5 flex items-end gap-1 relative">
          {/* Guide lines */}
          <div className="absolute inset-x-2.5 top-6 border-b border-dashed border-stone-200 pointer-events-none" />
          <div className="absolute inset-x-2.5 top-14 border-b border-dashed border-stone-200 pointer-events-none" />

          {crowd.hourlyCrowdIndex.map((density, hr) => {
            const isNow = hr === currentHour;
            const heightPercent = Math.max(8, density);
            let barColor = 'bg-emerald-400';
            if (density >= 85) barColor = 'bg-rose-500';
            else if (density >= 60) barColor = 'bg-orange-400';
            else if (density >= 30) barColor = 'bg-amber-400';

            return (
              <div
                key={hr}
                className="group relative flex-1 flex flex-col justify-end h-full cursor-pointer"
              >
                {/* Tooltip on hover */}
                <div className="absolute bottom-full mb-1.5 left-1/2 -translate-x-1/2 hidden group-hover:flex flex-col items-center bg-stone-900 text-white text-[10px] rounded px-1.5 py-1 z-30 whitespace-nowrap shadow-md pointer-events-none">
                  <span className="font-semibold">{hr.toString().padStart(2, '0')}:00</span>
                  <span>{density}% Crowd</span>
                  {isNow && <span className="text-amber-300 text-[9px]">Current Hour</span>}
                </div>

                <div
                  className={`w-full rounded-t transition-all ${barColor} ${
                    isNow
                      ? 'ring-2 ring-stone-900 ring-offset-2 ring-offset-white shadow-xs'
                      : 'opacity-85 hover:opacity-100'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                />
              </div>
            );
          })}
        </div>

        <div className="flex justify-between text-[11px] text-stone-500 font-mono px-1">
          <span className="flex items-center gap-1"><Moon className="w-3 h-3" /> 00:00</span>
          <span>06:00 (Dawn)</span>
          <span className="flex items-center gap-1"><Sun className="w-3 h-3 text-amber-500" /> 12:00 (Noon)</span>
          <span>18:00 (Dusk)</span>
          <span>23:00</span>
        </div>
      </div>

      {/* Average Wait Time & Peak vs Low Times */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        <div className="bg-rose-50/70 border border-rose-100 rounded-lg p-3 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-900">
            <AlertCircle className="w-4 h-4 text-rose-600" />
            <span>Peak Rush Windows (Longest Wait)</span>
          </div>
          <ul className="space-y-1 text-xs text-rose-800">
            {crowd.peakHours.map((peak, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-rose-500 font-bold">•</span>
                <span>{peak}</span>
              </li>
            ))}
          </ul>
          {crowd.peakDays && crowd.peakDays.length > 0 && (
            <p className="text-[11px] text-rose-700 font-medium pt-1">
              Busy Days: {crowd.peakDays.join(', ')}
            </p>
          )}
        </div>

        <div className="bg-emerald-50/70 border border-emerald-100 rounded-lg p-3 space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-900">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Best Time to Visit (Least Crowd)</span>
          </div>
          <p className="text-xs text-emerald-800 font-medium leading-relaxed">
            {crowd.leastCrowdHours}
          </p>
          {crowd.avgWaitTimeMinutes && (
            <div className="flex items-center gap-3 pt-1 text-[11px] text-emerald-700">
              <span>Avg Normal Queue: <strong>{crowd.avgWaitTimeMinutes.normal}m</strong></span>
              <span>Peak Queue: <strong>{crowd.avgWaitTimeMinutes.peak}m</strong></span>
              {crowd.avgWaitTimeMinutes.vip !== undefined && (
                <span>VIP Pass: <strong>{crowd.avgWaitTimeMinutes.vip}m</strong></span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Practical Tips to Avoid Crowd */}
      {crowd.tipsToAvoidCrowd && crowd.tipsToAvoidCrowd.length > 0 && (
        <div className="bg-white border border-stone-200 rounded-lg p-3 space-y-1.5">
          <h5 className="text-xs font-semibold text-stone-900 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Local Tourist Advice & Queue Bypass Tips:</span>
          </h5>
          <ul className="space-y-1 text-xs text-stone-600">
            {crowd.tipsToAvoidCrowd.map((tip, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-amber-600 font-semibold">✓</span>
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Special Ritual / Aarti Timings if applicable */}
      {crowd.specialRituals && crowd.specialRituals.length > 0 && (
        <div className="space-y-1.5">
          <h5 className="text-xs font-semibold text-stone-900">
            Sacred Ritual & Aarti Schedule
          </h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {crowd.specialRituals.map((ritual, idx) => (
              <div
                key={idx}
                className="bg-white border border-stone-200 rounded-md p-2 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-medium text-stone-800 block">{ritual.name}</span>
                  <span className="text-[11px] text-amber-700 font-mono">{ritual.time}</span>
                </div>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                    ritual.crowdImpact === 'High'
                      ? 'bg-rose-100 text-rose-800'
                      : ritual.crowdImpact === 'Medium'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {ritual.crowdImpact} Rush
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
