import React, { useState } from 'react';
import { Place, City } from '../types';
import { 
  Ticket, 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  Calculator, 
  Users, 
  Sparkles, 
  CheckCircle, 
  Download, 
  Share2, 
  Printer 
} from 'lucide-react';

interface TicketCalculatorModalProps {
  city: City;
  savedPlaces: Place[];
  allCityPlaces: Place[];
  isOpen: boolean;
  onClose: () => void;
  onRemovePlace: (placeId: string) => void;
  onAddPlace: (place: Place) => void;
}

export const TicketCalculatorModal: React.FC<TicketCalculatorModalProps> = ({
  city,
  savedPlaces,
  allCityPlaces,
  isOpen,
  onClose,
  onRemovePlace,
  onAddPlace,
}) => {
  const [adultCount, setAdultCount] = useState(2);
  const [childCount, setChildCount] = useState(0);
  const [isForeignTourist, setIsForeignTourist] = useState(false);
  const [useVipPasses, setUseVipPasses] = useState<{ [placeId: string]: boolean }>({});

  if (!isOpen) return null;

  const toggleVip = (placeId: string) => {
    setUseVipPasses((prev) => ({ ...prev, [placeId]: !prev[placeId] }));
  };

  // Calculate costs per place
  let grandTotal = 0;

  const itemizedCosts = savedPlaces.map((place) => {
    const t = place.ticket || { isFree: true, currency: '₹', generalPrice: 0 };
    let adultRate = t.generalPrice || 0;
    if (isForeignTourist && t.foreignTouristPrice !== undefined) {
      adultRate = t.foreignTouristPrice;
    }

    const isVip = useVipPasses[place.id] && t.vipPrice !== undefined;
    if (isVip && t.vipPrice) {
      adultRate = t.vipPrice;
    }

    let childRate = t.childPrice !== undefined ? t.childPrice : adultRate * 0.5;
    if (t.isFree) {
      adultRate = 0;
      childRate = 0;
    }

    const placeTotal = adultRate * adultCount + childRate * childCount;
    grandTotal += placeTotal;

    return {
      place,
      adultRate,
      childRate,
      placeTotal,
      isVip,
    };
  });

  const availablePlacesToAdd = allCityPlaces.filter(
    (p) => !savedPlaces.some((sp) => sp.id === p.id)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white border border-stone-200 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl space-y-4 my-auto text-stone-900">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-900 to-amber-950 text-white p-5 sm:p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 border border-amber-400/30 rounded-xl">
              <Calculator className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display">
                Tourist Trip Ticket Budget Calculator
              </h2>
              <p className="text-xs text-amber-200">
                Accurate entry fees, movie tickets & darshan passes for {city.name}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tourist Group Configuration */}
        <div className="p-5 sm:p-6 space-y-6">
          <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 space-y-3">
            <h4 className="font-bold text-xs text-stone-900 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-stone-500" />
              <span>Configure Your Travel Party:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              {/* Adults */}
              <div className="bg-white p-3 rounded-xl border border-stone-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-stone-900 block">Adults (12+ yrs)</span>
                  <span className="text-[10px] text-stone-500">Standard rates</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setAdultCount(Math.max(1, adultCount - 1))}
                    className="p-1 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-bold text-sm w-4 text-center">{adultCount}</span>
                  <button
                    onClick={() => setAdultCount(adultCount + 1)}
                    className="p-1 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Children */}
              <div className="bg-white p-3 rounded-xl border border-stone-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-stone-900 block">Children (&lt;12 yrs)</span>
                  <span className="text-[10px] text-emerald-600 font-medium">Discount / Free</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setChildCount(Math.max(0, childCount - 1))}
                    className="p-1 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-bold text-sm w-4 text-center">{childCount}</span>
                  <button
                    onClick={() => setChildCount(childCount + 1)}
                    className="p-1 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Foreign Tourist Toggle */}
              <div className="bg-white p-3 rounded-xl border border-stone-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-stone-900 block">Foreign Tourist</span>
                  <span className="text-[10px] text-stone-500">Non-resident tariff</span>
                </div>
                <input
                  type="checkbox"
                  checked={isForeignTourist}
                  onChange={(e) => setIsForeignTourist(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Selected Itinerary Places List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <h4 className="font-bold text-sm text-stone-900">
                Itinerary Places ({savedPlaces.length})
              </h4>
              <span className="text-stone-500">
                {savedPlaces.length === 0 ? 'No places selected yet' : 'Itemized entry breakdown'}
              </span>
            </div>

            {savedPlaces.length === 0 ? (
              <div className="p-8 text-center bg-stone-50 border border-dashed border-stone-300 rounded-2xl space-y-2">
                <Ticket className="w-8 h-8 text-stone-400 mx-auto" />
                <p className="font-semibold text-xs text-stone-700">Your ticket calculator is empty</p>
                <p className="text-[11px] text-stone-500 max-w-sm mx-auto">
                  Click "Add to Ticket Budget" on any place or select from available spots below.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {itemizedCosts.map(({ place, adultRate, childRate, placeTotal, isVip }) => (
                  <div
                    key={place.id}
                    className="p-3.5 bg-white border border-stone-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-start gap-3">
                      <img src={place.image} alt={place.name} className="w-12 h-12 rounded-lg object-cover shrink-0" />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-stone-900 text-sm">{place.name}</span>
                          <span className="text-[10px] bg-stone-100 text-stone-700 px-1.5 py-0.2 rounded uppercase font-semibold">
                            {place.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-500">
                          Adult: {place.ticket?.currency || '₹'}{adultRate} × {adultCount}
                          {childCount > 0 && ` + Child: ${place.ticket?.currency || '₹'}{childRate} × ${childCount}`}
                        </p>

                        {/* VIP Darshan toggle if available */}
                        {place.ticket?.vipPrice !== undefined && (
                          <label className="flex items-center gap-1.5 mt-1 cursor-pointer text-[11px] text-amber-800 font-semibold">
                            <input
                              type="checkbox"
                              checked={!!useVipPasses[place.id]}
                              onChange={() => toggleVip(place.id)}
                              className="w-3.5 h-3.5 text-amber-600 rounded"
                            />
                            <span>Use VIP Fast-Track Pass ({place.ticket?.currency || '₹'}{place.ticket?.vipPrice})</span>
                          </label>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100">
                      <div className="text-right">
                        <span className="font-extrabold text-sm text-stone-900 block">
                          {place.ticket?.currency || '₹'}{placeTotal}
                        </span>
                        <span className="text-[10px] text-stone-500">
                          {place.ticket?.isFree ? 'Free Admission' : 'Subtotal'}
                        </span>
                      </div>
                      <button
                        onClick={() => onRemovePlace(place.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Remove place"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Quick Add More Places Dropdown / List */}
            {availablePlacesToAdd.length > 0 && (
              <div className="pt-2">
                <span className="text-[11px] font-semibold text-stone-600 block mb-1.5">
                  + Add more places to your budget:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {availablePlacesToAdd.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => onAddPlace(p)}
                      className="px-2.5 py-1 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-[11px] font-medium text-stone-700 flex items-center gap-1 transition-colors"
                    >
                      <Plus className="w-3 h-3 text-stone-400" />
                      <span>{p.name} ({p.ticket.isFree ? 'Free' : `${p.ticket.currency}${p.ticket.generalPrice}`})</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Grand Total Summary Box */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs text-amber-900 font-semibold block">Total Estimated Ticket Budget</span>
              <p className="text-xs text-amber-800">
                For {adultCount} Adult{adultCount > 1 ? 's' : ''} {childCount > 0 ? `+ ${childCount} Child${childCount > 1 ? 'ren' : ''}` : ''} in {city.name}
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <span className="text-2xl sm:text-3xl font-extrabold text-stone-900 block font-display">
                  {city.currencySymbol}{grandTotal}
                </span>
                <span className="text-[10px] text-amber-900 font-bold uppercase">
                  {city.localCurrency}
                </span>
              </div>
              <button
                onClick={() => window.print()}
                className="p-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl shadow-xs transition-colors"
                title="Print or Save Budget"
              >
                <Printer className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
